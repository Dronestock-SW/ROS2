from __future__ import annotations

import math
import threading
import time
from collections import deque
from dataclasses import dataclass, replace

from ..types import IMUState, MotionState

try:  # pragma: no cover - hardware path
    from smbus2 import SMBus
except ImportError:  # pragma: no cover
    SMBus = None


PWR_MGMT_1 = 0x6B
TEMP_OUT_H = 0x41
ACCEL_XOUT_H = 0x3B
GYRO_XOUT_H = 0x43
G = 9.80665


@dataclass
class _Bias:
    ax_g: float = 0.0
    ay_g: float = 0.0
    az_g: float = 0.0
    gx_dps: float = 0.0
    gy_dps: float = 0.0
    gz_dps: float = 0.0


class MPU6050Reader:
    """MPU6050 safety IMU reader.

    The output is intentionally limited to companion-side safety and motion
    classification. It is never injected into Pixhawk attitude EKF and never
    integrated into x/y/z position.
    """

    def __init__(
        self,
        *,
        enabled: bool = True,
        i2c_bus: int = 1,
        i2c_addr: int = 0x68,
        rate_hz: int = 100,
        calibration_s: float = 3.0,
        complementary_alpha: float = 0.98,
    ) -> None:
        self.enabled = enabled
        self.i2c_bus = i2c_bus
        self.i2c_addr = i2c_addr
        self.rate_hz = max(10, int(rate_hz))
        self.calibration_s = max(0.5, float(calibration_s))
        self.alpha = max(0.0, min(1.0, float(complementary_alpha)))
        self._lock = threading.Lock()
        self._latest = IMUState(reason="disabled" if not enabled else "not_started")
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()
        self._bias = _Bias()
        self._last_sample_t: float | None = None
        self._roll = 0.0
        self._pitch = 0.0
        self._last_accel = (0.0, 0.0, G)
        self._vibration_window: deque[float] = deque(maxlen=max(10, self.rate_hz // 2))

    def start(self) -> None:
        if not self.enabled:
            return
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, name="mpu6050-reader", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()

    def latest(self, now: float | None = None) -> IMUState:
        now = time.monotonic() if now is None else now
        with self._lock:
            return self._latest.with_age(now)

    def _run(self) -> None:  # pragma: no cover - hardware loop
        if SMBus is None:
            self._set_error("IMU_NOT_FOUND:smbus2_missing")
            return
        period = 1.0 / float(self.rate_hz)
        while not self._stop.is_set():
            try:
                with SMBus(self.i2c_bus) as bus:
                    bus.write_byte_data(self.i2c_addr, PWR_MGMT_1, 0)
                    time.sleep(0.1)
                    ok, reason = self._calibrate(bus)
                    if not ok:
                        self._set_error(reason)
                        time.sleep(1.0)
                        continue
                    while not self._stop.is_set():
                        started = time.monotonic()
                        self._record_sample(bus)
                        elapsed = time.monotonic() - started
                        if elapsed < period:
                            time.sleep(period - elapsed)
            except Exception as exc:
                self._set_error(f"IMU_READ_TIMEOUT:{exc}")
                time.sleep(1.0)

    def _calibrate(self, bus: "SMBus") -> tuple[bool, str]:  # pragma: no cover
        samples: list[tuple[float, float, float, float, float, float]] = []
        end_at = time.monotonic() + self.calibration_s
        while time.monotonic() < end_at and not self._stop.is_set():
            ax, ay, az, gx, gy, gz, _temp = self._read_scaled(bus)
            samples.append((ax, ay, az, gx, gy, gz))
            time.sleep(0.01)
        if len(samples) < 20:
            return False, "IMU_CALIBRATION_FAILED"

        avg = [sum(row[i] for row in samples) / len(samples) for i in range(6)]
        gyro_norm = max(abs(avg[3]), abs(avg[4]), abs(avg[5]))
        accel_norm = math.sqrt(avg[0] * avg[0] + avg[1] * avg[1] + avg[2] * avg[2])
        moving = any(max(abs(row[3] - avg[3]), abs(row[4] - avg[4]), abs(row[5] - avg[5])) > 5.0 for row in samples)
        if moving:
            return False, "IMU_NOT_STATIONARY"
        if gyro_norm > 3.0:
            return False, "IMU_CALIBRATION_FAILED"
        if not 0.92 <= accel_norm <= 1.08:
            return False, "IMU_ACCEL_NORM_INVALID"

        self._bias = _Bias(
            ax_g=avg[0],
            ay_g=avg[1],
            az_g=avg[2] - 1.0,
            gx_dps=avg[3],
            gy_dps=avg[4],
            gz_dps=avg[5],
        )
        self._last_sample_t = None
        return True, "ok"

    def _record_sample(self, bus: "SMBus") -> None:  # pragma: no cover
        ax_g, ay_g, az_g, gx_dps, gy_dps, gz_dps, temp_c = self._read_scaled(bus)
        ax_g -= self._bias.ax_g
        ay_g -= self._bias.ay_g
        az_g -= self._bias.az_g
        gx_dps -= self._bias.gx_dps
        gy_dps -= self._bias.gy_dps
        gz_dps -= self._bias.gz_dps

        now = time.monotonic()
        dt = 1.0 / float(self.rate_hz) if self._last_sample_t is None else max(1e-3, now - self._last_sample_t)
        self._last_sample_t = now

        roll_acc = math.degrees(math.atan2(ay_g, az_g))
        pitch_acc = math.degrees(math.atan2(-ax_g, math.sqrt(ay_g * ay_g + az_g * az_g)))
        self._roll = self.alpha * (self._roll + gx_dps * dt) + (1.0 - self.alpha) * roll_acc
        self._pitch = self.alpha * (self._pitch + gy_dps * dt) + (1.0 - self.alpha) * pitch_acc

        accel = (ax_g * G, ay_g * G, az_g * G)
        prev = self._last_accel
        jerk = math.sqrt(sum((accel[i] - prev[i]) ** 2 for i in range(3))) / dt
        self._last_accel = accel
        accel_norm_g = math.sqrt(ax_g * ax_g + ay_g * ay_g + az_g * az_g)
        self._vibration_window.append(accel_norm_g)
        vibration = _stddev(self._vibration_window)
        tilt = max(abs(self._roll), abs(self._pitch))
        rate = max(abs(gx_dps), abs(gy_dps), abs(gz_dps))
        shock = accel_norm_g >= 2.0 or jerk >= 35.0
        motion_state = _classify_motion(tilt=tilt, rate=rate, accel_norm_g=accel_norm_g, jerk=jerk, vibration=vibration)

        with self._lock:
            self._latest = IMUState(
                roll_deg=self._roll,
                pitch_deg=self._pitch,
                roll_rate_dps=gx_dps,
                pitch_rate_dps=gy_dps,
                yaw_rate_dps=gz_dps,
                accel_z_g=az_g,
                accel_norm_g=accel_norm_g,
                linear_accel_x_mps2=accel[0],
                linear_accel_y_mps2=accel[1],
                linear_accel_z_mps2=accel[2] - G,
                jerk_mps3=jerk,
                vibration_score=vibration,
                temperature_c=temp_c,
                calibrated=True,
                sample_rate_hz=float(self.rate_hz),
                motion_state=motion_state,
                tilt_ok=tilt < 12.0,
                rate_ok=rate < 120.0,
                shock_detected=shock,
                drift_status="STABLE",
                health="OK",
                usable=True,
                reason="ok",
                received_monotonic=now,
            )

    def _read_scaled(self, bus: "SMBus") -> tuple[float, float, float, float, float, float, float]:  # pragma: no cover
        ax = _read_word_signed(bus, self.i2c_addr, ACCEL_XOUT_H) / 16384.0
        ay = _read_word_signed(bus, self.i2c_addr, ACCEL_XOUT_H + 2) / 16384.0
        az = _read_word_signed(bus, self.i2c_addr, ACCEL_XOUT_H + 4) / 16384.0
        temp_raw = _read_word_signed(bus, self.i2c_addr, TEMP_OUT_H)
        gx = _read_word_signed(bus, self.i2c_addr, GYRO_XOUT_H) / 131.0
        gy = _read_word_signed(bus, self.i2c_addr, GYRO_XOUT_H + 2) / 131.0
        gz = _read_word_signed(bus, self.i2c_addr, GYRO_XOUT_H + 4) / 131.0
        return ax, ay, az, gx, gy, gz, (temp_raw / 340.0) + 36.53

    def _set_error(self, reason: str) -> None:
        with self._lock:
            self._latest = replace(
                self._latest,
                usable=False,
                health="ERROR",
                reason=reason,
                received_monotonic=time.monotonic(),
            )


def _classify_motion(*, tilt: float, rate: float, accel_norm_g: float, jerk: float, vibration: float) -> str:
    if tilt >= 18.0 or accel_norm_g >= 2.5:
        return MotionState.TIPPED_OR_CRASHED.value
    if jerk >= 35.0:
        return MotionState.BOUNCE_OR_CONTACT.value
    if tilt < 8.0 and rate < 30.0 and vibration < 0.08 and 0.92 <= accel_norm_g <= 1.08:
        return MotionState.ON_GROUND_STABLE.value
    if vibration >= 0.08 and rate < 80.0:
        return MotionState.MOTOR_SPINNING.value
    if tilt < 12.0 and rate < 120.0 and jerk < 35.0:
        return MotionState.LIFTOFF_CANDIDATE.value
    return MotionState.UNKNOWN.value


def _stddev(values: deque[float]) -> float:
    if len(values) < 2:
        return 0.0
    mean = sum(values) / len(values)
    return math.sqrt(sum((value - mean) ** 2 for value in values) / len(values))


def _read_word_signed(bus: "SMBus", addr: int, reg: int) -> int:  # pragma: no cover
    high = bus.read_byte_data(addr, reg)
    low = bus.read_byte_data(addr, reg + 1)
    value = (high << 8) | low
    if value >= 0x8000:
        value = -((65535 - value) + 1)
    return value
