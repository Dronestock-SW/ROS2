from __future__ import annotations

import json
import statistics
import threading
import time
from collections import deque
from dataclasses import replace
from typing import Any

from ..types import ToFState, UWBState, finite_bool, finite_float

try:  # pragma: no cover - exercised on Raspberry Pi hardware
    import serial
except ImportError:  # pragma: no cover
    serial = None


class UWBSerialReader:
    """Read ESP32+DWM3000 tag telemetry over USB serial.

    This class is deliberately a sensor reader only. It parses UWB state and can
    send authoritative anchor layout commands to the tag, but it never changes
    mission state and never emits RC commands.
    """

    def __init__(self, *, port: str, baud: int = 115200, timeout_s: float = 0.1, tof_alpha: float = 0.35) -> None:
        self.port = port
        self.baud = baud
        self.timeout_s = timeout_s
        self.tof_alpha = max(0.01, min(1.0, tof_alpha))
        self._lock = threading.Lock()
        self._latest = UWBState(reason="not_started")
        self._latest_tof = ToFState(reason="uwb_tag_not_started")
        self._tof_ground_offset_m: float | None = None
        self._tof_recent_distances: deque[float] = deque(maxlen=30)
        self._serial: Any = None
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()
        self.last_anchor_layout_sent: str = ""
        self._serial_connected = False
        self._serial_open_count = 0
        self._total_lines = 0
        self._invalid_json_lines = 0
        self._ignored_json_lines = 0
        self._accepted_pose_lines = 0
        self._last_line_monotonic: float | None = None
        self._last_pose_monotonic: float | None = None
        self._last_payload_type = ""
        self._last_error = ""

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, name="uwb-serial-reader", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._serial is not None:
            try:
                self._serial.close()
            except Exception:
                pass

    def latest(self, now: float | None = None) -> UWBState:
        now = time.monotonic() if now is None else now
        with self._lock:
            return self._latest.with_age(now)

    def latest_tof(self, now: float | None = None) -> ToFState:
        now = time.monotonic() if now is None else now
        with self._lock:
            return self._latest_tof.with_age(now)

    def capture_tof_ground_offset(self) -> ToFState:
        with self._lock:
            samples = list(self._tof_recent_distances)
            if not samples:
                self._latest_tof = replace(self._latest_tof, usable=False, reason="uwb_tof_ground_offset_no_samples")
                return self._latest_tof
            self._tof_ground_offset_m = statistics.median(samples)
            self._latest_tof = self._tof_with_ground_offset_locked(self._latest_tof)
            return self._latest_tof

    def diagnostics(self, now: float | None = None) -> dict[str, Any]:
        """Return a secret-free snapshot suitable for logs and field support."""
        now = time.monotonic() if now is None else now
        with self._lock:
            return {
                "connected": self._serial_connected,
                "port": self.port,
                "baud": self.baud,
                "serial_open_count": self._serial_open_count,
                "total_lines": self._total_lines,
                "invalid_json_lines": self._invalid_json_lines,
                "ignored_json_lines": self._ignored_json_lines,
                "accepted_pose_lines": self._accepted_pose_lines,
                "last_line_age_ms": _age_ms(self._last_line_monotonic, now),
                "last_pose_age_ms": _age_ms(self._last_pose_monotonic, now),
                "last_payload_type": self._last_payload_type or None,
                "last_error": self._last_error or None,
                "last_reason": self._latest.reason or None,
                "last_seq": self._latest.seq,
                "last_fix": self._latest.fix,
                "last_x": self._latest.x_m,
                "last_y": self._latest.y_m,
                "last_uwb_link": self._latest.uwb_link,
                "last_xy_control_usable": self._latest.xy_control_usable,
            }

    def send_anchor_layout(self, *, layout_id: str, anchors: list[dict[str, Any]]) -> bool:
        """Send authoritative anchor layout to the tag firmware."""
        if self._serial is None or not anchors:
            return False

        ordered = _ordered_anchors(anchors)
        if len(ordered) < 3:
            return False
        command_name = "ANCHORS4" if len(ordered) >= 4 else "ANCHORS"
        ordered = ordered[:4] if command_name == "ANCHORS4" else ordered[:3]

        values: list[float] = []
        for anchor in ordered:
            x = finite_float(anchor.get("x"))
            y = finite_float(anchor.get("y"))
            z = finite_float(anchor.get("z"))
            if x is None or y is None or z is None:
                return False
            values.extend([x, y, z])

        command = "{} LAYOUT={} {}\n".format(
            command_name,
            _safe_layout_id(layout_id),
            " ".join(f"{value:.3f}" for value in values),
        )
        try:
            self._serial.write(command.encode("ascii"))
            self._serial.flush()
            self.last_anchor_layout_sent = layout_id
            return True
        except Exception:
            return False

    def _run(self) -> None:  # pragma: no cover - hardware loop
        if serial is None:
            with self._lock:
                self._latest = replace(self._latest, reason="pyserial_missing")
                self._last_error = "pyserial_missing"
            return

        while not self._stop.is_set():
            try:
                with serial.Serial(self.port, self.baud, timeout=self.timeout_s) as ser:
                    self._serial = ser
                    with self._lock:
                        self._serial_connected = True
                        self._serial_open_count += 1
                        self._last_error = ""
                    while not self._stop.is_set():
                        raw = ser.readline()
                        if not raw:
                            continue
                        line = raw.decode("utf-8", errors="ignore").strip()
                        self._consume_line(line)
            except Exception as exc:
                with self._lock:
                    self._latest = replace(self._latest, reason=f"serial_error:{exc}")
                    self._last_error = f"{type(exc).__name__}:{exc}"
                time.sleep(1.0)
            finally:
                self._serial = None
                with self._lock:
                    self._serial_connected = False

    def _consume_line(self, line: str, *, received_monotonic: float | None = None) -> bool:
        """Parse one tag line and update state; exposed for deterministic tests."""
        received_monotonic = time.monotonic() if received_monotonic is None else received_monotonic
        payload = _parse_json_line(line)
        with self._lock:
            self._total_lines += 1
            self._last_line_monotonic = received_monotonic
            if payload is None:
                self._invalid_json_lines += 1
                return False

            self._last_payload_type = str(payload.get("type") or "")
            state = parse_uwb_payload(payload, received_monotonic=received_monotonic)
            if state is None:
                self._ignored_json_lines += 1
                return False

            self._accepted_pose_lines += 1
            self._last_pose_monotonic = received_monotonic
            self._latest = state
            self._update_tof_from_payload_locked(payload, received_monotonic)
            return True

    def _update_tof_from_payload_locked(self, payload: dict[str, Any], received_monotonic: float) -> None:
        tof_payload = _extract_tof_payload(payload)
        if tof_payload is None:
            return
        if not finite_bool(tof_payload.get("usable"), True):
            self._latest_tof = replace(
                self._latest_tof,
                usable=False,
                reason=str(tof_payload.get("reason") or "uwb_tof_unusable"),
                received_monotonic=received_monotonic,
            )
            return
        raw_distance_m = _tof_distance_m(tof_payload)
        if raw_distance_m is None:
            self._latest_tof = replace(
                self._latest_tof,
                usable=False,
                reason=str(tof_payload.get("reason") or "uwb_tof_missing_distance"),
                received_monotonic=received_monotonic,
            )
            return

        prev = self._latest_tof
        filtered = raw_distance_m
        if prev.filtered_distance_m is not None:
            filtered = self.tof_alpha * raw_distance_m + (1.0 - self.tof_alpha) * prev.filtered_distance_m
        self._tof_recent_distances.append(filtered)

        vertical_speed = None
        if prev.filtered_distance_m is not None and prev.received_monotonic is not None:
            dt = max(1e-3, received_monotonic - prev.received_monotonic)
            vertical_speed = (filtered - prev.filtered_distance_m) / dt

        state = ToFState(
            raw_distance_m=raw_distance_m,
            filtered_distance_m=filtered,
            ground_offset_m=self._tof_ground_offset_m,
            vertical_speed_mps=vertical_speed,
            usable=True,
            reason=str(tof_payload.get("reason") or "ok"),
            confidence=finite_float(tof_payload.get("confidence"), 1.0) or 1.0,
            received_monotonic=received_monotonic,
        )
        self._latest_tof = self._tof_with_ground_offset_locked(state)

    def _tof_with_ground_offset_locked(self, state: ToFState) -> ToFState:
        if self._tof_ground_offset_m is None or state.filtered_distance_m is None:
            return replace(state, ground_offset_m=self._tof_ground_offset_m, altitude_m=None)
        altitude = max(0.0, state.filtered_distance_m - self._tof_ground_offset_m)
        return replace(state, ground_offset_m=self._tof_ground_offset_m, altitude_m=altitude)


def parse_uwb_payload(payload: dict[str, Any], *, received_monotonic: float | None = None) -> UWBState | None:
    payload_type = str(payload.get("type") or "").strip().lower()
    if payload_type not in {"uwb_pose", "telemetry"}:
        return None

    z_control_m = _first_float(payload, "z_control_m", "zc", "current_z_m", "z3d", "z3")
    z3d = _first_float(payload, "z3d", "z3", "current_z_m")
    ranges, range_ok = _parse_ranges(payload)
    range_fix = finite_bool(payload.get("range_fix"), all(range_ok[:3]) if len(range_ok) >= 3 else False)
    layout_synced = finite_bool(payload.get("layout_synced"), finite_bool(payload.get("tag_layout_synced"), False))
    xy_control_usable = finite_bool(
        payload.get("xy_control_usable"),
        finite_bool(payload.get("cu"), finite_bool(payload.get("control_usable"), False)),
    )
    if not xy_control_usable and finite_bool(payload.get("fix"), False) and range_fix and layout_synced:
        xy_control_usable = True
    z_trusted = finite_bool(payload.get("z_trusted"), finite_bool(payload.get("current_z_trusted"), False))
    if payload.get("z_control_usable") is not None:
        z_control_usable = finite_bool(payload.get("z_control_usable"), False)
    elif payload.get("zcu") is not None:
        z_control_usable = finite_bool(payload.get("zcu"), False)
    else:
        z_control_usable = z_trusted or finite_bool(payload.get("control_usable"), False)
    pose_quality = str(payload.get("pose_quality") or "").strip().upper()
    if not pose_quality:
        if xy_control_usable and z_control_usable:
            pose_quality = "CONTROL_GRADE"
        elif xy_control_usable:
            pose_quality = "POSITION_ONLY"
        elif finite_bool(payload.get("pose4d_fix"), finite_bool(payload.get("pose3d_fix"), False)):
            pose_quality = "DEGRADED_FIX"
        else:
            pose_quality = "NO_FIX"

    return UWBState(
        x_m=_first_float(payload, "x", "x_m"),
        y_m=_first_float(payload, "y", "y_m"),
        z_raw=_first_float(payload, "z_raw", "raw_z"),
        z3d=z3d,
        z_filtered=_first_float(payload, "z_filtered", "zf"),
        z_control_m=z_control_m,
        z_trusted=z_trusted,
        z_control_usable=z_control_usable,
        xy_control_usable=xy_control_usable,
        z_reason=str(payload.get("z_reason") or payload.get("uwb3d_reason") or ""),
        z_residual_m=_first_float(payload, "z_residual_m", "current_z_residual_m"),
        z_confidence=_first_float(payload, "z_confidence", "current_z_confidence"),
        z_candidate_spread_m=_first_float(payload, "z_candidate_spread_m"),
        ranges=ranges,
        range_ok=range_ok,
        fix=finite_bool(payload.get("fix"), False),
        pose4d_fix=finite_bool(payload.get("pose4d_fix"), finite_bool(payload.get("pose3d_fix"), False)),
        pose_quality=pose_quality,
        uwb4_residual_m=_first_float(payload, "uwb4_residual_m", "z_residual_m", "current_z_residual_m"),
        uwb_link=finite_bool(payload.get("uwb_link"), finite_bool(payload.get("pf"), range_fix or xy_control_usable)),
        tag_layout_synced=layout_synced,
        anchor_layout_id=str(payload.get("layout_id") or payload.get("anchor_layout_id") or ""),
        layout_version=int(finite_float(payload.get("layout_version"), 0) or 0),
        seq=int(payload["seq"]) if str(payload.get("seq") or "").isdigit() else None,
        reason=str(payload.get("reason") or ""),
        received_monotonic=received_monotonic,
        raw=dict(payload),
    )


def _parse_json_line(line: str) -> dict[str, Any] | None:
    if not line:
        return None
    try:
        payload = json.loads(line)
        return payload if isinstance(payload, dict) else None
    except json.JSONDecodeError:
        start = line.find("{")
        end = line.rfind("}")
        if start < 0 or end <= start:
            return None
        try:
            payload = json.loads(line[start:end + 1])
            return payload if isinstance(payload, dict) else None
        except json.JSONDecodeError:
            return None


def _first_float(payload: dict[str, Any], *keys: str) -> float | None:
    for key in keys:
        value = finite_float(payload.get(key))
        if value is not None:
            return value
    return None


def _age_ms(then: float | None, now: float) -> int | None:
    if then is None:
        return None
    return max(0, int((now - then) * 1000))


def _parse_ranges(payload: dict[str, Any]) -> tuple[list[float | None], list[bool]]:
    raw_ranges = payload.get("ranges")
    ranges: list[float | None] = []
    range_ok: list[bool] = []
    if isinstance(raw_ranges, list):
        for item in raw_ranges:
            if isinstance(item, dict):
                value = finite_float(item.get("range_m") or item.get("distance_m") or item.get("d"))
                ok = finite_bool(item.get("ok"), value is not None)
            else:
                value = finite_float(item)
                ok = value is not None
            ranges.append(value)
            range_ok.append(ok)
    else:
        for key in ("d1", "d2", "d3", "d4"):
            value = finite_float(payload.get(key))
            ranges.append(value)
            range_ok.append(value is not None)

    raw_ok = payload.get("range_ok")
    if isinstance(raw_ok, list):
        range_ok = [finite_bool(value, False) for value in raw_ok]
        if len(range_ok) < len(ranges):
            range_ok.extend([False] * (len(ranges) - len(range_ok)))
    return ranges, range_ok


def _extract_tof_payload(payload: dict[str, Any]) -> dict[str, Any] | None:
    nested = payload.get("tof") or payload.get("tof10120")
    if isinstance(nested, dict):
        return nested
    known_keys = {
        "tof_distance_m",
        "tof_distance_mm",
        "tof_raw_distance_m",
        "tof_raw_distance_mm",
        "tof_filtered_distance_m",
        "tof_altitude_m",
        "tof_usable",
        "tof_confidence",
    }
    if not any(key in payload for key in known_keys):
        return None
    return {
        "distance_m": payload.get("tof_distance_m"),
        "distance_mm": payload.get("tof_distance_mm"),
        "raw_distance_m": payload.get("tof_raw_distance_m"),
        "raw_distance_mm": payload.get("tof_raw_distance_mm"),
        "filtered_distance_m": payload.get("tof_filtered_distance_m"),
        "altitude_m": payload.get("tof_altitude_m"),
        "usable": payload.get("tof_usable", True),
        "confidence": payload.get("tof_confidence", 1.0),
        "reason": payload.get("tof_reason", ""),
    }


def _tof_distance_m(payload: dict[str, Any]) -> float | None:
    value = _first_float(payload, "raw_distance_m", "distance_m", "filtered_distance_m")
    if value is None:
        mm = _first_float(payload, "raw_distance_mm", "distance_mm")
        value = mm / 1000.0 if mm is not None else None
    return _valid_tof_distance(value)


def _valid_tof_distance(value: float | None) -> float | None:
    if value is None:
        return None
    if 0.02 <= value <= 12.0:
        return value
    return None


def _ordered_anchors(anchors: list[dict[str, Any]]) -> list[dict[str, Any]]:
    def key(anchor: dict[str, Any]) -> int:
        token = str(anchor.get("role") or anchor.get("id") or anchor.get("anchor_id") or "").upper()
        if "A1" in token or token in {"ORIGIN", "BASE_TOP"}:
            return 0
        if "A2" in token or token in {"X_AXIS", "X_FLOOR"}:
            return 1
        if "A3" in token or token in {"Y_AXIS", "Y_FLOOR"}:
            return 2
        if "A4" in token or token == "DIAG_TOP":
            return 3
        return 99

    ordered = sorted(anchors, key=key)
    return [anchor for anchor in ordered if key(anchor) < 99][:4]


def _safe_layout_id(layout_id: str) -> str:
    cleaned = "".join(ch for ch in str(layout_id or "runtime_layout") if ch.isalnum() or ch in {"_", "-"})
    return cleaned[:31] or "runtime_layout"
