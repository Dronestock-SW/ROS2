from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass

from ..config import AppConfig
from ..types import EstimationState, MissionState, Waypoint


@dataclass(frozen=True)
class ArrivalStatus:
    inside_radius: bool
    complete: bool
    distance_m: float | None
    z_error_m: float | None


class RouteManager:
    def __init__(self, config: AppConfig) -> None:
        self.config = config
        self._route_key = ""
        self.index = 0
        self._arrival_since: float | None = None

    def sync(self, mission: MissionState) -> None:
        key = _route_key(mission)
        if key != self._route_key:
            self._route_key = key
            self.index = 0
            self._arrival_since = None

    def active(self, mission: MissionState) -> Waypoint | None:
        self.sync(mission)
        if not mission.route_tasks or self.index >= len(mission.route_tasks):
            return None
        return mission.route_tasks[self.index]

    def advance(self, mission: MissionState) -> bool:
        self.sync(mission)
        self.index += 1
        self._arrival_since = None
        return self.index < len(mission.route_tasks)

    def update_arrival(self, *, waypoint: Waypoint | None, estimation: EstimationState, now: float) -> ArrivalStatus:
        if waypoint is None or estimation.current_x_m is None or estimation.current_y_m is None or estimation.current_z_m is None:
            self._arrival_since = None
            return ArrivalStatus(False, False, None, None)

        dx = waypoint.x_m - estimation.current_x_m
        dy = waypoint.y_m - estimation.current_y_m
        distance = (dx * dx + dy * dy) ** 0.5
        z_error = waypoint.z_m - estimation.current_z_m
        radius = waypoint.arrival_radius_m or self.config.waypoint_radius_m
        inside = distance <= radius and abs(z_error) <= self.config.waypoint_z_radius_m
        if inside:
            if self._arrival_since is None:
                self._arrival_since = now
        else:
            self._arrival_since = None

        hold_s = waypoint.hold_s if waypoint.task_type == "hover" else self.config.waypoint_dwell_s
        if waypoint.task_type == "scan":
            hold_s = max(2.0, waypoint.hold_s)
        complete = self._arrival_since is not None and (now - self._arrival_since) >= hold_s
        return ArrivalStatus(inside, complete, distance, z_error)

    def reset_arrival_timer(self) -> None:
        self._arrival_since = None


def _route_key(mission: MissionState) -> str:
    if mission.route_revision:
        return f"{mission.mission_db_id or mission.mission_id}:{mission.route_revision}"
    raw = {
        "mission_id": mission.mission_id,
        "route": [wp.raw or {"x": wp.x_m, "y": wp.y_m, "z": wp.z_m, "type": wp.task_type} for wp in mission.route_tasks],
    }
    return hashlib.sha1(json.dumps(raw, sort_keys=True, default=str).encode("utf-8")).hexdigest()
