#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="${REPO_DIR:-$(cd "${SCRIPT_DIR}/../../.." && pwd)}"
VENV_DIR="${VENV_DIR:-${REPO_DIR}/.venv-companion}"
SERVICE_USER="${SERVICE_USER:-${SUDO_USER:-$(whoami)}}"
ENV_FILE="/etc/dronestock-companion.env"
SERVICE_FILE="/etc/systemd/system/dronestock-companion.service"

if [[ "${EUID}" -ne 0 ]]; then
  echo "Run with sudo: sudo bash tools/companion/deploy/install_pi.sh" >&2
  exit 1
fi

echo "[companion-deploy] repo=${REPO_DIR}"
echo "[companion-deploy] user=${SERVICE_USER}"

apt-get update
apt-get install -y \
  python3-venv \
  python3-pip \
  python3-dev \
  i2c-tools \
  python3-smbus \
  libatlas-base-dev \
  libzbar0 \
  libcamera-tools \
  python3-picamera2 \
  python3-libcamera

usermod -a -G dialout,i2c,video "${SERVICE_USER}" || true

if [[ -f /boot/firmware/config.txt ]] && ! grep -Eq '^\s*enable_uart=1\s*$' /boot/firmware/config.txt; then
  echo "[companion-deploy] UART note: add 'enable_uart=1' to /boot/firmware/config.txt and reboot before using /dev/serial0."
fi
if command -v systemctl >/dev/null 2>&1 && systemctl is-enabled serial-getty@ttyAMA0.service >/dev/null 2>&1; then
  echo "[companion-deploy] UART note: disable the serial console/getty if it owns the GPIO UART."
fi

PY_OK="$(python3 - <<'PY'
import sys
print("ok" if sys.version_info >= (3, 10) else "old")
PY
)"
if [[ "${PY_OK}" != "ok" ]]; then
  echo "Python 3.10 or newer is required. This Pi has: $(python3 --version)" >&2
  echo "Use Raspberry Pi OS Bookworm or install a newer Python before deploying companion." >&2
  exit 1
fi

if [[ ! -d "${VENV_DIR}" ]]; then
  python3 -m venv "${VENV_DIR}" --system-site-packages
fi

"${VENV_DIR}/bin/python" -m pip install --upgrade pip wheel
"${VENV_DIR}/bin/python" -m pip install -r "${REPO_DIR}/requirements-companion.txt"
"${VENV_DIR}/bin/python" -m pip install zxing-cpp || \
  echo "[companion-deploy] optional zxing-cpp install failed; pyzbar/OpenCV QR fallback will be used."

if [[ ! -f "${ENV_FILE}" ]]; then
  install -m 0644 "${SCRIPT_DIR}/companion.env.example" "${ENV_FILE}"
  echo "[companion-deploy] created ${ENV_FILE}; edit it for your ports/server."
fi

sed \
  -e "s#__REPO_DIR__#${REPO_DIR}#g" \
  -e "s#__VENV_DIR__#${VENV_DIR}#g" \
  -e "s#__USER__#${SERVICE_USER}#g" \
  "${SCRIPT_DIR}/dronestock-companion.service" > "${SERVICE_FILE}"

systemctl daemon-reload
systemctl enable dronestock-companion.service

echo "[companion-deploy] installed service."
echo "Edit ${ENV_FILE}, then run:"
echo "  sudo systemctl restart dronestock-companion"
echo "  journalctl -u dronestock-companion -f"
