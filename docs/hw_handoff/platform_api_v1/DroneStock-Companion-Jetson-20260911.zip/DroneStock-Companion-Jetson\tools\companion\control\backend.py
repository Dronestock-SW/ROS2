from __future__ import annotations

from dataclasses import dataclass

from ..config import AppConfig
from ..io.pixhawk_mavlink import PixhawkMavlink
from ..types import (
    ControlMode,
    EstimationState,
    FailureReason,
    FcGuidedProbeResult,
    FlightState,
    MissionFSMResult,
    RCChannels,
    SafetyState,
    SensorSnapshot,
)


@dataclass
class BackendDispatchResult:
    selected_mode: str
    output_sent: bool
    reason: str = ""


class ControlBackendManager:
    def __init__(self, config: AppConfig, pixhawk: PixhawkMavlink) -> None:
        self.config = config
        self.pixhawk = pixhawk
        self.requested_mode = _normalize_mode(config.control_mode)
        self.selected_mode = self.requested_mode
        self.locked_after_arm = False
        self._last_mode_request: str = ""
        self._last_mode_request_t: float = 0.0
        self.last_probe_result = FcGuidedProbeResult(
            requested_mode=self.requested_mode,
            selected_mode=self.selected_mode,
            fc_guided_ok=False,
            fallback_allowed=False,
        )

    def update_selection(self, snapshot: SensorSnapshot, estimation: EstimationState) -> FcGuidedProbeResult:
        if snapshot.fc.armed:
            self.locked_after_arm = True
            return self.last_probe_result
        if self.requested_mode == ControlMode.DRY_RUN.value:
            self.selected_mode = ControlMode.DRY_RUN.value
            self.last_probe_result = FcGuidedProbeResult(
                requested_mode=self.requested_mode,
                selected_mode=self.selected_mode,
                fc_guided_ok=False,
                fallback_allowed=False,
            )
            return self.last_probe_result
        if self.requested_mode == ControlMode.COMPANION_RC.value:
            self.selected_mode = ControlMode.COMPANION_RC.value
            reasons = self._ensure_prearm_fc_mode(snapshot, self.config.companion_rc_flight_mode)
            if reasons:
                self.selected_mode = ControlMode.DRY_RUN.value
            self.last_probe_result = FcGuidedProbeResult(
                requested_mode=self.requested_mode,
                selected_mode=self.selected_mode,
                fc_guided_ok=False,
                fallback_allowed=False,
                reasons=reasons,
            )
            return self.last_probe_result

        self.selected_mode = ControlMode.DRY_RUN.value
        self.last_probe_result = FcGuidedProbeResult(
            requested_mode=self.requested_mode,
            selected_mode=self.selected_mode,
            fc_guided_ok=False,
            fallback_allowed=False,
            reasons=[FailureReason("CONTROL_MODE_UNSUPPORTED", message=f"control_mode={self.requested_mode}")],
        )
        return self.last_probe_result

    def dispatch(
        self,
        *,
        snapshot: SensorSnapshot,
        estimation: EstimationState,
        fsm_result: MissionFSMResult,
        safety: SafetyState,
        final_rc: RCChannels,
    ) -> BackendDispatchResult:
        if self.selected_mode == ControlMode.DRY_RUN.value:
            return BackendDispatchResult(self.selected_mode, True, "dry_run_no_motor_output")
        if self.selected_mode == ControlMode.COMPANION_RC.value:
            if self.config.dry_run_rc:
                return BackendDispatchResult(self.selected_mode, True, "dry_run_rc_no_output")
            if final_rc.disarm_request:
                ok = self.pixhawk.send_rc_override(final_rc)
                self.pixhawk.disarm()
                return BackendDispatchResult(self.selected_mode, ok, "disarm_request")
            nav_ok = self._send_external_nav(snapshot=snapshot, estimation=estimation)
            if not nav_ok and _external_nav_required(fsm_result.state):
                hold_rc = self._external_nav_failed_rc(snapshot=snapshot, estimation=estimation)
                ok = self.pixhawk.send_rc_override(hold_rc)
                return BackendDispatchResult(self.selected_mode, ok, "external_nav_failed_neutral_hold")
            ok = self.pixhawk.send_rc_override(final_rc)
            reason = "loiter_rc_override+external_nav" if nav_ok else "loiter_rc_override_external_nav_failed"
            return BackendDispatchResult(self.selected_mode, ok, reason)
        return BackendDispatchResult(self.selected_mode, False, "unsupported_backend")

    def _send_external_nav(self, *, snapshot: SensorSnapshot, estimation: EstimationState) -> bool:
        ok = True
        pose_sent = False
        distance_sent = False
        if (
            estimation.xy_control_usable and
            estimation.current_x_m is not None and
            estimation.current_y_m is not None and
            estimation.current_z_m is not None
        ):
            pose_sent = True
            vz_mps = 0.0
            if snapshot.tof.usable and snapshot.tof.vertical_speed_mps is not None:
                vz_mps = -snapshot.tof.vertical_speed_mps
            nav_ok = self.pixhawk.send_odometry(
                x_m=estimation.current_x_m,
                y_m=estimation.current_y_m,
                z_m=-estimation.current_z_m,
                vx_mps=estimation.current_vx_mps or 0.0,
                vy_mps=estimation.current_vy_mps or 0.0,
                vz_mps=vz_mps,
                yaw_deg=snapshot.fc.yaw_deg or 0.0,
                quality=100 if estimation.z_control_usable else 85,
            )
            if not nav_ok:
                nav_ok = self.pixhawk.send_vision_position_estimate(
                    x_m=estimation.current_x_m,
                    y_m=estimation.current_y_m,
                    z_m=-estimation.current_z_m,
                    yaw_deg=snapshot.fc.yaw_deg or 0.0,
                )
            ok = nav_ok and ok
        if snapshot.tof.altitude_m is not None and snapshot.tof.usable:
            distance_sent = True
            ok = self.pixhawk.send_distance_sensor(distance_m=snapshot.tof.altitude_m) and ok
        if self.config.require_tof:
            return ok and pose_sent and distance_sent
        return ok and pose_sent

    def _ensure_prearm_fc_mode(self, snapshot: SensorSnapshot, mode_name: str) -> list[FailureReason]:
        desired = str(mode_name or "").strip().upper()
        if not desired or snapshot.fc.armed:
            return []
        if desired == "ALT_HOLD":
            return [
                FailureReason(
                    "ALT_HOLD_FORBIDDEN",
                    message="ALT_HOLD is forbidden for autonomous companion control; use LOITER",
                )
            ]
        if _mode_matches(snapshot.fc.mode, desired):
            self._last_mode_request = ""
            self._last_mode_request_t = 0.0
            return []
        if not snapshot.fc.connected:
            return [FailureReason("FC_LINK_TIMEOUT", message="Pixhawk heartbeat is not available")]
        if self._should_send_mode_request(snapshot, desired):
            if not self.pixhawk.set_flight_mode(desired):
                code = f"{desired}_MODE_REJECTED" if desired else "FC_MODE_REJECTED"
                message = f"FC rejected or did not expose {desired} mode"
                return [FailureReason(code, message=message)]
            self._last_mode_request = desired
            self._last_mode_request_t = snapshot.now
        return [
            FailureReason(
                f"{desired}_MODE_PENDING",
                message=f"{desired} command sent; waiting for FC heartbeat to confirm mode",
            )
        ]

    def arm_allowed(self, snapshot: SensorSnapshot) -> bool:
        return not self.arm_block_reasons(snapshot)

    def arm_block_reasons(self, snapshot: SensorSnapshot) -> list[str]:
        reasons: list[str] = []
        if self.selected_mode != ControlMode.COMPANION_RC.value:
            reasons.append(f"control_backend_not_ready:{self.selected_mode}")
        for reason in self.last_probe_result.reasons:
            reasons.append(f"control_backend:{reason.code}")
        desired = str(self.config.companion_rc_flight_mode or "").strip().upper()
        if desired == "ALT_HOLD":
            reasons.append("ALT_HOLD_FORBIDDEN")
        elif desired and not _mode_matches(snapshot.fc.mode, desired):
            reasons.append(f"fc_mode_not_{desired}:{snapshot.fc.mode or 'unknown'}")
        return reasons

    def _should_send_mode_request(self, snapshot: SensorSnapshot, desired: str) -> bool:
        return self._last_mode_request != desired or snapshot.now - self._last_mode_request_t >= 1.0

    def _external_nav_failed_rc(self, *, snapshot: SensorSnapshot, estimation: EstimationState) -> RCChannels:
        airborne = False
        if estimation.current_z_m is not None and estimation.current_z_m > 0.12:
            airborne = True
        if snapshot.tof.altitude_m is not None and snapshot.tof.altitude_m > 0.12:
            airborne = True
        throttle = self.config.hover_throttle_pwm if snapshot.fc.armed and airborne else self.config.throttle_min_pwm
        return RCChannels(throttle=throttle, reason="external_nav_failed_neutral_hold")


def _normalize_mode(value: str) -> str:
    lowered = str(value or "").strip().lower()
    if lowered == ControlMode.DRY_RUN.value:
        return lowered
    return ControlMode.COMPANION_RC.value


def _mode_matches(current: str, desired: str) -> bool:
    def normalize(value: str) -> str:
        return str(value or "").strip().upper().replace(" ", "_")

    return normalize(current) == normalize(desired)


def _external_nav_required(state: FlightState) -> bool:
    return state in {
        FlightState.WAIT_FOR_TAKEOFF,
        FlightState.MOVE_TO_WAYPOINT,
        FlightState.WAIT_FOR_ARRIVAL,
        FlightState.SCAN,
        FlightState.RETURN,
        FlightState.DEGRADED_HOVER,
    }
