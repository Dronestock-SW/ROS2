#!/usr/bin/env python3
from __future__ import annotations

import argparse
import sys
import time

try:
    from pymavlink import mavutil
except ImportError:
    mavutil = None


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Check Pixhawk MAVLink heartbeat over Raspberry Pi UART")
    parser.add_argument("--device", default="/dev/serial0", help="Pi UART device connected to Pixhawk TELEM TX/RX")
    parser.add_argument("--baud", type=int, default=57600, help="MAVLink serial baudrate")
    parser.add_argument("--timeout", type=float, default=10.0, help="Heartbeat timeout seconds")
    args = parser.parse_args(argv)

    if mavutil is None:
        print("ERROR: pymavlink is not installed. Run deploy/install_pi.sh first.", file=sys.stderr)
        return 2

    print(f"[uart-check] opening {args.device} baud={args.baud}")
    try:
        master = mavutil.mavlink_connection(args.device, baud=args.baud, autoreconnect=False)
    except Exception as exc:
        print(f"ERROR: failed to open {args.device}: {exc}", file=sys.stderr)
        return 2

    try:
        started = time.monotonic()
        heartbeat = master.wait_heartbeat(timeout=args.timeout)
        elapsed = time.monotonic() - started
        if heartbeat is None:
            print(f"ERROR: no MAVLink heartbeat within {args.timeout:.1f}s", file=sys.stderr)
            return 1

        try:
            mode = mavutil.mode_string_v10(heartbeat)
        except Exception:
            mode = str(getattr(heartbeat, "custom_mode", "unknown"))
        armed = bool(heartbeat.base_mode & mavutil.mavlink.MAV_MODE_FLAG_SAFETY_ARMED)
        print("[uart-check] heartbeat OK")
        print(f"  target_system={master.target_system}")
        print(f"  target_component={master.target_component}")
        print(f"  autopilot={heartbeat.autopilot}")
        print(f"  mode={mode}")
        print(f"  armed={armed}")
        print(f"  elapsed_s={elapsed:.2f}")
        return 0
    finally:
        try:
            master.close()
        except Exception:
            pass


if __name__ == "__main__":
    raise SystemExit(main())
