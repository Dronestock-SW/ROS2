from __future__ import annotations

from dataclasses import replace

from ..config import AppConfig
from ..types import EstimationState, FlightState, RCChannels, SafetyState, SensorSnapshot, TakeoffPhase, clamp


class RCArbiter:
    """Final RC safety gate.

    All controller outputs must pass through this class before Pixhawk output.
    """

    def __init__(self, config: AppConfig) -> None:
        self.config = config
        self._last_final = RCChannels()
        self._last_t: float | None = None
        self.last_clamp_reason = "init"

    def apply(
        self,
        *,
        requested_rc: RCChannels,
        state: FlightState,
        phase: TakeoffPhase | None,
        snapshot: SensorSnapshot,
        estimation: EstimationState,
        safety: SafetyState,
    ) -> RCChannels:
        now = snapshot.now
        rc = requested_rc
        reasons: list[str] = []

        if safety.emergency_cut or state == FlightState.EMERGENCY_CUT:
            final = RCChannels(throttle=self.config.throttle_min_pwm, disarm_request=True, reason="emergency_cut")
            self._last_final = final
            self._last_t = now
            self.last_clamp_reason = "emergency_cut"
            return final

        if state in {
            FlightState.SYSTEM_CHECK,
            FlightState.READY,
            FlightState.ARMING,
            FlightState.TAKEOFF_READY,
            FlightState.TAKEOFF_INIT,
            FlightState.POWER_OFF,
        }:
            rc = RCChannels(throttle=self.config.throttle_min_pwm, reason=f"{state.value}_throttle_lock")
            reasons.append("preflight_throttle_lock")

        if state == FlightState.WAIT_FOR_TAKEOFF and phase == TakeoffPhase.TAKEOFF_ARMED_IDLE:
            rc = replace(rc, throttle=self.config.throttle_min_pwm, reason="takeoff_armed_idle_throttle_lock")
            reasons.append("takeoff_boost_not_started")

        if state in {
            FlightState.MOVE_TO_WAYPOINT,
            FlightState.WAIT_FOR_ARRIVAL,
            FlightState.SCAN,
            FlightState.RETURN,
        } and not estimation.xy_control_usable:
            rc = replace(rc, roll=1500, pitch=1500, yaw=1500)
            reasons.append("xy_unusable_neutral")

        if state == FlightState.DEGRADED_HOVER:
            rc = replace(rc, roll=1500, pitch=1500, yaw=1500)
            reasons.append("degraded_hover_neutral_xy")

        if state == FlightState.FAILSAFE_LAND or safety.failsafe_land:
            throttle = self._failsafe_descent(now)
            rc = RCChannels(roll=1500, pitch=1500, throttle=throttle, yaw=1500, reason="failsafe_land")
            reasons.append("failsafe_land_descent")

        if state == FlightState.LAND:
            rc = replace(rc, roll=1500, pitch=1500, yaw=1500)
            reasons.append("landing_neutral_xy")

        rc = rc.clamped(
            roll_limit=self.config.xy_roll_limit_pwm,
            pitch_limit=self.config.xy_pitch_limit_pwm,
            yaw_limit=self.config.yaw_limit_pwm,
            throttle_min=self.config.throttle_min_pwm,
            throttle_max=self.config.throttle_max_pwm,
        )
        rc = self._rate_limit_throttle(rc, now, force_low=state in {
            FlightState.SYSTEM_CHECK,
            FlightState.READY,
            FlightState.ARMING,
            FlightState.TAKEOFF_READY,
            FlightState.TAKEOFF_INIT,
            FlightState.POWER_OFF,
        })

        self._last_final = rc
        self._last_t = now
        self.last_clamp_reason = ",".join(reasons) if reasons else "none"
        return replace(rc, reason=f"{rc.reason};arbiter={self.last_clamp_reason}")

    def _rate_limit_throttle(self, rc: RCChannels, now: float, *, force_low: bool = False) -> RCChannels:
        if force_low:
            return replace(rc, throttle=self.config.throttle_min_pwm)
        if self._last_t is None:
            return rc
        dt = max(0.0, now - self._last_t)
        limit = self.config.throttle_rate_limit_pwm_s * dt
        lower = self._last_final.throttle - limit
        upper = self._last_final.throttle + limit
        return replace(rc, throttle=int(clamp(rc.throttle, lower, upper)))

    def _failsafe_descent(self, now: float) -> int:
        if self._last_t is None:
            return min(self._last_final.throttle, self.config.hover_throttle_pwm)
        dt = max(0.0, now - self._last_t)
        throttle = self._last_final.throttle - self.config.failsafe_descent_pwm_s * dt
        return int(clamp(throttle, self.config.throttle_min_pwm, self.config.hover_throttle_pwm))

