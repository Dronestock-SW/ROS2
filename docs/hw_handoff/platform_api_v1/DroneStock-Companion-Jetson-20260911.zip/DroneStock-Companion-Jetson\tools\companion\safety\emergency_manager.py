from __future__ import annotations

from ..config import AppConfig
from ..types import EstimationState, FlightState, SafetyLevel, SafetyState, SensorSnapshot
from .imu_safety_monitor import IMUSafetyMonitor
from .sensor_failsafe import SensorFailsafe, max_level


class EmergencyManager:
    def __init__(self, config: AppConfig) -> None:
        self.config = config
        self.imu_monitor = IMUSafetyMonitor(config)
        self.sensor_failsafe = SensorFailsafe(config)

    def evaluate(self, snapshot: SensorSnapshot, estimation: EstimationState, state: FlightState) -> SafetyState:
        imu_result = self.imu_monitor.evaluate(snapshot.imu, snapshot.now)
        sensor_result = self.sensor_failsafe.evaluate(snapshot, estimation, state)

        level = max_level(imu_result.level, sensor_result.level)
        reasons = [reason for reason in (imu_result.reasons + sensor_result.reasons) if reason != "ok"]

        action = snapshot.mission.control_action
        if action == "land":
            level = max_level(level, SafetyLevel.FAILSAFE_LAND)
            reasons.append("manual_land")

        emergency = level == SafetyLevel.EMERGENCY_CUT
        failsafe = level == SafetyLevel.FAILSAFE_LAND
        degraded = level == SafetyLevel.DEGRADED_HOVER
        return SafetyState(
            level=level,
            reasons=reasons or ["ok"],
            degraded_hover=degraded,
            failsafe_land=failsafe,
            emergency_cut=emergency,
            disarm_request=emergency,
        )
