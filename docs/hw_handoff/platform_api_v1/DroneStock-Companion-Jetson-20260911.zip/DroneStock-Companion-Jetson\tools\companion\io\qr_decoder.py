from __future__ import annotations

from typing import Callable

from ..types import QRDecodeResult

try:  # pragma: no cover - optional runtime dependency
    import cv2
    import numpy as np
except ImportError:  # pragma: no cover
    cv2 = None
    np = None


DecodeFn = Callable[["np.ndarray"], list[str]]


class QRDecoder:
    """Multi-pass QR decoder for camera frames."""

    def __init__(self) -> None:
        self._decoders: list[tuple[str, DecodeFn]] = []
        self._cv2_qr = cv2.QRCodeDetector() if cv2 is not None else None
        self._load_zxing()
        self._load_pyzbar()
        if self._cv2_qr is not None:
            self._decoders.append(("cv2", self._decode_cv2))

    @property
    def available(self) -> bool:
        return cv2 is not None and np is not None and bool(self._decoders)

    def decode_frame(self, frame: "np.ndarray") -> QRDecodeResult:
        if not self.available:
            return QRDecodeResult(decoder="unavailable")

        gray = _to_gray(frame)
        variants = _image_variants(gray)
        for image in variants:
            result = self._decode_with_all(image)
            if result.text:
                return result

        for roi in _find_qr_rois(gray):
            for image in _image_variants(roi):
                result = self._decode_with_all(image, suffix="/roi")
                if result.text:
                    return result

        return QRDecodeResult()

    def _decode_with_all(self, gray: "np.ndarray", suffix: str = "") -> QRDecodeResult:
        for name, decoder in self._decoders:
            try:
                values = decoder(gray)
            except Exception:
                continue
            for value in values:
                text = str(value or "").strip()
                if text:
                    return QRDecodeResult(text=text, decoder=f"{name}{suffix}", confidence=1.0)
        return QRDecodeResult()

    def _load_zxing(self) -> None:
        try:
            import zxingcpp  # type: ignore[import-not-found]

            qr_formats = (
                zxingcpp.BarcodeFormat.QRCode
                | zxingcpp.BarcodeFormat.MicroQRCode
                | zxingcpp.BarcodeFormat.RMQRCode
            )

            def decode(gray: "np.ndarray") -> list[str]:
                return [result.text for result in zxingcpp.read_barcodes(gray, formats=qr_formats) if result.text]

            self._decoders.append(("zxingcpp", decode))
        except Exception:
            return

    def _load_pyzbar(self) -> None:
        try:
            from pyzbar import pyzbar  # type: ignore[import-not-found]

            def decode(gray: "np.ndarray") -> list[str]:
                return [obj.data.decode("utf-8", errors="replace") for obj in pyzbar.decode(gray) if obj.data]

            self._decoders.append(("pyzbar", decode))
        except Exception:
            return

    def _decode_cv2(self, gray: "np.ndarray") -> list[str]:
        if self._cv2_qr is None:
            return []
        data, _, _ = self._cv2_qr.detectAndDecode(gray)
        return [data] if data else []


def _to_gray(frame: "np.ndarray") -> "np.ndarray":
    if len(frame.shape) == 2:
        return frame
    return cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)


def _image_variants(gray: "np.ndarray") -> list["np.ndarray"]:
    variants = [gray]
    try:
        variants.append(cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2))
        variants.append(cv2.equalizeHist(gray))
    except Exception:
        pass
    return variants


def _find_qr_rois(gray: "np.ndarray") -> list["np.ndarray"]:
    h, w = gray.shape[:2]
    small = cv2.resize(gray, None, fx=0.5, fy=0.5)
    blurred = cv2.GaussianBlur(small, (3, 3), 0)
    edges = cv2.Canny(blurred, 40, 130)
    dilated = cv2.dilate(edges, np.ones((2, 2), np.uint8), iterations=1)
    contours, _ = cv2.findContours(dilated, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    rois: list["np.ndarray"] = []
    for contour in sorted(contours, key=cv2.contourArea, reverse=True)[:8]:
        area = cv2.contourArea(contour)
        if area < 400 or area > small.shape[0] * small.shape[1] * 0.7:
            continue
        perimeter = cv2.arcLength(contour, True)
        approx = cv2.approxPolyDP(contour, 0.05 * perimeter, True)
        if len(approx) != 4 or not cv2.isContourConvex(approx):
            continue
        x, y, rw, rh = cv2.boundingRect(approx)
        ratio = rw / max(rh, 1)
        if not 0.6 < ratio < 1.7:
            continue
        x1 = max(int(x / 0.5) - int(rw * 0.2), 0)
        y1 = max(int(y / 0.5) - int(rh * 0.2), 0)
        x2 = min(int((x + rw) / 0.5) + int(rw * 0.2), w)
        y2 = min(int((y + rh) / 0.5) + int(rh * 0.2), h)
        crop = gray[y1:y2, x1:x2]
        if crop.shape[0] < 40 or crop.shape[1] < 40:
            continue
        scale = min(3.0, 360.0 / max(crop.shape[0], crop.shape[1]))
        if scale > 1.0:
            crop = cv2.resize(crop, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)
        rois.append(crop)
    return rois
