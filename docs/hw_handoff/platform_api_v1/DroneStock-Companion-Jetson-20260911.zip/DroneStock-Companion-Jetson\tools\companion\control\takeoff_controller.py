from __future__ import annotations

from dataclasses import dataclass

from ..config import AppConfig
from ..types import ControllerStatus, EstimationState, IMUState, RCChannels, SensorSnapshot, TakeoffPhase, clamp
from .altitude_controller import AltitudeController


@dataclass(frozen=True)
class TakeoffOutput:
    rc: RCChannels
    status: ControllerStatus


class TakeoffController:
    def __init__(self, config: AppConfig, altitude_controller: AltitudeController) -> None:
        self.config = config
        self.altitude_controller = altitude_controller
        self.phase = TakeoffPhase.TAKEOFF_ARMED_IDLE
        self.phase_since: float | None = None
        self._last_t: float | None = None
        self._previous_throttle = float(config.takeoff_start_pwm)
        self._liftoff_pwm: float | None = None
        self._liftoff_vote_since: float | None = None
        self._settle_since: float | None = None
        self._hover_since: float | None = None
        self._xy_stable_since: float | None = None
        self._fc_alt_baseline: float | None = None
        self._uwb_z_baseline: float | None = None
        self._events: list[str] = []

    def reset(self, snapshot: SensorSnapshot | None = None) -> None:
        self.altitude_controller.reset()
        self.phase = TakeoffPhase.TAKEOFF_ARMED_IDLE
        self.phase_since = None
        self._last_t = None
        self._previous_throttle = float(self.config.takeoff_start_pwm)
        self._liftoff_pwm = None
        self._liftoff_vote_since = None
        self._settle_since = None
        self._hover_since = None
        self._xy_stable_since = None
        self._events = []
        self._fc_alt_baseline = snapshot.fc.relative_alt_m if snapshot else None
        self._uwb_z_baseline = snapshot.uwb.z_control_m if snapshot else None

    def pop_events(self) -> list[str]:
        events = self._events
        self._events = []
        return events

    def status(self) -> ControllerStatus:
        return ControllerStatus(takeoff_phase=self.phase, takeoff_complete=False)

    def compute(self, *, snapshot: SensorSnapshot, estimation: EstimationState) -> TakeoffOutput:
        now = snapshot.now
        if self.phase_since is None:
            self.phase_since = now
        dt = 0.0 if self._last_t is None else max(1e-3, now - self._last_t)
        self._last_t = now

        if self.phase == TakeoffPhase.TAKEOFF_ARMED_IDLE:
            if now - self.phase_since >= self.config.takeoff_armed_idle_s:
                self._enter(TakeoffPhase.TAKEOFF_BOOST, now)
            else:
                return self._output(self.config.takeoff_start_pwm, False, "takeoff_armed_idle")

        if self.phase == TakeoffPhase.TAKEOFF_BOOST:
            throttle = self._ramp_boost(dt)
            self._previous_throttle = throttle
            if self._liftoff_votes(snapshot, estimation) >= 2:
                if self._liftoff_vote_since is None:
                    self._liftoff_vote_since = now
                if now - self._liftoff_vote_since >= self.config.liftoff_confirm_s:
                    self._liftoff_pwm = throttle
                    self._events.append("LIFTOFF_DETECTED")
                    self._enter(TakeoffPhase.LIFTOFF_CONFIRM, now)
            else:
                self._liftoff_vote_since = None
            return self._output(int(throttle), False, "takeoff_boost")

        if self.phase == TakeoffPhase.LIFTOFF_CONFIRM:
            throttle = self._liftoff_pwm or self._previous_throttle
            if now - (self.phase_since or now) >= 0.20:
                self._enter(TakeoffPhase.CLIMB_CAPTURE, now)
            return self._output(int(throttle), False, "liftoff_confirm")

        if self.phase == TakeoffPhase.CLIMB_CAPTURE:
            throttle = min((self._liftoff_pwm or self._previous_throttle) + 8.0, self.config.takeoff_max_pwm)
            z = estimation.current_z_m
            if (now - (self.phase_since or now) >= self.config.climb_capture_hold_s) or (z is not None and z >= self.config.takeoff_target_z_m - 0.08):
                self._enter(TakeoffPhase.ALTITUDE_HOLD_SETTLE, now)
            self._previous_throttle = throttle
            return self._output(int(throttle), False, "climb_capture")

        if self.phase == TakeoffPhase.ALTITUDE_HOLD_SETTLE:
            throttle = self.altitude_controller.compute(target_z_m=self.config.takeoff_target_z_m, estimation=estimation, now=now)
            self._previous_throttle = throttle
            if estimation.current_z_m is not None and abs(self.config.takeoff_target_z_m - estimation.current_z_m) <= 0.12:
                if self._settle_since is None:
                    self._settle_since = now
                if now - self._settle_since >= 0.8:
                    self._enter(TakeoffPhase.INITIAL_HOVER, now)
            else:
                self._settle_since = None
            return self._output(throttle, False, "altitude_hold_settle")

        if self.phase == TakeoffPhase.INITIAL_HOVER:
            throttle = self.altitude_controller.compute(target_z_m=self.config.takeoff_target_z_m, estimation=estimation, now=now)
            stable = _hover_stable(snapshot.imu, estimation, self.config.takeoff_target_z_m)
            if stable:
                if self._hover_since is None:
                    self._hover_since = now
                if now - self._hover_since >= self.config.initial_hover_s:
                    self._enter(TakeoffPhase.XY_STABILITY_CHECK, now)
            else:
                self._hover_since = None
            return self._output(throttle, False, "initial_hover")

        if self.phase == TakeoffPhase.XY_STABILITY_CHECK:
            throttle = self.altitude_controller.compute(target_z_m=self.config.takeoff_target_z_m, estimation=estimation, now=now)
            stable = (
                estimation.xy_control_usable
                and snapshot.uwb.age_ms is not None
                and snapshot.uwb.age_ms <= self.config.uwb_max_age_ms
                and snapshot.uwb.tag_layout_synced
                and snapshot.uwb.z_control_usable
                and _imu_stable(snapshot.imu)
            )
            if stable:
                if self._xy_stable_since is None:
                    self._xy_stable_since = now
                if now - self._xy_stable_since >= self.config.xy_stability_s:
                    return self._output(throttle, True, "xy_stability_complete")
            else:
                self._xy_stable_since = None
            return self._output(throttle, False, "xy_stability_check")

        return self._output(self.config.takeoff_start_pwm, False, "takeoff_unknown_phase")

    def _enter(self, phase: TakeoffPhase, now: float) -> None:
        self.phase = phase
        self.phase_since = now
        if phase == TakeoffPhase.TAKEOFF_BOOST:
            self._events.append("TAKEOFF_BOOST_START")
        elif phase == TakeoffPhase.CLIMB_CAPTURE:
            self._events.append("CLIMB_CAPTURE_START")
        elif phase == TakeoffPhase.INITIAL_HOVER:
            self._events.append("INITIAL_HOVER_START")
        elif phase == TakeoffPhase.XY_STABILITY_CHECK:
            self._events.append("XY_STABILITY_CHECK_START")

    def _ramp_boost(self, dt: float) -> float:
        if self._previous_throttle < self.config.takeoff_prespin_pwm:
            rate = self.config.takeoff_fast_ramp_pwm_s
            target = self.config.takeoff_prespin_pwm
        else:
            rate = self.config.takeoff_slow_ramp_pwm_s
            target = self.config.takeoff_max_pwm
        return min(target, self._previous_throttle + rate * dt)

    def _liftoff_votes(self, snapshot: SensorSnapshot, estimation: EstimationState) -> int:
        votes = 0
        if snapshot.tof.altitude_m is not None and snapshot.tof.altitude_m > 0.08:
            votes += 1
        if snapshot.tof.vertical_speed_mps is not None and snapshot.tof.vertical_speed_mps > 0.05:
            votes += 1
        if snapshot.imu.motion_state == "LIFTOFF_CANDIDATE" and _imu_stable(snapshot.imu):
            votes += 1
        if snapshot.fc.relative_alt_m is not None and self._fc_alt_baseline is not None:
            if snapshot.fc.relative_alt_m - self._fc_alt_baseline > 0.08:
                votes += 1
        if snapshot.uwb.z_control_m is not None and self._uwb_z_baseline is not None:
            if snapshot.uwb.z_control_m - self._uwb_z_baseline > 0.08:
                votes += 1
        if estimation.current_z_m is not None and estimation.current_z_m > 0.12:
            votes += 1
        return votes

    def _output(self, throttle: int, complete: bool, reason: str) -> TakeoffOutput:
        return TakeoffOutput(
            rc=RCChannels(throttle=int(throttle), reason=reason),
            status=ControllerStatus(takeoff_phase=self.phase, takeoff_complete=complete),
        )


def _imu_stable(imu: IMUState) -> bool:
    if not imu.usable or imu.roll_deg is None or imu.pitch_deg is None or imu.yaw_rate_dps is None:
        return False
    rate = max(abs(imu.roll_rate_dps or 0.0), abs(imu.pitch_rate_dps or 0.0), abs(imu.yaw_rate_dps))
    return (
        max(abs(imu.roll_deg), abs(imu.pitch_deg)) <= 12.0
        and rate <= 120.0
        and not imu.shock_detected
    )


def _hover_stable(imu: IMUState, estimation: EstimationState, target_z_m: float) -> bool:
    if estimation.current_z_m is None:
        return False
    return abs(target_z_m - estimation.current_z_m) <= 0.10 and _imu_stable(imu)
