"""Safety monitors and emergency arbitration."""

