from __future__ import annotations

import datetime as _dt
import threading
import time
import uuid
from dataclasses import replace
from typing import Any

from ..config import AppConfig
from ..types import MissionState, QRScanState, QRScanStatus, Waypoint
from .offline_scan_buffer import OfflineScanBuffer
from .qr_decoder import QRDecoder
from .server_client import ServerClient

try:  # pragma: no cover - hardware/runtime dependency
    import cv2
except ImportError:  # pragma: no cover
    cv2 = None


class QRCameraScanner:
    """CSI/V4L2 camera QR scan pipeline.

    The scanner is active only while the mission FSM is in `SCAN`. A successful
    server upload or offline buffer write marks the scan complete.
    """

    def __init__(self, *, config: AppConfig, server: ServerClient) -> None:
        self.config = config
        self.server = server
        self.decoder = QRDecoder()
        self.buffer = OfflineScanBuffer(config.qr_buffer_path)
        self._lock = threading.Lock()
        self._state = QRScanState(status=QRScanStatus.IDLE if config.qr_enabled else QRScanStatus.DISABLED)
        self._active_context: dict[str, Any] | None = None
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()
        self._last_flush = 0.0
        self._last_qr_text = ""
        self._last_qr_at = 0.0

    def start(self) -> None:
        if not self.config.qr_enabled:
            return
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, name="qr-camera-scanner", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()

    def latest(self) -> QRScanState:
        with self._lock:
            return self._state

    def request_scan(self, *, mission: MissionState, waypoint: Waypoint | None, drone_name: str = "") -> QRScanState:
        if not self.config.qr_enabled:
            return QRScanState(status=QRScanStatus.DISABLED, last_error="qr_disabled")
        waypoint_id = waypoint.point_id if waypoint else ""
        mission_id = mission.mission_id
        key = f"{mission_id}|{waypoint_id}"
        with self._lock:
            if self._active_context and self._active_context.get("key") == key:
                return self._state
            label_point_id = _int_or_none((waypoint.raw or {}).get("label_point_id") if waypoint else None)
            self._active_context = {
                "key": key,
                "mission_id": mission.mission_db_id,
                "mission_code": mission.mission_code or mission_id,
                "waypoint_id": waypoint_id,
                "label_point_id": label_point_id,
                "drone_name": drone_name,
                "started_at": time.monotonic(),
                "note": f"waypoint={waypoint_id}" if waypoint_id else "",
            }
            self._state = QRScanState(
                status=QRScanStatus.SCANNING,
                active=True,
                waypoint_id=waypoint_id,
                mission_id=mission_id,
                pending_buffer_count=self.buffer.count(),
                updated_monotonic=time.monotonic(),
            )
            return self._state

    def cancel_scan(self) -> None:
        with self._lock:
            self._active_context = None
            self._state = QRScanState(
                status=QRScanStatus.IDLE if self.config.qr_enabled else QRScanStatus.DISABLED,
                pending_buffer_count=self.buffer.count(),
                updated_monotonic=time.monotonic(),
            )

    def _run(self) -> None:  # pragma: no cover - integration/hardware loop
        if not self.decoder.available:
            self._set_state(status=QRScanStatus.FAILED, error="qr_decoder_unavailable", active=False)
            return

        camera = _open_camera(self.config)
        if camera is None:
            self._set_state(status=QRScanStatus.FAILED, error="camera_open_failed", active=False)
            return

        try:
            while not self._stop.is_set():
                now = time.monotonic()
                self._flush_buffer_if_due(now)
                context = self._context()
                if context is None:
                    time.sleep(0.1)
                    continue

                if now - float(context.get("started_at") or now) > self.config.qr_scan_timeout_s:
                    self._set_state(status=QRScanStatus.FAILED, error="qr_scan_timeout", active=True, context=context)
                    time.sleep(0.2)
                    continue

                ok, frame = camera.read()
                if not ok or frame is None:
                    self._set_state(status=QRScanStatus.FAILED, error="camera_frame_failed", active=True, context=context)
                    time.sleep(0.1)
                    continue

                decoded = self.decoder.decode_frame(frame)
                if not decoded.text:
                    time.sleep(0.03)
                    continue

                if decoded.text == self._last_qr_text and now - self._last_qr_at < self.config.qr_scan_cooldown_s:
                    time.sleep(0.1)
                    continue
                self._last_qr_text = decoded.text
                self._last_qr_at = now
                self._upload_or_buffer(decoded.text, decoded.decoder, context)
        finally:
            camera.close()

    def _upload_or_buffer(self, qr_text: str, decoder: str, context: dict[str, Any]) -> None:
        client_scan_id = str(uuid.uuid4())
        scanned_at_iso = _dt.datetime.now(_dt.timezone.utc).isoformat()
        payload: dict[str, Any] = {
            "client_scan_id": client_scan_id,
            "raw_qr_data": qr_text,
            "drone_name": context.get("drone_name") or "",
            "mission_code": context.get("mission_code") or "",
            "scan_source": "wifi",
            "scanned_at_iso": scanned_at_iso,
            "note": context.get("note") or "",
        }
        if context.get("mission_id") is not None:
            payload["mission_id"] = context["mission_id"]
        if context.get("label_point_id") is not None:
            payload["label_point_id"] = context["label_point_id"]

        result: dict[str, Any] = {"ok": False}
        for attempt in range(1, self.config.qr_upload_retry_count + 1):
            result = self.server.upload_scan_payload(payload)
            if result.get("ok"):
                accepted = bool(result.get("accepted", False))
                status = QRScanStatus.UPLOADED if accepted else QRScanStatus.REJECTED
                complete = accepted
                self._set_state(
                    status=status,
                    active=False if complete else True,
                    complete=complete,
                    context=context,
                    client_scan_id=client_scan_id,
                    qr_text=qr_text,
                    decoder=decoder,
                    accepted=accepted,
                    error="" if accepted else str(result.get("rejection_code") or "scan_rejected"),
                )
                if complete:
                    self._clear_context(context)
                return
            time.sleep(0.25 * attempt)

        buffered_payload = dict(payload)
        buffered_payload["scan_source"] = "offline"
        buffered_payload["attempts"] = 0
        buffered_payload["last_error"] = result.get("error") or "upload_failed"
        self.buffer.push(buffered_payload)
        self._set_state(
            status=QRScanStatus.BUFFERED,
            active=False,
            complete=True,
            context=context,
            client_scan_id=client_scan_id,
            qr_text=qr_text,
            decoder=decoder,
            accepted=None,
            buffered=True,
            error="buffered_for_deferred_upload",
        )
        self._clear_context(context)

    def _flush_buffer_if_due(self, now: float) -> None:
        if now - self._last_flush < self.config.qr_buffer_flush_s:
            return
        self._last_flush = now
        self.buffer.flush(self.server.upload_scan_payload)
        with self._lock:
            self._state = replace(self._state, pending_buffer_count=self.buffer.count(), updated_monotonic=now)

    def _context(self) -> dict[str, Any] | None:
        with self._lock:
            return dict(self._active_context) if self._active_context is not None else None

    def _clear_context(self, context: dict[str, Any]) -> None:
        with self._lock:
            if self._active_context and self._active_context.get("key") == context.get("key"):
                self._active_context = None

    def _set_state(
        self,
        *,
        status: QRScanStatus,
        error: str = "",
        active: bool = False,
        complete: bool = False,
        context: dict[str, Any] | None = None,
        client_scan_id: str = "",
        qr_text: str = "",
        decoder: str = "",
        accepted: bool | None = None,
        buffered: bool = False,
    ) -> None:
        with self._lock:
            self._state = QRScanState(
                status=status,
                active=active,
                complete=complete,
                client_scan_id=client_scan_id,
                qr_text=qr_text,
                decoder=decoder,
                waypoint_id=str((context or {}).get("waypoint_id") or ""),
                mission_id=str((context or {}).get("mission_id") or ""),
                accepted=accepted,
                buffered=buffered,
                pending_buffer_count=self.buffer.count(),
                last_error=error,
                updated_monotonic=time.monotonic(),
            )


class _OpenCVCamera:
    def __init__(self, source: int | str, width: int, height: int) -> None:
        if cv2 is None:
            raise RuntimeError("opencv_missing")
        self._cap = cv2.VideoCapture(source)
        self._cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
        self._cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
        self._cap.set(cv2.CAP_PROP_AUTOFOCUS, 1)

    def read(self) -> tuple[bool, Any]:
        return self._cap.read()

    def close(self) -> None:
        self._cap.release()


class _Picamera2Camera:
    def __init__(self, width: int, height: int) -> None:
        from picamera2 import Picamera2  # type: ignore[import-not-found]

        self._picam = Picamera2()
        config = self._picam.create_video_configuration(main={"size": (width, height), "format": "RGB888"})
        self._picam.configure(config)
        self._picam.start()
        time.sleep(0.5)

    def read(self) -> tuple[bool, Any]:
        frame = self._picam.capture_array()
        if cv2 is not None:
            frame = cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)
        return True, frame

    def close(self) -> None:
        self._picam.stop()


def _open_camera(config: AppConfig) -> Any | None:  # pragma: no cover - hardware path
    backend = config.qr_camera_backend.strip().lower()
    if backend in {"picamera2", "csi", "libcamera"}:
        try:
            return _Picamera2Camera(config.qr_camera_width, config.qr_camera_height)
        except Exception:
            if backend != "picamera2":
                return None
    source = _camera_source(config.qr_camera_source)
    try:
        return _OpenCVCamera(source, config.qr_camera_width, config.qr_camera_height)
    except Exception:
        return None


def _camera_source(raw: str) -> int | str:
    text = str(raw or "0").strip()
    try:
        return int(text)
    except ValueError:
        return text


def _int_or_none(value: Any) -> int | None:
    try:
        if value in (None, ""):
            return None
        return int(value)
    except (TypeError, ValueError):
        return None
