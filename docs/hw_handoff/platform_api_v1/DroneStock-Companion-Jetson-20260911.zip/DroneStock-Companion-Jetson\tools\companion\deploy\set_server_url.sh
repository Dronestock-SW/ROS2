#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PREPARED_ENV="${SCRIPT_DIR}/companion.env.local"
TARGET_ENV="/etc/dronestock-companion.env"

if [[ "${EUID}" -ne 0 ]]; then
  echo "Run with sudo: sudo bash tools/companion/deploy/set_server_url.sh" >&2
  exit 1
fi

if [[ ! -f "${PREPARED_ENV}" ]]; then
  echo "Prepared LAN configuration is missing: ${PREPARED_ENV}" >&2
  exit 1
fi

SERVER_URL="$(sed -n 's/^DRONESTOCK_SERVER_URL=//p' "${PREPARED_ENV}" | head -n 1)"
if [[ ! "${SERVER_URL}" =~ ^https?://[^[:space:]]+$ ]]; then
  echo "Invalid DRONESTOCK_SERVER_URL in ${PREPARED_ENV}" >&2
  exit 1
fi

if [[ ! -f "${TARGET_ENV}" ]]; then
  install -m 0640 -o root -g root "${PREPARED_ENV}" "${TARGET_ENV}"
  echo "Created ${TARGET_ENV} with ${SERVER_URL}"
else
  BACKUP="${TARGET_ENV}.bak.$(date +%Y%m%d%H%M%S)"
  cp -p "${TARGET_ENV}" "${BACKUP}"
  if grep -q '^DRONESTOCK_SERVER_URL=' "${TARGET_ENV}"; then
    sed -i "s#^DRONESTOCK_SERVER_URL=.*#DRONESTOCK_SERVER_URL=${SERVER_URL}#" "${TARGET_ENV}"
  else
    printf '\nDRONESTOCK_SERVER_URL=%s\n' "${SERVER_URL}" >> "${TARGET_ENV}"
  fi
  echo "Updated only DRONESTOCK_SERVER_URL in ${TARGET_ENV}"
  echo "Backup: ${BACKUP}"
fi

echo "Next: sudo systemctl restart dronestock-companion"
