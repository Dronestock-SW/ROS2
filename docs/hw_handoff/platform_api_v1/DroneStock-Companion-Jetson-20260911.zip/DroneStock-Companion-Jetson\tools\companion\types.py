from __future__ import annotations

import math
from dataclasses import dataclass, field, replace
from enum import Enum
from typing import Any


def monotonic_age_ms(received_monotonic: float | None, now: float) -> int | None:
    if received_monotonic is None:
        return None
    return max(0, int((now - received_monotonic) * 1000.0))


def finite_float(value: Any, default: float | None = None) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return default
    return number if math.isfinite(number) else default


def finite_bool(value: Any, default: bool = False) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    lowered = str(value).strip().lower()
    if lowered in {"1", "true", "yes", "on", "ok", "connected"}:
        return True
    if lowered in {"0", "false", "no", "off", "none", "null"}:
        return False
    return default


def clamp(value: float, lower: float, upper: float) -> float:
    return max(lower, min(upper, value))


class FlightState(str, Enum):
    SYSTEM_CHECK = "SYSTEM_CHECK"
    READY = "READY"
    ARMING = "ARMING"
    TAKEOFF_READY = "TAKEOFF_READY"
    TAKEOFF_INIT = "TAKEOFF_INIT"
    WAIT_FOR_TAKEOFF = "WAIT_FOR_TAKEOFF"
    MOVE_TO_WAYPOINT = "MOVE_TO_WAYPOINT"
    WAIT_FOR_ARRIVAL = "WAIT_FOR_ARRIVAL"
    SCAN = "SCAN"
    NEXT_WAYPOINT = "NEXT_WAYPOINT"
    RETURN = "RETURN"
    LAND = "LAND"
    POWER_OFF = "POWER_OFF"
    DEGRADED_HOVER = "DEGRADED_HOVER"
    FAILSAFE_LAND = "FAILSAFE_LAND"
    EMERGENCY_CUT = "EMERGENCY_CUT"


class TakeoffPhase(str, Enum):
    TAKEOFF_ARMED_IDLE = "TAKEOFF_ARMED_IDLE"
    TAKEOFF_BOOST = "TAKEOFF_BOOST"
    LIFTOFF_CONFIRM = "LIFTOFF_CONFIRM"
    CLIMB_CAPTURE = "CLIMB_CAPTURE"
    ALTITUDE_HOLD_SETTLE = "ALTITUDE_HOLD_SETTLE"
    INITIAL_HOVER = "INITIAL_HOVER"
    XY_STABILITY_CHECK = "XY_STABILITY_CHECK"


class SafetyLevel(str, Enum):
    OK = "OK"
    WARN = "WARN"
    DEGRADED_HOVER = "DEGRADED_HOVER"
    FAILSAFE_LAND = "FAILSAFE_LAND"
    EMERGENCY_CUT = "EMERGENCY_CUT"


class ZSource(str, Enum):
    UNKNOWN = "unknown"
    TOF = "tof10120"
    UWB = "uwb_z_control"
    FC_RELATIVE = "fc_relative_alt"
    LAST_SAFE = "last_safe_z"


class RequiredAction(str, Enum):
    NONE = "NONE"
    ARM = "ARM"
    DISARM = "DISARM"
    INIT_TAKEOFF = "INIT_TAKEOFF"


class QRScanStatus(str, Enum):
    DISABLED = "DISABLED"
    IDLE = "IDLE"
    SCANNING = "SCANNING"
    UPLOADED = "UPLOADED"
    BUFFERED = "BUFFERED"
    REJECTED = "REJECTED"
    FAILED = "FAILED"


class ControlMode(str, Enum):
    FC_GUIDED = "fc_guided"
    COMPANION_RC = "companion_rc"
    DRY_RUN = "dry_run"


class PoseQuality(str, Enum):
    NO_FIX = "NO_FIX"
    DEGRADED_FIX = "DEGRADED_FIX"
    POSITION_ONLY = "POSITION_ONLY"
    CONTROL_GRADE = "CONTROL_GRADE"


class MotionState(str, Enum):
    UNKNOWN = "UNKNOWN"
    ON_GROUND_STABLE = "ON_GROUND_STABLE"
    MOTOR_SPINNING = "MOTOR_SPINNING"
    LIFTOFF_CANDIDATE = "LIFTOFF_CANDIDATE"
    AIRBORNE_STABLE = "AIRBORNE_STABLE"
    BOUNCE_OR_CONTACT = "BOUNCE_OR_CONTACT"
    TIPPED_OR_CRASHED = "TIPPED_OR_CRASHED"


@dataclass(frozen=True)
class Waypoint:
    x_m: float
    y_m: float
    z_m: float
    point_id: str = ""
    task_type: str = "waypoint"
    hold_s: float = 0.0
    arrival_radius_m: float = 0.2
    required_scan: bool = False
    raw: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class UWBState:
    x_m: float | None = None
    y_m: float | None = None
    z_raw: float | None = None
    z3d: float | None = None
    z_filtered: float | None = None
    z_control_m: float | None = None
    z_trusted: bool = False
    z_control_usable: bool = False
    xy_control_usable: bool = False
    z_reason: str = ""
    z_residual_m: float | None = None
    z_confidence: float | None = None
    z_candidate_spread_m: float | None = None
    ranges: list[float | None] = field(default_factory=list)
    range_ok: list[bool] = field(default_factory=list)
    fix: bool = False
    pose4d_fix: bool = False
    pose_quality: str = PoseQuality.NO_FIX.value
    uwb4_residual_m: float | None = None
    uwb_link: bool = False
    tag_layout_synced: bool = False
    anchor_layout_id: str = ""
    layout_version: int = 0
    seq: int | None = None
    reason: str = ""
    age_ms: int | None = None
    received_monotonic: float | None = None
    raw: dict[str, Any] = field(default_factory=dict)

    def with_age(self, now: float) -> "UWBState":
        return replace(self, age_ms=monotonic_age_ms(self.received_monotonic, now))


@dataclass(frozen=True)
class ToFState:
    raw_distance_m: float | None = None
    filtered_distance_m: float | None = None
    ground_offset_m: float | None = None
    altitude_m: float | None = None
    vertical_speed_mps: float | None = None
    usable: bool = False
    reason: str = "not_started"
    age_ms: int | None = None
    confidence: float = 0.0
    received_monotonic: float | None = None

    def with_age(self, now: float) -> "ToFState":
        return replace(self, age_ms=monotonic_age_ms(self.received_monotonic, now))


@dataclass(frozen=True)
class IMUState:
    roll_deg: float | None = None
    pitch_deg: float | None = None
    roll_rate_dps: float | None = None
    pitch_rate_dps: float | None = None
    yaw_rate_dps: float | None = None
    accel_z_g: float | None = None
    accel_norm_g: float | None = None
    linear_accel_x_mps2: float | None = None
    linear_accel_y_mps2: float | None = None
    linear_accel_z_mps2: float | None = None
    jerk_mps3: float | None = None
    vibration_score: float | None = None
    temperature_c: float | None = None
    calibrated: bool = False
    sample_rate_hz: float | None = None
    motion_state: str = MotionState.UNKNOWN.value
    tilt_ok: bool = False
    rate_ok: bool = False
    shock_detected: bool = False
    drift_status: str = ""
    health: str = "UNKNOWN"
    usable: bool = False
    reason: str = "not_started"
    age_ms: int | None = None
    received_monotonic: float | None = None

    def with_age(self, now: float) -> "IMUState":
        return replace(self, age_ms=monotonic_age_ms(self.received_monotonic, now))


@dataclass(frozen=True)
class FCState:
    connected: bool = False
    armed: bool = False
    mode: str = ""
    battery_voltage: float | None = None
    battery_remaining_pct: float | None = None
    relative_alt_m: float | None = None
    yaw_deg: float | None = None
    heartbeat_age_ms: int | None = None
    telemetry_age_ms: int | None = None
    received_monotonic: float | None = None
    heartbeat_monotonic: float | None = None

    def with_age(self, now: float) -> "FCState":
        return replace(
            self,
            heartbeat_age_ms=monotonic_age_ms(self.heartbeat_monotonic, now),
            telemetry_age_ms=monotonic_age_ms(self.received_monotonic, now),
            connected=self.heartbeat_monotonic is not None and (now - self.heartbeat_monotonic) < 2.0,
        )


@dataclass(frozen=True)
class MissionState:
    contract_version: str = ""
    ok: bool = False
    server_reachable: bool = False
    status: str = "HOLD"
    mission_id: str = ""
    mission_db_id: int | None = None
    mission_code: str = ""
    route_revision: str = ""
    mission_status: str = ""
    launch_authorized: bool = False
    launch_blocked_reason: str | None = None
    mission_target_alt_m: float | None = None
    target_x_m: float | None = None
    target_y_m: float | None = None
    target_z_m: float | None = None
    home_point: Waypoint | None = None
    route_tasks: list[Waypoint] = field(default_factory=list)
    control_action: str = ""
    control_requested_at: str | None = None
    control_request_id: str = ""
    anchors: list[dict[str, Any]] = field(default_factory=list)
    anchor_layout_id: str = ""
    anchor_layout_version: int = 0
    layout_compact: str = ""
    anchor_layout_valid: bool = False
    anchor_layout_warning: str | None = None
    age_ms: int | None = None
    received_monotonic: float | None = None
    raw: dict[str, Any] = field(default_factory=dict)

    def with_age(self, now: float) -> "MissionState":
        return replace(self, age_ms=monotonic_age_ms(self.received_monotonic, now))


@dataclass(frozen=True)
class SensorSnapshot:
    uwb: UWBState
    tof: ToFState
    imu: IMUState
    fc: FCState
    mission: MissionState
    now: float


@dataclass(frozen=True)
class EstimationState:
    current_x_m: float | None = None
    current_y_m: float | None = None
    current_vx_mps: float | None = None
    current_vy_mps: float | None = None
    current_z_m: float | None = None
    current_z_source: ZSource = ZSource.UNKNOWN
    current_z_trusted: bool = False
    current_z_confidence: float = 0.0
    altitude_error_m: float | None = None
    z_control_usable: bool = False
    xy_control_usable: bool = False
    altitude_sensor_ready: bool = False
    freeze_altitude_integrator: bool = False
    health: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class SafetyState:
    level: SafetyLevel = SafetyLevel.OK
    reasons: list[str] = field(default_factory=list)
    degraded_hover: bool = False
    failsafe_land: bool = False
    emergency_cut: bool = False
    disarm_request: bool = False


@dataclass(frozen=True)
class MissionFSMResult:
    state: FlightState
    takeoff_phase: TakeoffPhase | None = None
    active_waypoint: Waypoint | None = None
    required_action: RequiredAction = RequiredAction.NONE
    events: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class RCChannels:
    roll: int = 1500
    pitch: int = 1500
    throttle: int = 1000
    yaw: int = 1500
    ch5: int = 0
    ch6: int = 0
    ch7: int = 0
    ch8: int = 0
    disarm_request: bool = False
    reason: str = ""

    def clamped(self, *, roll_limit: int, pitch_limit: int, yaw_limit: int,
                throttle_min: int, throttle_max: int) -> "RCChannels":
        return replace(
            self,
            roll=int(clamp(self.roll, 1500 - roll_limit, 1500 + roll_limit)),
            pitch=int(clamp(self.pitch, 1500 - pitch_limit, 1500 + pitch_limit)),
            yaw=int(clamp(self.yaw, 1500 - yaw_limit, 1500 + yaw_limit)),
            throttle=int(clamp(self.throttle, throttle_min, throttle_max)),
        )

    def as_mavlink_channels(self) -> tuple[int, int, int, int, int, int, int, int]:
        # 0 means "release/no override" for aux channels in ArduPilot.
        return (
            self.roll,
            self.pitch,
            self.throttle,
            self.yaw,
            self.ch5,
            self.ch6,
            self.ch7,
            self.ch8,
        )


@dataclass(frozen=True)
class ControllerStatus:
    takeoff_phase: TakeoffPhase | None = None
    takeoff_complete: bool = False
    arrival_candidate: bool = False
    scan_complete: bool = False
    scan_status: QRScanStatus = QRScanStatus.IDLE


@dataclass(frozen=True)
class QRDecodeResult:
    text: str = ""
    decoder: str = ""
    confidence: float = 0.0


@dataclass(frozen=True)
class QRScanState:
    status: QRScanStatus = QRScanStatus.IDLE
    active: bool = False
    complete: bool = False
    client_scan_id: str = ""
    qr_text: str = ""
    decoder: str = ""
    waypoint_id: str = ""
    mission_id: str = ""
    accepted: bool | None = None
    buffered: bool = False
    pending_buffer_count: int = 0
    last_error: str = ""
    updated_monotonic: float | None = None


@dataclass(frozen=True)
class FailureReason:
    code: str
    level: str = "BLOCKER"
    message: str = ""

    def as_dict(self) -> dict[str, str]:
        return {"code": self.code, "level": self.level, "message": self.message}


@dataclass(frozen=True)
class FcGuidedProbeResult:
    requested_mode: str = ControlMode.COMPANION_RC.value
    selected_mode: str = ControlMode.COMPANION_RC.value
    fc_guided_ok: bool = False
    fallback_allowed: bool = True
    reasons: list[FailureReason] = field(default_factory=list)

    def as_dict(self) -> dict[str, Any]:
        return {
            "requested_mode": self.requested_mode,
            "selected_mode": self.selected_mode,
            "fc_guided_ok": self.fc_guided_ok,
            "fallback_allowed": self.fallback_allowed,
            "reasons": [reason.as_dict() for reason in self.reasons],
        }
