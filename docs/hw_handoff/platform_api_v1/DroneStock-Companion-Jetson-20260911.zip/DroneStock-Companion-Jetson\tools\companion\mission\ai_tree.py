from __future__ import annotations

from enum import Enum

from ..types import EstimationState, FlightState, SafetyState, SensorSnapshot
from .launch_guard import LaunchGuardResult


class Decision(str, Enum):
    ALLOW_ARM = "ALLOW_ARM"
    BLOCK_ARM = "BLOCK_ARM"
    ALLOW_TAKEOFF = "ALLOW_TAKEOFF"
    BLOCK_TAKEOFF = "BLOCK_TAKEOFF"
    CONTINUE_TAKEOFF = "CONTINUE_TAKEOFF"
    ALLOW_XY_NAVIGATION = "ALLOW_XY_NAVIGATION"
    DEGRADED_HOVER = "DEGRADED_HOVER"
    FAILSAFE_LAND = "FAILSAFE_LAND"
    EMERGENCY_CUT = "EMERGENCY_CUT"


class AITree:
    """Decision flags only. This module never creates PWM."""

    def evaluate(
        self,
        *,
        state: FlightState,
        snapshot: SensorSnapshot,
        estimation: EstimationState,
        safety: SafetyState,
        launch_guard: LaunchGuardResult,
    ) -> set[Decision]:
        decisions: set[Decision] = set()
        if safety.emergency_cut:
            return {Decision.EMERGENCY_CUT}
        if safety.failsafe_land:
            decisions.add(Decision.FAILSAFE_LAND)
        if safety.degraded_hover:
            decisions.add(Decision.DEGRADED_HOVER)

        if launch_guard.mission_ready:
            decisions.add(Decision.ALLOW_ARM)
        else:
            decisions.add(Decision.BLOCK_ARM)

        if state == FlightState.TAKEOFF_READY:
            decisions.add(Decision.ALLOW_TAKEOFF if launch_guard.allow_takeoff else Decision.BLOCK_TAKEOFF)
            return decisions

        if state == FlightState.WAIT_FOR_TAKEOFF and estimation.altitude_sensor_ready:
            decisions.add(Decision.CONTINUE_TAKEOFF)

        if estimation.xy_control_usable and estimation.z_control_usable:
            decisions.add(Decision.ALLOW_XY_NAVIGATION)

        return decisions

