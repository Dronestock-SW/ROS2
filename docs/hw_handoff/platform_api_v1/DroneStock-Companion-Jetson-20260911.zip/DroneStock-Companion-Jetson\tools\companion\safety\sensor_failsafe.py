from __future__ import annotations

from dataclasses import dataclass

from ..config import AppConfig
from ..types import EstimationState, FlightState, SafetyLevel, SensorSnapshot


@dataclass(frozen=True)
class SensorFailsafeResult:
    level: SafetyLevel
    reasons: list[str]


class SensorFailsafe:
    def __init__(self, config: AppConfig) -> None:
        self.config = config

    def evaluate(self, snapshot: SensorSnapshot, estimation: EstimationState, state: FlightState) -> SensorFailsafeResult:
        reasons: list[str] = []
        level = SafetyLevel.OK
        in_flight = state not in {
            FlightState.SYSTEM_CHECK,
            FlightState.READY,
            FlightState.ARMING,
            FlightState.TAKEOFF_READY,
            FlightState.TAKEOFF_INIT,
            FlightState.POWER_OFF,
        }

        if self.config.require_pixhawk and (
            snapshot.fc.heartbeat_age_ms is None or snapshot.fc.heartbeat_age_ms > self.config.fc_max_age_ms
        ):
            reasons.append("fc_heartbeat_lost")
            level = SafetyLevel.FAILSAFE_LAND if in_flight else SafetyLevel.WARN

        if self.config.require_server and (
            snapshot.mission.age_ms is None or snapshot.mission.age_ms > self.config.server_max_age_ms
        ):
            reasons.append("server_link_stale")
            level = SafetyLevel.FAILSAFE_LAND if in_flight else max_level(level, SafetyLevel.WARN)

        if in_flight and not estimation.xy_control_usable and estimation.z_control_usable:
            reasons.append("uwb_xy_unusable")
            level = max_level(level, SafetyLevel.DEGRADED_HOVER)

        if in_flight and not estimation.xy_control_usable and not estimation.z_control_usable:
            reasons.append("xy_and_z_unusable")
            level = max_level(level, SafetyLevel.FAILSAFE_LAND)

        if snapshot.mission.anchor_layout_id and snapshot.uwb.anchor_layout_id:
            if snapshot.mission.anchor_layout_id != snapshot.uwb.anchor_layout_id:
                reasons.append("LAYOUT_ID_MISMATCH")
                level = max_level(level, SafetyLevel.FAILSAFE_LAND if in_flight else SafetyLevel.WARN)

        if snapshot.uwb.pose_quality and snapshot.uwb.pose_quality != "CONTROL_GRADE":
            reasons.append(f"UWB4_NO_CONTROL_GRADE:{snapshot.uwb.pose_quality}")
            level = max_level(level, SafetyLevel.DEGRADED_HOVER if in_flight else SafetyLevel.WARN)

        if estimation.current_z_m is not None and snapshot.tof.altitude_m is not None and snapshot.tof.usable:
            if abs(estimation.current_z_m - snapshot.tof.altitude_m) > self.config.uwb_tof_z_diff_max_m:
                reasons.append("UWB_TOF_Z_MISMATCH")
                level = max_level(level, SafetyLevel.FAILSAFE_LAND if in_flight else SafetyLevel.WARN)

        return SensorFailsafeResult(level, reasons or ["ok"])


def max_level(lhs: SafetyLevel, rhs: SafetyLevel) -> SafetyLevel:
    order = {
        SafetyLevel.OK: 0,
        SafetyLevel.WARN: 1,
        SafetyLevel.DEGRADED_HOVER: 2,
        SafetyLevel.FAILSAFE_LAND: 3,
        SafetyLevel.EMERGENCY_CUT: 4,
    }
    return lhs if order[lhs] >= order[rhs] else rhs
