# DroneStock Companion Jetson 로컬 네트워크 설치 안내

이 배포 묶음은 전체 Django 소스가 아니라 Jetson에서 실행할 Companion
Runtime만 포함합니다. Jetson은 Vercel이 아니라 같은 네트워크의 작업 PC에
접속합니다.

## 0. 연결 구조

```text
UWB 태그 / Pixhawk / 센서
        ↓ Jetson 장치 포트
DroneStock Companion
        ↓ 같은 LAN의 HTTP + WebSocket
http://203.247.41.82:8001
        ↓
작업 PC의 DroneStock Platform
```

`127.0.0.1`은 Jetson 자기 자신을 뜻하므로 작업 PC 주소로 사용할 수
없습니다. 번들 안 `LAN_CONNECTION_INFO.txt`와
`tools/companion/deploy/companion.env.local`에는 번들 생성 당시 작업 PC의
실제 LAN 주소가 기록됩니다.

## 1. 작업 PC 준비

Platform 프로젝트 폴더에서 실행합니다.

```powershell
.\dev.ps1 start -OpenBrowser
```

출력의 `LAN URL`이 다른 컴퓨터에서 열 주소입니다. Windows 방화벽 때문에
접속되지 않으면 관리자 PowerShell에서 한 번 실행합니다.

```powershell
.\tools\allow_platform_lan_firewall.ps1 -Port 8001
```

이 규칙은 TCP 8001을 `LocalSubnet`에만 허용합니다. 작업 PC와 Jetson은
같은 네트워크에 있어야 하며, 공용 Wi-Fi의 AP isolation이 켜져 있으면
서로 접속할 수 없습니다.

## 2. 압축 해제와 설치

```bash
mkdir -p ~/DroneStock-Companion
unzip DroneStock-Companion-Jetson-20260911.zip -d ~/DroneStock-Companion
cd ~/DroneStock-Companion/DroneStock-Companion-Jetson
sudo bash tools/companion/deploy/install_jetson.sh
```

신규 설치에서는 생성된 `companion.env.local`이 자동 적용됩니다. 기존
`/etc/dronestock-companion.env`는 안전을 위해 덮어쓰지 않습니다. 기존
설치의 서버 URL만 바꾸려면 다음을 실행합니다.

```bash
sudo bash tools/companion/deploy/set_server_url.sh
```

## 3. 전달·확인할 설정

```text
DRONESTOCK_DRONE_ID=5
DRONESTOCK_SERVER_URL=http://203.247.41.82:8001
DRONESTOCK_COMPANION_PLATFORM=jetson-orin-nano
DRONESTOCK_COMPANION_ID=jetson-drone-05
DRONESTOCK_DIAGNOSTIC_INTERVAL_S=5
DRONESTOCK_UWB_PORT=/dev/ttyUSB0
DRONESTOCK_UWB_BAUD=921600
DRONESTOCK_PIXHAWK_DEVICE=/dev/serial0
DRONESTOCK_PIXHAWK_BAUD=57600
```

Jetson에서 먼저 연결을 확인합니다.

```bash
curl -I http://203.247.41.82:8001/platform/login/
```

HTTP `200` 또는 정상적인 리다이렉트 응답이 와야 합니다. 실제 장치가
`/dev/ttyACM0` 등으로 잡히면 `/etc/dronestock-companion.env`의 포트를
변경합니다.

## 4. UWB 단독 확인

```bash
cd ~/DroneStock-Companion/DroneStock-Companion-Jetson
.venv-companion/bin/python tools/companion/deploy/check_uwb_serial.py \
  --port /dev/ttyUSB0 --baud 921600 --seconds 15 --require-fix
```

정상 기준은 `pose_lines`와 `usable_fix_lines`가 1 이상이고 `last_x`,
`last_y`가 숫자인 것입니다.

## 5. Companion 시작 및 서버 전송 확인

```bash
sudo systemctl restart dronestock-companion
sudo systemctl status dronestock-companion --no-pager
sudo journalctl -u dronestock-companion -f
```

`COMPANION_HEALTH`에서 아래를 확인합니다.

- `uwb.connected=true`: Jetson이 UWB 직렬 장치를 열었음
- `uwb.usable_fix_lines` 증가: 사용할 수 있는 좌표 수신 중
- `server.connected=true`: 작업 PC WebSocket 연결 성공
- `server.messages_sent` 증가: UWB/상태 데이터가 작업 PC로 전송 중
- `server.endpoint=ws://203.247.41.82:8001/ws/drones/5/`

## 6. 중요 사항

- 작업 PC의 IP가 DHCP로 바뀌면 새 번들을 만들거나 Jetson의
  `DRONESTOCK_SERVER_URL`을 새 주소로 갱신해야 합니다.
- 작업 PC Platform이 꺼지거나 절전 상태가 되면 Jetson 전송도 끊깁니다.
- 개발용 로컬 서버는 같은 현장 네트워크에서만 사용하세요.
- ESP32 펌웨어는 이 묶음에 포함되지 않으며 자동으로 변경되지 않습니다.
- `/etc/dronestock-companion.env`에 계정 비밀번호나 Secret을 추가해 공유하지
  마세요.
