"""Sensor normalization and state estimation."""

