from __future__ import annotations

from ..config import AppConfig
from ..types import (
    ControllerStatus,
    EstimationState,
    FcGuidedProbeResult,
    FlightState,
    MissionFSMResult,
    RequiredAction,
    SafetyState,
    SensorSnapshot,
    TakeoffPhase,
    Waypoint,
)
from .ai_tree import AITree, Decision
from .launch_guard import LaunchGuard
from .route_manager import RouteManager


class MissionFSM:
    """Single owner of flight_state transitions."""

    def __init__(self, config: AppConfig) -> None:
        self.config = config
        self.state = FlightState.SYSTEM_CHECK
        self.state_since = 0.0
        self.launch_guard = LaunchGuard(config)
        self.ai_tree = AITree()
        self.route_manager = RouteManager(config)

    def update(
        self,
        *,
        snapshot: SensorSnapshot,
        estimation: EstimationState,
        safety: SafetyState,
        controller_status: ControllerStatus,
        control_probe: FcGuidedProbeResult | None = None,
    ) -> MissionFSMResult:
        if self.state_since <= 0.0:
            self.state_since = snapshot.now

        events: list[str] = []
        required_action = RequiredAction.NONE
        guard = self.launch_guard.evaluate(snapshot, estimation, control_probe)
        decisions = self.ai_tree.evaluate(
            state=self.state,
            snapshot=snapshot,
            estimation=estimation,
            safety=safety,
            launch_guard=guard,
        )
        self.route_manager.sync(snapshot.mission)

        if Decision.EMERGENCY_CUT in decisions:
            events += self._transition(FlightState.EMERGENCY_CUT, snapshot.now)
            required_action = RequiredAction.DISARM
            return self._result(snapshot, controller_status.takeoff_phase, required_action, events)

        if safety.failsafe_land and self._is_in_flight():
            events += self._transition(FlightState.FAILSAFE_LAND, snapshot.now)

        if snapshot.mission.control_action == "return_to_home" and self._is_in_flight():
            events += self._transition(FlightState.RETURN, snapshot.now)
        elif snapshot.mission.control_action == "land" and self._is_in_flight():
            events += self._transition(FlightState.LAND, snapshot.now)

        active = self._active_waypoint(snapshot)

        if self.state == FlightState.SYSTEM_CHECK:
            if guard.system_ready:
                events.append("SYSTEM_CHECK_PASS")
                events += self._transition(FlightState.READY, snapshot.now)

        elif self.state == FlightState.READY:
            if guard.mission_ready:
                events += self._transition(FlightState.ARMING, snapshot.now)

        elif self.state == FlightState.ARMING:
            if not guard.mission_ready:
                events += self._transition(FlightState.READY, snapshot.now)
            else:
                required_action = RequiredAction.ARM
                if snapshot.fc.armed:
                    events.append("ARM_SUCCESS")
                    events += self._transition(FlightState.TAKEOFF_READY, snapshot.now)

        elif self.state == FlightState.TAKEOFF_READY:
            if not snapshot.fc.armed:
                events += self._transition(FlightState.ARMING, snapshot.now)
            elif snapshot.now - self.state_since >= self.config.takeoff_ready_hold_s and Decision.ALLOW_TAKEOFF in decisions:
                events += self._transition(FlightState.TAKEOFF_INIT, snapshot.now)
                required_action = RequiredAction.INIT_TAKEOFF

        elif self.state == FlightState.TAKEOFF_INIT:
            required_action = RequiredAction.INIT_TAKEOFF
            if snapshot.now - self.state_since >= 0.05:
                events += self._transition(FlightState.WAIT_FOR_TAKEOFF, snapshot.now)

        elif self.state == FlightState.WAIT_FOR_TAKEOFF:
            if controller_status.takeoff_complete:
                events.append("INITIAL_HOVER_COMPLETE")
                events.append("MOVE_TO_WAYPOINT_START")
                events += self._transition(FlightState.MOVE_TO_WAYPOINT, snapshot.now)

        elif self.state == FlightState.MOVE_TO_WAYPOINT:
            if not estimation.xy_control_usable and estimation.z_control_usable:
                events += self._transition(FlightState.DEGRADED_HOVER, snapshot.now)
            else:
                arrival = self.route_manager.update_arrival(waypoint=active, estimation=estimation, now=snapshot.now)
                if arrival.inside_radius:
                    events += self._transition(FlightState.WAIT_FOR_ARRIVAL, snapshot.now)

        elif self.state == FlightState.WAIT_FOR_ARRIVAL:
            arrival = self.route_manager.update_arrival(waypoint=active, estimation=estimation, now=snapshot.now)
            if arrival.complete:
                if active and active.task_type == "scan":
                    events += self._transition(FlightState.SCAN, snapshot.now)
                else:
                    events += self._transition(FlightState.NEXT_WAYPOINT, snapshot.now)

        elif self.state == FlightState.SCAN:
            if controller_status.scan_complete:
                events.append("QR_SCAN_COMPLETE")
                events += self._transition(FlightState.NEXT_WAYPOINT, snapshot.now)

        elif self.state == FlightState.NEXT_WAYPOINT:
            if self.route_manager.advance(snapshot.mission):
                events += self._transition(FlightState.MOVE_TO_WAYPOINT, snapshot.now)
            else:
                events += self._transition(FlightState.RETURN if snapshot.mission.home_point else FlightState.LAND, snapshot.now)

        elif self.state == FlightState.RETURN:
            home = snapshot.mission.home_point
            arrival = self.route_manager.update_arrival(waypoint=home, estimation=estimation, now=snapshot.now)
            if home is None or arrival.complete:
                events += self._transition(FlightState.LAND, snapshot.now)

        elif self.state == FlightState.DEGRADED_HOVER:
            if not estimation.z_control_usable:
                events += self._transition(FlightState.FAILSAFE_LAND, snapshot.now)
            elif estimation.xy_control_usable:
                events += self._transition(FlightState.MOVE_TO_WAYPOINT, snapshot.now)

        elif self.state in {FlightState.LAND, FlightState.FAILSAFE_LAND}:
            if estimation.current_z_m is not None and estimation.current_z_m <= 0.08:
                required_action = RequiredAction.DISARM
                events += self._transition(FlightState.POWER_OFF, snapshot.now)

        elif self.state == FlightState.EMERGENCY_CUT:
            required_action = RequiredAction.DISARM

        elif self.state == FlightState.POWER_OFF:
            required_action = RequiredAction.DISARM

        return self._result(snapshot, controller_status.takeoff_phase, required_action, events)

    def _active_waypoint(self, snapshot: SensorSnapshot) -> Waypoint | None:
        if self.state == FlightState.RETURN:
            return snapshot.mission.home_point
        if self.state in {
            FlightState.MOVE_TO_WAYPOINT,
            FlightState.WAIT_FOR_ARRIVAL,
            FlightState.SCAN,
            FlightState.DEGRADED_HOVER,
        }:
            return self.route_manager.active(snapshot.mission)
        return None

    def _result(
        self,
        snapshot: SensorSnapshot,
        takeoff_phase: TakeoffPhase | None,
        required_action: RequiredAction,
        events: list[str],
    ) -> MissionFSMResult:
        return MissionFSMResult(
            state=self.state,
            takeoff_phase=takeoff_phase,
            active_waypoint=self._active_waypoint(snapshot),
            required_action=required_action,
            events=events,
        )

    def _transition(self, new_state: FlightState, now: float) -> list[str]:
        if new_state == self.state:
            return []
        old_state = self.state
        self.state = new_state
        self.state_since = now
        events: list[str] = []

        def add_event(event: str) -> None:
            if event not in events:
                events.append(event)

        add_event(f"{new_state.value}_ENTER")
        if new_state == FlightState.ARMING:
            add_event("ARM_REQUEST")
        if new_state == FlightState.TAKEOFF_READY:
            add_event("TAKEOFF_READY_ENTER")
        if new_state == FlightState.TAKEOFF_INIT:
            add_event("TAKEOFF_INIT_ENTER")
        if new_state == FlightState.DEGRADED_HOVER:
            add_event("DEGRADED_HOVER_ENTER")
        if new_state == FlightState.FAILSAFE_LAND:
            add_event("FAILSAFE_LAND_ENTER")
        if new_state == FlightState.EMERGENCY_CUT:
            add_event("EMERGENCY_CUT_ENTER")
        if old_state != new_state:
            self.route_manager.reset_arrival_timer()
        return events

    def _is_in_flight(self) -> bool:
        return self.state in {
            FlightState.WAIT_FOR_TAKEOFF,
            FlightState.MOVE_TO_WAYPOINT,
            FlightState.WAIT_FOR_ARRIVAL,
            FlightState.SCAN,
            FlightState.NEXT_WAYPOINT,
            FlightState.RETURN,
            FlightState.LAND,
            FlightState.DEGRADED_HOVER,
            FlightState.FAILSAFE_LAND,
        }
