from __future__ import annotations

from dataclasses import dataclass

from ..config import AppConfig
from ..types import FlightState, SensorSnapshot, TakeoffPhase, ZSource


@dataclass(frozen=True)
class CurrentZResult:
    current_z_m: float | None
    source: ZSource
    trusted: bool
    confidence: float
    freeze_integrator: bool
    altitude_sensor_ready: bool
    reason: str = ""


class CurrentZResolver:
    """Choose one current_z_m for the whole control tick."""

    def __init__(self, config: AppConfig) -> None:
        self.config = config
        self.last_safe_z_m: float | None = None
        self.fc_relative_alt_baseline_m: float | None = None
        self.uwb_z_baseline_m: float | None = None

    def capture_takeoff_baselines(self, snapshot: SensorSnapshot) -> None:
        self.fc_relative_alt_baseline_m = snapshot.fc.relative_alt_m
        self.uwb_z_baseline_m = snapshot.uwb.z_control_m

    def resolve(
        self,
        snapshot: SensorSnapshot,
        *,
        state: FlightState,
        takeoff_phase: TakeoffPhase | None = None,
    ) -> CurrentZResult:
        altitude_ready = self._altitude_sensor_ready(snapshot)
        if state in {FlightState.SYSTEM_CHECK, FlightState.READY, FlightState.ARMING, FlightState.TAKEOFF_READY, FlightState.TAKEOFF_INIT}:
            return CurrentZResult(
                current_z_m=self.last_safe_z_m,
                source=ZSource.LAST_SAFE if self.last_safe_z_m is not None else ZSource.UNKNOWN,
                trusted=False,
                confidence=0.0,
                freeze_integrator=True,
                altitude_sensor_ready=altitude_ready,
                reason="pre_takeoff_no_forced_altitude",
            )

        prefer_tof = state == FlightState.WAIT_FOR_TAKEOFF
        if prefer_tof:
            candidates = (
                self._tof_candidate(snapshot),
                self._uwb_candidate(snapshot),
                self._fc_candidate(snapshot),
            )
        else:
            candidates = (
                self._uwb_candidate(snapshot),
                self._tof_low_alt_candidate(snapshot),
                self._fc_candidate(snapshot),
            )

        for result in candidates:
            if result is None:
                continue
            self.last_safe_z_m = result.current_z_m
            return result

        return CurrentZResult(
            current_z_m=self.last_safe_z_m,
            source=ZSource.LAST_SAFE if self.last_safe_z_m is not None else ZSource.UNKNOWN,
            trusted=False,
            confidence=0.0,
            freeze_integrator=True,
            altitude_sensor_ready=altitude_ready,
            reason="using_last_safe_z",
        )

    def _altitude_sensor_ready(self, snapshot: SensorSnapshot) -> bool:
        tof_ready = snapshot.tof.usable and snapshot.tof.age_ms is not None and snapshot.tof.age_ms <= self.config.tof_max_age_ms
        uwb_ready = snapshot.uwb.z_control_usable and snapshot.uwb.age_ms is not None and snapshot.uwb.age_ms <= self.config.uwb_max_age_ms
        fc_ready = snapshot.fc.relative_alt_m is not None and snapshot.fc.heartbeat_age_ms is not None and snapshot.fc.heartbeat_age_ms <= self.config.fc_max_age_ms
        return tof_ready or uwb_ready or fc_ready

    def _tof_candidate(self, snapshot: SensorSnapshot) -> CurrentZResult | None:
        tof = snapshot.tof
        if not tof.usable or tof.altitude_m is None or tof.age_ms is None or tof.age_ms > self.config.tof_max_age_ms:
            return None
        return CurrentZResult(tof.altitude_m, ZSource.TOF, True, tof.confidence, False, True, "tof")

    def _tof_low_alt_candidate(self, snapshot: SensorSnapshot) -> CurrentZResult | None:
        result = self._tof_candidate(snapshot)
        if result is None:
            return None
        if result.current_z_m is not None and result.current_z_m <= 1.2:
            return result
        return None

    def _uwb_candidate(self, snapshot: SensorSnapshot) -> CurrentZResult | None:
        uwb = snapshot.uwb
        if not uwb.z_control_usable or uwb.z_control_m is None or uwb.age_ms is None or uwb.age_ms > self.config.uwb_max_age_ms:
            return None
        if uwb.pose_quality and uwb.pose_quality != "CONTROL_GRADE":
            return None
        if uwb.uwb4_residual_m is not None and uwb.uwb4_residual_m > self.config.uwb_residual_control_max_m:
            return None
        confidence = uwb.z_confidence if uwb.z_confidence is not None else 0.7
        return CurrentZResult(uwb.z_control_m, ZSource.UWB, True, confidence, False, True, "uwb")

    def _fc_candidate(self, snapshot: SensorSnapshot) -> CurrentZResult | None:
        fc = snapshot.fc
        if fc.relative_alt_m is None or fc.heartbeat_age_ms is None or fc.heartbeat_age_ms > self.config.fc_max_age_ms:
            return None
        baseline = self.fc_relative_alt_baseline_m or 0.0
        return CurrentZResult(max(0.0, fc.relative_alt_m - baseline), ZSource.FC_RELATIVE, False, 0.35, True, True, "fc_fallback")
