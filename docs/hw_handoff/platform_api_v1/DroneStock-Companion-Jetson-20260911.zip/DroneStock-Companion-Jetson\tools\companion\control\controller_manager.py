from __future__ import annotations

from dataclasses import replace

from ..config import AppConfig
from ..types import (
    ControllerStatus,
    EstimationState,
    FlightState,
    MissionFSMResult,
    RCChannels,
    SafetyState,
    SensorSnapshot,
)
from .altitude_controller import AltitudeController
from .landing_controller import LandingController
from .takeoff_controller import TakeoffController
from .xy_controller import XYController


class ControllerManager:
    def __init__(self, config: AppConfig) -> None:
        self.config = config
        self.altitude = AltitudeController(config)
        self.takeoff = TakeoffController(config, self.altitude)
        self.xy = XYController(config)
        self.landing = LandingController(config)
        self._status = ControllerStatus()
        self._events: list[str] = []

    def status(self) -> ControllerStatus:
        return self._status

    def reset_takeoff(self, snapshot: SensorSnapshot) -> None:
        self.altitude.reset()
        self.takeoff.reset(snapshot)
        self.landing.reset()

    def pop_events(self) -> list[str]:
        events = self._events + self.takeoff.pop_events()
        self._events = []
        return events

    def compute(
        self,
        *,
        fsm_result: MissionFSMResult,
        snapshot: SensorSnapshot,
        estimation: EstimationState,
        safety: SafetyState,
    ) -> RCChannels:
        state = fsm_result.state
        target = fsm_result.active_waypoint

        if state == FlightState.WAIT_FOR_TAKEOFF:
            output = self.takeoff.compute(snapshot=snapshot, estimation=estimation)
            self._status = output.status
            return output.rc

        if state in {FlightState.MOVE_TO_WAYPOINT, FlightState.WAIT_FOR_ARRIVAL, FlightState.SCAN, FlightState.RETURN}:
            target_z = target.z_m if target else (snapshot.mission.mission_target_alt_m or self.config.takeoff_target_z_m)
            xy_rc = self.xy.compute(waypoint=target, snapshot=snapshot, estimation=estimation)
            throttle = self.altitude.compute(target_z_m=target_z, estimation=estimation, now=snapshot.now)
            self._status = ControllerStatus(takeoff_phase=self.takeoff.phase, takeoff_complete=False)
            return replace(xy_rc, throttle=throttle, reason=f"{xy_rc.reason};altitude_hold target_z={target_z:.2f}")

        if state == FlightState.DEGRADED_HOVER:
            target_z = estimation.current_z_m if estimation.current_z_m is not None else self.config.takeoff_target_z_m
            throttle = self.altitude.compute(target_z_m=target_z, estimation=estimation, now=snapshot.now)
            self._status = ControllerStatus(takeoff_phase=self.takeoff.phase, takeoff_complete=False)
            return RCChannels(throttle=throttle, reason="degraded_hover_altitude_hold")

        if state == FlightState.LAND:
            self._status = ControllerStatus(takeoff_phase=self.takeoff.phase, takeoff_complete=False)
            return self.landing.compute(estimation=estimation, now=snapshot.now, failsafe=False)

        if state == FlightState.FAILSAFE_LAND or safety.failsafe_land:
            self._status = ControllerStatus(takeoff_phase=self.takeoff.phase, takeoff_complete=False)
            return self.landing.compute(estimation=estimation, now=snapshot.now, failsafe=True)

        if state == FlightState.EMERGENCY_CUT:
            self._status = ControllerStatus(takeoff_phase=self.takeoff.phase, takeoff_complete=False)
            return RCChannels(throttle=self.config.throttle_min_pwm, disarm_request=True, reason="emergency_cut")

        self._status = ControllerStatus(takeoff_phase=self.takeoff.phase, takeoff_complete=False)
        return RCChannels(reason=f"{state.value}_neutral")
