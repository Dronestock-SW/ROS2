from __future__ import annotations

import json
import signal
import socket
import sys
import time
from dataclasses import dataclass, replace
from typing import Any

from . import __version__
from .config import AppConfig, load_config
from .control.backend import ControlBackendManager
from .control.controller_manager import ControllerManager
from .control.rc_arbiter import RCArbiter
from .estimation.health_resolver import Estimator
from .estimation.sensor_snapshot import build_sensor_snapshot
from .io.mpu6050_reader import MPU6050Reader
from .io.pixhawk_mavlink import PixhawkMavlink
from .io.qr_camera_scanner import QRCameraScanner
from .io.server_client import ServerClient
from .io.tof10120_reader import ToF10120Reader
from .io.uwb_serial_reader import UWBSerialReader
from .logging.event_logger import EventLogger
from .logging.flight_logger import FlightLogger
from .mission.launch_guard import LaunchGuard
from .mission.mission_fsm import MissionFSM
from .safety.emergency_manager import EmergencyManager
from .types import FlightState, MissionFSMResult, RCChannels, RequiredAction, SensorSnapshot, ToFState


@dataclass
class Runtime:
    config: AppConfig
    uwb: UWBSerialReader
    tof: ToF10120Reader
    imu: MPU6050Reader
    pixhawk: PixhawkMavlink
    server: ServerClient
    qr_scanner: QRCameraScanner
    estimator: Estimator
    safety_manager: EmergencyManager
    mission_fsm: MissionFSM
    controller_manager: ControllerManager
    rc_arbiter: RCArbiter
    control_backend: ControlBackendManager
    flight_logger: FlightLogger
    event_logger: EventLogger
    launch_guard: LaunchGuard
    telemetry_seq: int = 0
    last_anchor_layout_attempt_id: str = ""
    last_anchor_layout_attempt_at: float = 0.0
    last_control_ack_attempt_key: str = ""
    last_control_ack_attempt_at: float = 0.0


def build_runtime(config: AppConfig) -> Runtime:
    log_dir = config.log_dir
    server = ServerClient(
        server_url=config.server_url,
        drone_id=config.drone_id,
        poll_s=config.mission_poll_s,
        device_auth_id=config.device_auth_id,
        device_auth_secret=config.device_auth_secret,
    )
    pixhawk = PixhawkMavlink(
        device=config.pixhawk_device,
        baud=config.pixhawk_baud,
        dry_run=config.simulation or config.control_mode == "dry_run",
    )
    return Runtime(
        config=config,
        uwb=UWBSerialReader(port=config.uwb_port, baud=config.uwb_baud, tof_alpha=config.tof_alpha),
        tof=ToF10120Reader(
            enabled=config.tof_enabled and config.tof_source == "pi",
            port=config.tof_port,
            baud=config.tof_baud,
            i2c_bus=config.tof_i2c_bus,
            i2c_addr=config.tof_i2c_addr,
            alpha=config.tof_alpha,
        ),
        imu=MPU6050Reader(
            enabled=config.imu_enabled,
            i2c_bus=config.imu_i2c_bus,
            i2c_addr=config.imu_i2c_addr,
            rate_hz=config.imu_rate_hz,
            calibration_s=config.imu_calibration_s,
            complementary_alpha=config.imu_complementary_alpha,
        ),
        pixhawk=pixhawk,
        server=server,
        qr_scanner=QRCameraScanner(config=config, server=server),
        estimator=Estimator(config),
        safety_manager=EmergencyManager(config),
        mission_fsm=MissionFSM(config),
        controller_manager=ControllerManager(config),
        rc_arbiter=RCArbiter(config),
        control_backend=ControlBackendManager(config, pixhawk),
        flight_logger=FlightLogger(log_dir),
        event_logger=EventLogger(log_dir),
        launch_guard=LaunchGuard(config),
    )


def start_runtime(runtime: Runtime) -> None:
    runtime.server.start()
    runtime.qr_scanner.start()
    if not runtime.config.simulation:
        runtime.uwb.start()
        runtime.tof.start()
        runtime.imu.start()
        runtime.pixhawk.start()


def stop_runtime(runtime: Runtime) -> None:
    runtime.server.stop()
    runtime.qr_scanner.stop()
    runtime.uwb.stop()
    runtime.tof.stop()
    runtime.imu.stop()
    runtime.pixhawk.stop()


def main(argv: list[str] | None = None) -> int:
    config = load_config(argv)
    runtime = build_runtime(config)
    start_runtime(runtime)
    runtime.event_logger.write(
        "COMPANION_START",
        drone_id=config.drone_id,
        companion_id=config.companion_id or socket.gethostname(),
        companion_platform=config.companion_platform,
        companion_version=__version__,
        uwb_port=config.uwb_port,
        uwb_baud=config.uwb_baud,
        dry_run_rc=config.dry_run_rc,
        control_mode=config.control_mode,
    )

    stop_requested = False

    def _signal_handler(signum: int, _frame: Any) -> None:
        nonlocal stop_requested
        stop_requested = True
        runtime.event_logger.write("COMPANION_STOP_REQUESTED", signal=signum)

    signal.signal(signal.SIGINT, _signal_handler)
    signal.signal(signal.SIGTERM, _signal_handler)

    period = 1.0 / max(1.0, config.loop_hz)
    takeoff_init_done = False
    posted_launch_snapshot_for = ""
    acked_control_request = ""
    last_qr_status_key = ""
    last_health_log_at = 0.0
    last_telemetry_at = 0.0

    try:
        while not stop_requested:
            loop_start = time.monotonic()
            server_mission = runtime.server.poll_if_due(loop_start)

            snapshot = build_sensor_snapshot(
                uwb=runtime.uwb.latest(loop_start),
                tof=_latest_tof(runtime, loop_start),
                imu=runtime.imu.latest(loop_start),
                fc=runtime.pixhawk.latest(loop_start),
                mission=server_mission,
                now=loop_start,
            )

            _sync_anchor_layout(runtime, snapshot)

            target_z = _active_target_z(runtime, snapshot)
            estimation = runtime.estimator.update(
                snapshot,
                state=runtime.mission_fsm.state,
                takeoff_phase=runtime.controller_manager.status().takeoff_phase,
                target_z_m=target_z,
            )
            control_probe = runtime.control_backend.update_selection(snapshot, estimation)
            posted_launch_snapshot_for = _maybe_post_launch_snapshot(
                runtime,
                snapshot,
                estimation,
                posted_launch_snapshot_for,
            )
            if snapshot.mission.mission_id and snapshot.mission.home_point:
                posted_launch_snapshot_for = snapshot.mission.mission_id

            safety = runtime.safety_manager.evaluate(snapshot, estimation, runtime.mission_fsm.state)
            qr_state = runtime.qr_scanner.latest()
            controller_status = replace(
                runtime.controller_manager.status(),
                scan_complete=qr_state.complete,
                scan_status=qr_state.status,
            )
            fsm_result = runtime.mission_fsm.update(
                snapshot=snapshot,
                estimation=estimation,
                safety=safety,
                controller_status=controller_status,
                control_probe=control_probe,
            )
            last_qr_status_key = _log_qr_status_if_changed(runtime, qr_state, last_qr_status_key)
            qr_state = _update_qr_scan(runtime, snapshot, fsm_result)

            if fsm_result.required_action == RequiredAction.INIT_TAKEOFF and not takeoff_init_done:
                _handle_takeoff_init(runtime, snapshot)
                takeoff_init_done = True
            elif fsm_result.state != FlightState.TAKEOFF_INIT:
                takeoff_init_done = False

            _handle_required_action(runtime, snapshot, fsm_result)

            requested_rc = runtime.controller_manager.compute(
                fsm_result=fsm_result,
                snapshot=snapshot,
                estimation=estimation,
                safety=safety,
            )
            controller_events = runtime.controller_manager.pop_events()
            final_rc = runtime.rc_arbiter.apply(
                requested_rc=requested_rc,
                state=fsm_result.state,
                phase=fsm_result.takeoff_phase,
                snapshot=snapshot,
                estimation=estimation,
                safety=safety,
            )
            backend_result = runtime.control_backend.dispatch(
                snapshot=snapshot,
                estimation=estimation,
                fsm_result=fsm_result,
                safety=safety,
                final_rc=final_rc,
            )

            all_events = fsm_result.events + controller_events
            for event in all_events:
                runtime.event_logger.write(event, state=fsm_result.state.value, reasons=safety.reasons)
            _post_phase_for_state(runtime, snapshot, fsm_result, safety)
            acked_control_request = _ack_control_action_if_handled(runtime, snapshot, fsm_result, acked_control_request)
            last_qr_status_key = _log_qr_status_if_changed(runtime, qr_state, last_qr_status_key)

            telemetry_period = 1.0 / max(1.0, runtime.config.telemetry_hz)
            if loop_start - last_telemetry_at >= telemetry_period:
                runtime.server.push_telemetry(_telemetry_payload(snapshot, estimation, fsm_result, safety, final_rc, qr_state, runtime))
                last_telemetry_at = loop_start
            last_health_log_at = _log_runtime_health_if_due(
                runtime,
                now=loop_start,
                last_logged_at=last_health_log_at,
                estimation=estimation,
                flight_state=fsm_result.state.value,
            )
            runtime.flight_logger.write(
                snapshot=snapshot,
                estimation=estimation,
                fsm_result=fsm_result,
                safety=safety,
                requested_rc=requested_rc,
                final_rc=final_rc,
                throttle_clamp_reason=runtime.rc_arbiter.last_clamp_reason,
                qr_state=qr_state,
                rc_writer=backend_result.reason,
                control_mode=runtime.control_backend.requested_mode,
                selected_mode=backend_result.selected_mode,
            )

            elapsed = time.monotonic() - loop_start
            if elapsed < period:
                time.sleep(period - elapsed)
    finally:
        stop_runtime(runtime)
        runtime.event_logger.write("COMPANION_STOP")
    return 0


def _sync_anchor_layout(runtime: Runtime, snapshot: SensorSnapshot) -> None:
    mission = snapshot.mission
    if not mission.anchor_layout_valid or not mission.anchor_layout_id or not mission.anchors:
        return
    tag_matches_server = (
        snapshot.uwb.tag_layout_synced
        and snapshot.uwb.anchor_layout_id == mission.anchor_layout_id
    )
    if runtime.uwb.last_anchor_layout_sent == mission.anchor_layout_id and tag_matches_server:
        return
    if (
        runtime.last_anchor_layout_attempt_id == mission.anchor_layout_id
        and snapshot.now - runtime.last_anchor_layout_attempt_at < 2.0
    ):
        return
    runtime.last_anchor_layout_attempt_id = mission.anchor_layout_id
    runtime.last_anchor_layout_attempt_at = snapshot.now
    if runtime.uwb.send_anchor_layout(layout_id=mission.anchor_layout_id, anchors=mission.anchors):
        runtime.event_logger.write("ANCHOR_LAYOUT_SENT", layout_id=mission.anchor_layout_id)


def _active_target_z(runtime: Runtime, snapshot: SensorSnapshot) -> float | None:
    active = runtime.mission_fsm.route_manager.active(snapshot.mission)
    if runtime.mission_fsm.state == FlightState.RETURN and snapshot.mission.home_point:
        active = snapshot.mission.home_point
    if active:
        return active.z_m
    return snapshot.mission.mission_target_alt_m


def _maybe_post_launch_snapshot(runtime: Runtime, snapshot: SensorSnapshot, estimation, posted_for: str) -> str:
    mission = snapshot.mission
    if not mission.launch_authorized or mission.home_point is not None:
        return posted_for
    if mission.mission_id and posted_for == mission.mission_id:
        return posted_for
    payload = runtime.launch_guard.build_launch_snapshot_payload(snapshot, estimation)
    if payload is None:
        return posted_for
    payload.update({
        "contract_version": "1.0",
        "mission_db_id": mission.mission_db_id,
        "mission_code": mission.mission_code,
        "captured_for_mission": mission.mission_id,
    })
    if runtime.server.post_launch_snapshot(payload):
        runtime.event_logger.write("LAUNCH_SNAPSHOT_POSTED", mission_id=mission.mission_id)
        return mission.mission_id or posted_for
    return posted_for


def _handle_takeoff_init(runtime: Runtime, snapshot: SensorSnapshot) -> None:
    runtime.controller_manager.reset_takeoff(snapshot)
    runtime.estimator.capture_takeoff_baselines(snapshot)
    tof_state = _capture_tof_ground_offset(runtime)
    runtime.event_logger.write(
        "TOF_GROUND_OFFSET_CAPTURED",
        ground_offset_m=tof_state.ground_offset_m,
        usable=tof_state.usable,
        reason=tof_state.reason,
    )


def _handle_required_action(runtime: Runtime, snapshot: SensorSnapshot, fsm_result: MissionFSMResult) -> None:
    if fsm_result.required_action == RequiredAction.ARM:
        block_reasons = runtime.control_backend.arm_block_reasons(snapshot)
        if block_reasons:
            runtime.event_logger.write("ARM_BLOCKED_CONTROL_BACKEND", reasons=block_reasons, fc_mode=snapshot.fc.mode)
            return
        if runtime.config.dry_run_rc:
            runtime.event_logger.write("ARM_SKIPPED_DRY_RUN_RC", fc_mode=snapshot.fc.mode)
            return
        runtime.pixhawk.arm()
    elif fsm_result.required_action == RequiredAction.DISARM:
        if runtime.config.dry_run_rc:
            runtime.event_logger.write("DISARM_SKIPPED_DRY_RUN_RC", fc_mode=snapshot.fc.mode)
            return
        runtime.pixhawk.disarm()


def _latest_tof(runtime: Runtime, now: float) -> ToFState:
    if not runtime.config.tof_enabled:
        return ToFState(reason="disabled").with_age(now)
    if runtime.config.tof_source == "uwb":
        return runtime.uwb.latest_tof(now)
    return runtime.tof.latest(now)


def _capture_tof_ground_offset(runtime: Runtime) -> ToFState:
    if not runtime.config.tof_enabled:
        return ToFState(reason="disabled")
    if runtime.config.tof_source == "uwb":
        return runtime.uwb.capture_tof_ground_offset()
    return runtime.tof.capture_ground_offset()


def _update_qr_scan(runtime: Runtime, snapshot: SensorSnapshot, fsm_result: MissionFSMResult):
    if fsm_result.state == FlightState.SCAN:
        return runtime.qr_scanner.request_scan(
            mission=snapshot.mission,
            waypoint=fsm_result.active_waypoint,
            drone_name=snapshot.mission.raw.get("drone_name") or snapshot.mission.raw.get("drone_id") or runtime.config.drone_id,
        )
    runtime.qr_scanner.cancel_scan()
    return runtime.qr_scanner.latest()


def _post_phase_for_state(runtime: Runtime, snapshot: SensorSnapshot, fsm_result: MissionFSMResult, safety) -> None:
    state = fsm_result.state
    mission_ref = {
        "mission_db_id": snapshot.mission.mission_db_id,
        "mission_code": snapshot.mission.mission_code,
    }
    if state in {
        FlightState.WAIT_FOR_TAKEOFF,
        FlightState.MOVE_TO_WAYPOINT,
        FlightState.WAIT_FOR_ARRIVAL,
        FlightState.SCAN,
        FlightState.NEXT_WAYPOINT,
    }:
        runtime.server.post_phase_once("in_flight", **mission_ref)
    elif state == FlightState.RETURN:
        runtime.server.post_phase_once("returning", **mission_ref)
    elif state == FlightState.LAND:
        runtime.server.post_phase_once("landing", **mission_ref)
    elif state == FlightState.FAILSAFE_LAND:
        runtime.server.post_phase_once("failed_returning", ",".join(safety.reasons), **mission_ref)
    elif state == FlightState.EMERGENCY_CUT:
        runtime.server.post_phase_once("failed", ",".join(safety.reasons), **mission_ref)
    elif state == FlightState.POWER_OFF:
        runtime.server.post_phase_once("completed", **mission_ref)


def _ack_control_action_if_handled(
    runtime: Runtime,
    snapshot: SensorSnapshot,
    fsm_result: MissionFSMResult,
    acked_control_request: str,
) -> str:
    action = snapshot.mission.control_action
    requested_at = snapshot.mission.control_requested_at or ""
    request_id = snapshot.mission.control_request_id
    key = request_id or f"{action}|{requested_at}"
    if not action or key == acked_control_request:
        return acked_control_request
    if runtime.last_control_ack_attempt_key == key and snapshot.now - runtime.last_control_ack_attempt_at < 0.5:
        return acked_control_request
    runtime.last_control_ack_attempt_key = key
    runtime.last_control_ack_attempt_at = snapshot.now
    if action == "return_to_home" and fsm_result.state == FlightState.RETURN:
        if runtime.server.ack_control_action(action, request_id=request_id, requested_at=requested_at):
            return key
    if action == "land" and fsm_result.state in {FlightState.LAND, FlightState.FAILSAFE_LAND}:
        if runtime.server.ack_control_action(action, request_id=request_id, requested_at=requested_at):
            return key
    return acked_control_request


def _log_qr_status_if_changed(runtime: Runtime, qr_state, previous_key: str) -> str:
    key = "|".join([
        qr_state.status.value,
        qr_state.client_scan_id,
        qr_state.waypoint_id,
        qr_state.last_error,
    ])
    if key == previous_key:
        return previous_key
    if qr_state.status.value in {"UPLOADED", "BUFFERED", "REJECTED", "FAILED", "SCANNING"}:
        runtime.event_logger.write(
            f"QR_SCAN_{qr_state.status.value}",
            client_scan_id=qr_state.client_scan_id,
            waypoint_id=qr_state.waypoint_id,
            mission_id=qr_state.mission_id,
            accepted=qr_state.accepted,
            buffered=qr_state.buffered,
            decoder=qr_state.decoder,
            error=qr_state.last_error,
            pending_buffer_count=qr_state.pending_buffer_count,
        )
    return key


def _telemetry_payload(
    snapshot: SensorSnapshot,
    estimation,
    fsm_result: MissionFSMResult,
    safety,
    final_rc: RCChannels,
    qr_state,
    runtime: Runtime,
) -> dict[str, Any]:
    probe_result = runtime.control_backend.last_probe_result.as_dict()
    runtime.telemetry_seq += 1
    sent_at_ms = int(time.time() * 1000)
    active_waypoint = runtime.mission_fsm.route_manager.active(snapshot.mission)
    return {
        "contract_version": "1.0",
        "type": "telemetry",
        "telemetry_source": "companion",
        "companion_link": True,
        "companion_platform": runtime.config.companion_platform,
        "companion_id": runtime.config.companion_id or socket.gethostname(),
        "companion_version": __version__,
        "telemetry_seq": runtime.telemetry_seq,
        "sent_at_ms": sent_at_ms,
        "uwb_seq": snapshot.uwb.seq,
        "uwb_age_ms": snapshot.uwb.age_ms,
        "mission_db_id": snapshot.mission.mission_db_id,
        "mission_code": snapshot.mission.mission_code,
        "route_revision": snapshot.mission.route_revision,
        "active_waypoint_index": runtime.mission_fsm.route_manager.index if active_waypoint else None,
        "active_waypoint_id": active_waypoint.point_id if active_waypoint else None,
        "fix": bool(estimation.xy_control_usable),
        "telemetry_verified": bool(estimation.xy_control_usable),
        "x": estimation.current_x_m,
        "y": estimation.current_y_m,
        "current_z_m": estimation.current_z_m,
        "current_z_source": estimation.current_z_source.value,
        "current_z_trusted": estimation.current_z_trusted,
        "current_z_confidence": estimation.current_z_confidence,
        "altitude_error_m": estimation.altitude_error_m,
        "mission_target_alt_m": snapshot.mission.mission_target_alt_m,
        "uwb_link": snapshot.uwb.uwb_link,
        "xy_control_usable": snapshot.uwb.xy_control_usable,
        "z_control_usable": snapshot.uwb.z_control_usable,
        "uwb_z_trusted": snapshot.uwb.z_trusted,
        "uwb_z_residual_m": snapshot.uwb.z_residual_m,
        "pose3d_fix": snapshot.uwb.pose4d_fix,
        "pose4d_fix": snapshot.uwb.pose4d_fix,
        "pose_quality": snapshot.uwb.pose_quality,
        "uwb4_residual_m": snapshot.uwb.uwb4_residual_m,
        "d1": snapshot.uwb.ranges[0] if len(snapshot.uwb.ranges) > 0 else None,
        "d2": snapshot.uwb.ranges[1] if len(snapshot.uwb.ranges) > 1 else None,
        "d3": snapshot.uwb.ranges[2] if len(snapshot.uwb.ranges) > 2 else None,
        "d4": snapshot.uwb.ranges[3] if len(snapshot.uwb.ranges) > 3 else None,
        "range_ok": snapshot.uwb.range_ok,
        "layout_version": snapshot.uwb.layout_version or snapshot.mission.anchor_layout_version,
        "anchor_layout_id": snapshot.mission.anchor_layout_id or snapshot.uwb.anchor_layout_id,
        "tag_layout_synced": snapshot.uwb.tag_layout_synced,
        "control_mode": runtime.control_backend.requested_mode,
        "selected_mode": runtime.control_backend.selected_mode,
        "control_backend_probe_result": probe_result,
        "fc_guided_probe_result": probe_result,
        "failure_reasons": probe_result.get("reasons", []),
        "imu": {
            "sensor": "MPU6050",
            "health": snapshot.imu.health,
            "calibrated": snapshot.imu.calibrated,
            "sample_rate_hz": snapshot.imu.sample_rate_hz,
            "roll_deg": snapshot.imu.roll_deg,
            "pitch_deg": snapshot.imu.pitch_deg,
            "roll_rate_dps": snapshot.imu.roll_rate_dps,
            "pitch_rate_dps": snapshot.imu.pitch_rate_dps,
            "yaw_rate_dps": snapshot.imu.yaw_rate_dps,
            "accel_norm_g": snapshot.imu.accel_norm_g,
            "linear_accel_z_mps2": snapshot.imu.linear_accel_z_mps2,
            "jerk_mps3": snapshot.imu.jerk_mps3,
            "vibration_score": snapshot.imu.vibration_score,
            "motion_state": snapshot.imu.motion_state,
            "tilt_ok": snapshot.imu.tilt_ok,
            "rate_ok": snapshot.imu.rate_ok,
            "shock_detected": snapshot.imu.shock_detected,
            "drift_status": snapshot.imu.drift_status,
            "temperature_c": snapshot.imu.temperature_c,
        },
        "battery": snapshot.fc.battery_remaining_pct,
        "battery_voltage": snapshot.fc.battery_voltage,
        "fc_connected": snapshot.fc.connected,
        "fc_armed": snapshot.fc.armed,
        "fc_mode": snapshot.fc.mode or None,
        "flight_state": fsm_result.state.value,
        "takeoff_phase": fsm_result.takeoff_phase.value if fsm_result.takeoff_phase else None,
        "safety_level": safety.level.value,
        "safety_reasons": safety.reasons,
        "qr_scan_status": qr_state.status.value,
        "qr_scan_active": qr_state.active,
        "qr_scan_complete": qr_state.complete,
        "qr_pending_buffer_count": qr_state.pending_buffer_count,
        "qr_last_error": qr_state.last_error,
        "final_rc": {
            "roll": final_rc.roll,
            "pitch": final_rc.pitch,
            "throttle": final_rc.throttle,
            "yaw": final_rc.yaw,
        },
        "t": sent_at_ms,
    }


def _log_runtime_health_if_due(
    runtime: Runtime,
    *,
    now: float,
    last_logged_at: float,
    estimation,
    flight_state: str,
) -> float:
    interval = max(0.0, runtime.config.diagnostic_interval_s)
    if interval == 0.0 or (last_logged_at and now - last_logged_at < interval):
        return last_logged_at

    payload = {
        "drone_id": runtime.config.drone_id,
        "flight_state": flight_state,
        "uwb": runtime.uwb.diagnostics(now),
        "server": runtime.server.diagnostics(now),
        "estimation": {
            "x": estimation.current_x_m,
            "y": estimation.current_y_m,
            "z": estimation.current_z_m,
            "xy_control_usable": estimation.xy_control_usable,
            "z_control_usable": estimation.z_control_usable,
            "health": estimation.health,
        },
    }
    runtime.event_logger.write("COMPANION_HEALTH", **payload)
    print(json.dumps({"event": "COMPANION_HEALTH", **payload}, ensure_ascii=False, separators=(",", ":")), flush=True)
    return now


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
