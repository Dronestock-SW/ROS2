#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BUNDLE_DIR="${BUNDLE_DIR:-$(cd "${SCRIPT_DIR}/../../.." && pwd)}"
VENV_DIR="${VENV_DIR:-${BUNDLE_DIR}/.venv-companion}"
SERVICE_USER="${SERVICE_USER:-${SUDO_USER:-$(whoami)}}"
SERVICE_GROUP="$(id -gn "${SERVICE_USER}")"
ENV_FILE="/etc/dronestock-companion.env"
SERVICE_FILE="/etc/systemd/system/dronestock-companion.service"
PREPARED_ENV="${SCRIPT_DIR}/companion.env.local"
if [[ ! -f "${PREPARED_ENV}" ]]; then
  PREPARED_ENV="${SCRIPT_DIR}/companion.env.example"
fi

if [[ "${EUID}" -ne 0 ]]; then
  echo "Run with sudo: sudo bash tools/companion/deploy/install_jetson.sh" >&2
  exit 1
fi

if [[ ! -f "${BUNDLE_DIR}/requirements-companion.txt" || ! -f "${BUNDLE_DIR}/tools/companion/app.py" ]]; then
  echo "Invalid bundle: requirements-companion.txt or tools/companion/app.py is missing." >&2
  exit 1
fi

echo "[companion-deploy] bundle=${BUNDLE_DIR}"
echo "[companion-deploy] service_user=${SERVICE_USER}"

apt-get update
apt-get install -y \
  python3-venv \
  python3-pip \
  python3-dev \
  i2c-tools \
  python3-smbus \
  libopenblas-dev \
  libzbar0

usermod -a -G dialout,i2c,video "${SERVICE_USER}" || true

PY_OK="$(python3 - <<'PY'
import sys
print("ok" if sys.version_info >= (3, 10) else "old")
PY
)"
if [[ "${PY_OK}" != "ok" ]]; then
  echo "Python 3.10 or newer is required. Installed: $(python3 --version)" >&2
  exit 1
fi

if [[ ! -d "${VENV_DIR}" ]]; then
  python3 -m venv "${VENV_DIR}" --system-site-packages
fi

"${VENV_DIR}/bin/python" -m pip install --upgrade pip wheel
"${VENV_DIR}/bin/python" -m pip install -r "${BUNDLE_DIR}/requirements-companion.txt"
"${VENV_DIR}/bin/python" -m pip install zxing-cpp || \
  echo "[companion-deploy] optional zxing-cpp install failed; QR fallback remains available."

if [[ ! -f "${ENV_FILE}" ]]; then
  install -m 0640 -o root -g "${SERVICE_GROUP}" "${PREPARED_ENV}" "${ENV_FILE}"
  echo "[companion-deploy] created ${ENV_FILE} from $(basename "${PREPARED_ENV}")"
else
  echo "[companion-deploy] preserving existing ${ENV_FILE}"
  echo "[companion-deploy] update only its server URL with:"
  echo "  sudo bash ${SCRIPT_DIR}/set_server_url.sh"
fi

sed \
  -e "s#__REPO_DIR__#${BUNDLE_DIR}#g" \
  -e "s#__VENV_DIR__#${VENV_DIR}#g" \
  -e "s#__USER__#${SERVICE_USER}#g" \
  "${SCRIPT_DIR}/dronestock-companion.service" > "${SERVICE_FILE}"

systemctl daemon-reload
systemctl enable dronestock-companion.service

echo
echo "[companion-deploy] installation complete; the service was not started automatically."
echo "1. Edit ${ENV_FILE}"
echo "2. Test UWB serial:"
echo "   ${VENV_DIR}/bin/python ${BUNDLE_DIR}/tools/companion/deploy/check_uwb_serial.py --seconds 15 --require-fix"
echo "3. Start the runtime:"
echo "   sudo systemctl restart dronestock-companion"
echo "   sudo journalctl -u dronestock-companion -f"
