from __future__ import annotations

from dataclasses import dataclass

from ..config import AppConfig
from ..types import IMUState, SafetyLevel


@dataclass(frozen=True)
class IMUSafetyResult:
    level: SafetyLevel
    reasons: list[str]


class IMUSafetyMonitor:
    """Monitor MPU6050 for unsafe tilt/yaw-rate.

    The MPU6050 is not used for attitude control here. It only contributes to
    safety decisions.
    """

    def __init__(self, config: AppConfig) -> None:
        self.config = config
        self._tilt_exceeded_since: float | None = None

    def evaluate(self, imu: IMUState, now: float) -> IMUSafetyResult:
        if not imu.usable:
            return IMUSafetyResult(SafetyLevel.WARN, [f"imu_unusable:{imu.reason}"])
        if imu.roll_deg is None or imu.pitch_deg is None or imu.yaw_rate_dps is None:
            return IMUSafetyResult(SafetyLevel.WARN, ["imu_incomplete"])

        tilt = max(abs(imu.roll_deg), abs(imu.pitch_deg))
        rate = max(
            abs(imu.roll_rate_dps or 0.0),
            abs(imu.pitch_rate_dps or 0.0),
            abs(imu.yaw_rate_dps or 0.0),
        )
        accel_norm = abs(imu.accel_norm_g or 1.0)
        jerk = abs(imu.jerk_mps3 or 0.0)
        vibration = abs(imu.vibration_score or 0.0)
        reasons: list[str] = []
        level = SafetyLevel.OK

        if tilt >= self.config.imu_tilt_abort_deg:
            return IMUSafetyResult(SafetyLevel.EMERGENCY_CUT, [f"IMU_TILT_ABORT:{tilt:.1f}"])
        if rate >= self.config.imu_rate_abort_dps:
            return IMUSafetyResult(SafetyLevel.EMERGENCY_CUT, [f"IMU_RATE_ABORT:{rate:.1f}"])
        if accel_norm >= self.config.imu_accel_abort_g or jerk >= self.config.imu_jerk_abort_mps3:
            return IMUSafetyResult(SafetyLevel.EMERGENCY_CUT, [f"IMU_SHOCK_DETECTED:{accel_norm:.2f}g:{jerk:.1f}"])
        if vibration >= self.config.imu_vibration_abort:
            return IMUSafetyResult(SafetyLevel.EMERGENCY_CUT, [f"IMU_VIBRATION_HIGH:{vibration:.3f}"])

        if tilt >= self.config.imu_tilt_block_deg:
            if self._tilt_exceeded_since is None:
                self._tilt_exceeded_since = now
            if now - self._tilt_exceeded_since >= self.config.failsafe_tilt_hold_s:
                level = SafetyLevel.FAILSAFE_LAND
                reasons.append(f"IMU_TILT_BLOCK:{tilt:.1f}")
        else:
            self._tilt_exceeded_since = None

        if rate >= self.config.imu_rate_block_dps:
            level = SafetyLevel.FAILSAFE_LAND
            reasons.append(f"IMU_RATE_BLOCK:{rate:.1f}")
        if accel_norm >= self.config.imu_accel_block_g or jerk >= self.config.imu_jerk_block_mps3:
            level = SafetyLevel.FAILSAFE_LAND
            reasons.append(f"IMU_SHOCK_DETECTED:{accel_norm:.2f}g:{jerk:.1f}")
        if vibration >= self.config.imu_vibration_block:
            level = SafetyLevel.FAILSAFE_LAND
            reasons.append(f"IMU_VIBRATION_HIGH:{vibration:.3f}")

        if not reasons and (tilt >= self.config.imu_tilt_warn_deg or rate >= self.config.imu_rate_warn_dps):
            level = SafetyLevel.WARN
            reasons.append(f"imu_warn:tilt={tilt:.1f}:rate={rate:.1f}")

        return IMUSafetyResult(level, reasons or ["ok"])
