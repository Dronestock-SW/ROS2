from __future__ import annotations

import argparse
import os
from dataclasses import dataclass
from pathlib import Path


def _env_bool(name: str, default: bool) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _env_float(name: str, default: float) -> float:
    value = os.getenv(name)
    if value is None:
        return default
    try:
        return float(value)
    except ValueError:
        return default


def _env_int(name: str, default: int) -> int:
    value = os.getenv(name)
    if value is None:
        return default
    try:
        return int(value)
    except ValueError:
        return default


@dataclass(frozen=True)
class AppConfig:
    drone_id: str = "5"
    server_url: str = "http://127.0.0.1:8000"
    loop_hz: float = 20.0
    telemetry_hz: float = 10.0
    log_dir: Path = Path("logs/companion")
    diagnostic_interval_s: float = 5.0
    companion_platform: str = "linux-companion"
    companion_id: str = ""
    device_auth_id: str = ""
    device_auth_secret: str = ""

    uwb_port: str = "/dev/ttyUSB0"
    uwb_baud: int = 921600
    pixhawk_device: str = "/dev/serial0"
    pixhawk_baud: int = 57600

    tof_enabled: bool = True
    tof_source: str = "pi"
    tof_port: str = ""
    tof_baud: int = 115200
    tof_i2c_bus: int = 1
    tof_i2c_addr: int = 0x52
    tof_alpha: float = 0.35

    imu_enabled: bool = True
    imu_i2c_bus: int = 1
    imu_i2c_addr: int = 0x68
    imu_rate_hz: int = 100
    imu_calibration_s: float = 3.0
    imu_complementary_alpha: float = 0.98
    imu_tilt_warn_deg: float = 8.0
    imu_tilt_block_deg: float = 12.0
    imu_tilt_abort_deg: float = 18.0
    imu_rate_warn_dps: float = 80.0
    imu_rate_block_dps: float = 120.0
    imu_rate_abort_dps: float = 180.0
    imu_accel_warn_g: float = 1.6
    imu_accel_block_g: float = 2.0
    imu_accel_abort_g: float = 2.5
    imu_jerk_warn_mps3: float = 20.0
    imu_jerk_block_mps3: float = 35.0
    imu_jerk_abort_mps3: float = 50.0
    imu_vibration_warn: float = 0.08
    imu_vibration_block: float = 0.12
    imu_vibration_abort: float = 0.18

    qr_enabled: bool = True
    qr_camera_backend: str = "picamera2"
    qr_camera_source: str = "0"
    qr_camera_width: int = 1280
    qr_camera_height: int = 720
    qr_scan_timeout_s: float = 8.0
    qr_scan_cooldown_s: float = 3.0
    qr_upload_retry_count: int = 3
    qr_buffer_path: Path = Path("/tmp/companion_scan_buffer.jsonl")
    qr_buffer_flush_s: float = 15.0

    require_uwb: bool = True
    require_tof: bool = True
    require_imu: bool = True
    require_pixhawk: bool = True
    require_server: bool = True

    uwb_max_age_ms: int = 120
    tof_max_age_ms: int = 250
    imu_max_age_ms: int = 250
    fc_max_age_ms: int = 1000
    server_max_age_ms: int = 3000
    mission_poll_s: float = 0.5

    takeoff_target_z_m: float = 0.50
    takeoff_ready_hold_s: float = 2.0
    takeoff_armed_idle_s: float = 0.30
    takeoff_start_pwm: int = 1000
    takeoff_prespin_pwm: int = 1350
    takeoff_max_pwm: int = 1500
    takeoff_fast_ramp_pwm_s: float = 80.0
    takeoff_slow_ramp_pwm_s: float = 15.0
    liftoff_confirm_s: float = 0.18
    climb_capture_hold_s: float = 0.35
    initial_hover_s: float = 1.5
    xy_stability_s: float = 1.0
    max_z_speed_mps: float = 0.15
    max_xy_speed_mps: float = 0.15
    max_xy_step_m: float = 0.05
    max_yaw_rate_dps: float = 12.0
    uwb_residual_control_max_m: float = 0.15
    uwb_tof_z_diff_max_m: float = 0.15

    hover_throttle_pwm: int = 1500
    altitude_kp_pwm_per_m: float = 220.0
    altitude_ki_pwm_per_m_s: float = 35.0
    altitude_kd_pwm_per_mps: float = 70.0
    altitude_integrator_limit_pwm: float = 80.0
    altitude_output_min_pwm: int = 1200
    altitude_output_max_pwm: int = 1600

    xy_kp_pwm_per_m: float = 80.0
    xy_roll_limit_pwm: int = 30
    xy_pitch_limit_pwm: int = 30
    yaw_limit_pwm: int = 30
    waypoint_radius_m: float = 0.20
    waypoint_z_radius_m: float = 0.15
    waypoint_dwell_s: float = 0.7

    throttle_min_pwm: int = 1000
    throttle_max_pwm: int = 1700
    throttle_rate_limit_pwm_s: float = 120.0
    failsafe_descent_pwm_s: float = 35.0
    landing_descent_pwm_s: float = 45.0

    warn_tilt_deg: float = 25.0
    failsafe_tilt_deg: float = 35.0
    failsafe_tilt_hold_s: float = 0.35
    emergency_tilt_deg: float = 60.0
    failsafe_yaw_rate_dps: float = 180.0
    emergency_yaw_rate_dps: float = 300.0

    simulation: bool = False
    dry_run_rc: bool = False
    control_mode: str = "companion_rc"
    companion_rc_flight_mode: str = "LOITER"
    allow_prearm_fallback_to_rc: bool = True
    forbid_inflight_backend_switch: bool = True
    yaw_alignment_ready: bool = False

    @classmethod
    def from_env(cls) -> "AppConfig":
        return cls(
            drone_id=os.getenv("DRONESTOCK_DRONE_ID", "5"),
            server_url=os.getenv("DRONESTOCK_SERVER_URL", "http://127.0.0.1:8000").rstrip("/"),
            loop_hz=_env_float("DRONESTOCK_LOOP_HZ", 20.0),
            telemetry_hz=_env_float("DRONESTOCK_TELEMETRY_HZ", 10.0),
            log_dir=Path(os.getenv("DRONESTOCK_COMPANION_LOG_DIR", "logs/companion")),
            diagnostic_interval_s=_env_float("DRONESTOCK_DIAGNOSTIC_INTERVAL_S", 5.0),
            companion_platform=os.getenv("DRONESTOCK_COMPANION_PLATFORM", "linux-companion").strip() or "linux-companion",
            companion_id=os.getenv("DRONESTOCK_COMPANION_ID", "").strip(),
            device_auth_id=os.getenv("DRONESTOCK_DEVICE_AUTH_ID", "").strip(),
            device_auth_secret=os.getenv("DRONESTOCK_DEVICE_AUTH_SECRET", ""),
            uwb_port=os.getenv("DRONESTOCK_UWB_PORT", "/dev/ttyUSB0"),
            uwb_baud=_env_int("DRONESTOCK_UWB_BAUD", 921600),
            pixhawk_device=os.getenv("DRONESTOCK_PIXHAWK_DEVICE", "/dev/serial0"),
            pixhawk_baud=_env_int("DRONESTOCK_PIXHAWK_BAUD", 57600),
            tof_enabled=_env_bool("DRONESTOCK_TOF_ENABLED", True),
            tof_source=os.getenv("DRONESTOCK_TOF_SOURCE", "pi").strip().lower(),
            tof_port=os.getenv("DRONESTOCK_TOF_PORT", ""),
            tof_baud=_env_int("DRONESTOCK_TOF_BAUD", 115200),
            tof_i2c_bus=_env_int("DRONESTOCK_TOF_I2C_BUS", 1),
            tof_i2c_addr=int(os.getenv("DRONESTOCK_TOF_I2C_ADDR", "0x52"), 0),
            tof_alpha=_env_float("DRONESTOCK_TOF_ALPHA", 0.35),
            imu_enabled=_env_bool("DRONESTOCK_MPU6050_ENABLED", _env_bool("DRONESTOCK_IMU_ENABLED", True)),
            imu_i2c_bus=_env_int("DRONESTOCK_MPU6050_I2C_BUS", _env_int("DRONESTOCK_IMU_I2C_BUS", 1)),
            imu_i2c_addr=int(os.getenv("DRONESTOCK_MPU6050_I2C_ADDR", os.getenv("DRONESTOCK_IMU_I2C_ADDR", "0x68")), 0),
            imu_rate_hz=_env_int("DRONESTOCK_MPU6050_RATE_HZ", _env_int("DRONESTOCK_MPU_RATE_HZ", 100)),
            imu_calibration_s=_env_float("DRONESTOCK_MPU_CALIBRATION_S", 3.0),
            imu_complementary_alpha=_env_float("DRONESTOCK_MPU_COMPLEMENTARY_ALPHA", 0.98),
            imu_tilt_warn_deg=_env_float("DRONESTOCK_MPU_TILT_WARN_DEG", 8.0),
            imu_tilt_block_deg=_env_float("DRONESTOCK_MPU_TILT_BLOCK_DEG", 12.0),
            imu_tilt_abort_deg=_env_float("DRONESTOCK_MPU_TILT_ABORT_DEG", 18.0),
            imu_rate_warn_dps=_env_float("DRONESTOCK_MPU_RATE_WARN_DPS", 80.0),
            imu_rate_block_dps=_env_float("DRONESTOCK_MPU_RATE_BLOCK_DPS", 120.0),
            imu_rate_abort_dps=_env_float("DRONESTOCK_MPU_RATE_ABORT_DPS", 180.0),
            imu_accel_warn_g=_env_float("DRONESTOCK_MPU_ACCEL_WARN_G", 1.6),
            imu_accel_block_g=_env_float("DRONESTOCK_MPU_ACCEL_BLOCK_G", 2.0),
            imu_accel_abort_g=_env_float("DRONESTOCK_MPU_ACCEL_ABORT_G", 2.5),
            imu_jerk_warn_mps3=_env_float("DRONESTOCK_MPU_JERK_WARN_MPS3", 20.0),
            imu_jerk_block_mps3=_env_float("DRONESTOCK_MPU_JERK_BLOCK_MPS3", 35.0),
            imu_jerk_abort_mps3=_env_float("DRONESTOCK_MPU_JERK_ABORT_MPS3", 50.0),
            imu_vibration_warn=_env_float("DRONESTOCK_MPU_VIBRATION_WARN", 0.08),
            imu_vibration_block=_env_float("DRONESTOCK_MPU_VIBRATION_BLOCK", 0.12),
            imu_vibration_abort=_env_float("DRONESTOCK_MPU_VIBRATION_ABORT", 0.18),
            qr_enabled=_env_bool("DRONESTOCK_QR_ENABLED", True),
            qr_camera_backend=os.getenv("DRONESTOCK_QR_CAMERA_BACKEND", "picamera2"),
            qr_camera_source=os.getenv("DRONESTOCK_QR_CAMERA_SOURCE", "0"),
            qr_camera_width=_env_int("DRONESTOCK_QR_CAMERA_WIDTH", 1280),
            qr_camera_height=_env_int("DRONESTOCK_QR_CAMERA_HEIGHT", 720),
            qr_scan_timeout_s=_env_float("DRONESTOCK_QR_SCAN_TIMEOUT_S", 8.0),
            qr_scan_cooldown_s=_env_float("DRONESTOCK_QR_SCAN_COOLDOWN_S", 3.0),
            qr_upload_retry_count=_env_int("DRONESTOCK_QR_UPLOAD_RETRY_COUNT", 3),
            qr_buffer_path=Path(os.getenv("DRONESTOCK_QR_BUFFER_PATH", "/tmp/companion_scan_buffer.jsonl")),
            qr_buffer_flush_s=_env_float("DRONESTOCK_QR_BUFFER_FLUSH_S", 15.0),
            require_uwb=_env_bool("DRONESTOCK_REQUIRE_UWB", True),
            require_tof=_env_bool("DRONESTOCK_REQUIRE_TOF", True),
            require_imu=_env_bool("DRONESTOCK_REQUIRE_IMU", True),
            require_pixhawk=_env_bool("DRONESTOCK_REQUIRE_PIXHAWK", True),
            require_server=_env_bool("DRONESTOCK_REQUIRE_SERVER", True),
            control_mode=os.getenv("DRONESTOCK_CONTROL_MODE", "companion_rc").strip().lower(),
            companion_rc_flight_mode=os.getenv("DRONESTOCK_COMPANION_RC_FC_MODE", "LOITER").strip().upper(),
            allow_prearm_fallback_to_rc=_env_bool("DRONESTOCK_ALLOW_PREARM_FALLBACK_TO_RC", True),
            forbid_inflight_backend_switch=_env_bool("DRONESTOCK_FORBID_INFLIGHT_BACKEND_SWITCH", True),
            yaw_alignment_ready=_env_bool("DRONESTOCK_YAW_ALIGNMENT_READY", False),
            max_z_speed_mps=_env_float("DRONESTOCK_MAX_Z_SPEED_MPS", 0.15),
            max_xy_speed_mps=_env_float("DRONESTOCK_MAX_XY_SPEED_MPS", 0.15),
            max_xy_step_m=_env_float("DRONESTOCK_MAX_XY_STEP_M", 0.05),
            max_yaw_rate_dps=_env_float("DRONESTOCK_MAX_YAW_RATE_DPS", 12.0),
            takeoff_target_z_m=_env_float("DRONESTOCK_TAKEOFF_TARGET_M", 0.50),
            takeoff_prespin_pwm=_env_int("DRONESTOCK_RC_TAKEOFF_PWM_START", 1370),
            takeoff_max_pwm=_env_int("DRONESTOCK_RC_TAKEOFF_PWM_INITIAL_CEIL", 1500),
            throttle_rate_limit_pwm_s=_env_float("DRONESTOCK_RC_PWM_SLEW_PER_SEC", 30.0),
            climb_capture_hold_s=_env_float("DRONESTOCK_RC_LIFTOFF_CAPTURE_S", 0.35),
            initial_hover_s=_env_float("DRONESTOCK_HOVER_SETTLE_S", 2.0),
            uwb_residual_control_max_m=_env_float("DRONESTOCK_UWB_RESIDUAL_CONTROL_MAX_M", 0.15),
            uwb_tof_z_diff_max_m=_env_float("DRONESTOCK_UWB_TOF_Z_DIFF_MAX_M", 0.15),
            uwb_max_age_ms=_env_int("DRONESTOCK_UWB_MAX_AGE_MS", _env_int("DRONESTOCK_SENSOR_STALE_MS", 120)),
            tof_max_age_ms=_env_int("DRONESTOCK_SENSOR_STALE_MS", 250),
            imu_max_age_ms=_env_int("DRONESTOCK_SENSOR_STALE_MS", 250),
            simulation=_env_bool("DRONESTOCK_SIMULATION", False),
            dry_run_rc=_env_bool("DRONESTOCK_DRY_RUN_RC", False),
        )

    def with_args(self, args: argparse.Namespace) -> "AppConfig":
        updates = {}
        for field_name in (
            "drone_id",
            "server_url",
            "uwb_port",
            "pixhawk_device",
            "pixhawk_baud",
            "loop_hz",
            "diagnostic_interval_s",
        ):
            value = getattr(args, field_name, None)
            if value not in (None, ""):
                updates[field_name] = value
        if getattr(args, "log_dir", None):
            updates["log_dir"] = Path(args.log_dir)
        if args.no_tof:
            updates["tof_enabled"] = False
            updates["require_tof"] = False
        if args.no_imu:
            updates["imu_enabled"] = False
            updates["require_imu"] = False
        if args.no_qr:
            updates["qr_enabled"] = False
        if args.simulation:
            updates["simulation"] = True
            updates["dry_run_rc"] = True
            updates["require_uwb"] = False
            updates["require_tof"] = False
            updates["require_imu"] = False
            updates["require_pixhawk"] = False
            updates["require_server"] = False
            updates["qr_enabled"] = False
        if args.dry_run_rc:
            updates["dry_run_rc"] = True
        if getattr(args, "control_mode", None):
            updates["control_mode"] = args.control_mode
            if args.control_mode == "dry_run":
                updates["dry_run_rc"] = True
        return self.__class__(**{**self.__dict__, **updates})


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="DroneStock Raspberry Pi companion runtime")
    parser.add_argument("--drone-id", dest="drone_id", help="Drone ID used by the web server")
    parser.add_argument("--server-url", dest="server_url", help="Django server base URL")
    parser.add_argument("--uwb-port", dest="uwb_port", help="USB serial port connected to ESP32 UWB tag")
    parser.add_argument("--pixhawk-device", dest="pixhawk_device", help="Pixhawk MAVLink serial device")
    parser.add_argument("--pixhawk-baud", dest="pixhawk_baud", type=int, help="Pixhawk MAVLink baudrate")
    parser.add_argument("--loop-hz", dest="loop_hz", type=float, help="Main control loop rate")
    parser.add_argument("--diagnostic-interval", dest="diagnostic_interval_s", type=float, help="Seconds between secret-free health logs; use 0 to disable")
    parser.add_argument("--log-dir", dest="log_dir", help="Companion log directory")
    parser.add_argument("--no-tof", action="store_true", help="Do not require/read ToF10120")
    parser.add_argument("--no-imu", action="store_true", help="Do not require/read MPU6050")
    parser.add_argument("--no-qr", action="store_true", help="Disable CSI/V4L2 QR camera scanning")
    parser.add_argument("--dry-run-rc", action="store_true", help="Compute final RC but do not send to Pixhawk")
    parser.add_argument("--control-mode", choices=["companion_rc", "dry_run", "fc_guided"], help="Control backend; fc_guided is accepted as legacy and normalized to companion_rc")
    parser.add_argument("--simulation", action="store_true", help="Start without hardware requirements")
    return parser


def load_config(argv: list[str] | None = None) -> AppConfig:
    args = build_arg_parser().parse_args(argv)
    return AppConfig.from_env().with_args(args)
