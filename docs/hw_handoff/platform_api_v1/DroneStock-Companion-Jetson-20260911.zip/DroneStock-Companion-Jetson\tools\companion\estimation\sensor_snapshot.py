from __future__ import annotations

import time

from ..types import FCState, IMUState, MissionState, SensorSnapshot, ToFState, UWBState


def build_sensor_snapshot(
    *,
    uwb: UWBState,
    tof: ToFState,
    imu: IMUState,
    fc: FCState,
    mission: MissionState,
    now: float | None = None,
) -> SensorSnapshot:
    now = time.monotonic() if now is None else now
    return SensorSnapshot(
        uwb=uwb.with_age(now),
        tof=tof.with_age(now),
        imu=imu.with_age(now),
        fc=fc.with_age(now),
        mission=mission.with_age(now),
        now=now,
    )

