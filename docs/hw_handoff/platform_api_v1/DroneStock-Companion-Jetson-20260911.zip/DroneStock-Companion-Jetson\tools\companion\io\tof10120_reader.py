from __future__ import annotations

import json
import statistics
import threading
import time
from collections import deque
from dataclasses import replace
from typing import Any

from ..types import ToFState, finite_bool, finite_float

try:  # pragma: no cover - hardware path
    import serial
except ImportError:  # pragma: no cover
    serial = None

try:  # pragma: no cover - hardware path
    from smbus2 import SMBus
except ImportError:  # pragma: no cover
    SMBus = None


class ToF10120Reader:
    """Read a downward ToF10120 range sensor.

    The output is altitude sensor data only. No XY, waypoint, or throttle logic
    is allowed here.
    """

    def __init__(
        self,
        *,
        enabled: bool = True,
        port: str = "",
        baud: int = 115200,
        i2c_bus: int = 1,
        i2c_addr: int = 0x52,
        alpha: float = 0.35,
    ) -> None:
        self.enabled = enabled
        self.port = port
        self.baud = baud
        self.i2c_bus = i2c_bus
        self.i2c_addr = i2c_addr
        self.alpha = max(0.01, min(1.0, alpha))
        self._lock = threading.Lock()
        self._latest = ToFState(reason="disabled" if not enabled else "not_started")
        self._ground_offset_m: float | None = None
        self._recent_distances: deque[float] = deque(maxlen=30)
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()

    def start(self) -> None:
        if not self.enabled:
            return
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, name="tof10120-reader", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()

    def latest(self, now: float | None = None) -> ToFState:
        now = time.monotonic() if now is None else now
        with self._lock:
            return self._latest.with_age(now)

    def capture_ground_offset(self) -> ToFState:
        with self._lock:
            samples = list(self._recent_distances)
            if not samples:
                self._latest = replace(self._latest, usable=False, reason="ground_offset_no_samples")
                return self._latest
            self._ground_offset_m = statistics.median(samples)
            self._latest = self._with_ground_offset_locked(self._latest)
            return self._latest

    def _run(self) -> None:  # pragma: no cover - hardware loop
        if self.port:
            self._run_serial()
            return
        self._run_i2c()

    def _run_serial(self) -> None:  # pragma: no cover
        if serial is None:
            self._set_error("pyserial_missing")
            return
        while not self._stop.is_set():
            try:
                with serial.Serial(self.port, self.baud, timeout=0.2) as ser:
                    while not self._stop.is_set():
                        raw = ser.readline()
                        if not raw:
                            continue
                        line = raw.decode("utf-8", errors="ignore").strip()
                        distance_m = _parse_distance_line(line)
                        if distance_m is not None:
                            self._record_distance(distance_m)
            except Exception as exc:
                self._set_error(f"serial_error:{exc}")
                time.sleep(1.0)

    def _run_i2c(self) -> None:  # pragma: no cover
        if SMBus is None:
            self._set_error("smbus2_missing")
            return
        while not self._stop.is_set():
            try:
                with SMBus(self.i2c_bus) as bus:
                    while not self._stop.is_set():
                        block = bus.read_i2c_block_data(self.i2c_addr, 0x00, 2)
                        distance_mm = (int(block[0]) << 8) | int(block[1])
                        if 20 <= distance_mm <= 12000:
                            self._record_distance(distance_mm / 1000.0)
                        time.sleep(0.05)
            except Exception as exc:
                self._set_error(f"i2c_error:{exc}")
                time.sleep(1.0)

    def _record_distance(self, raw_distance_m: float) -> None:
        now = time.monotonic()
        with self._lock:
            prev = self._latest
            filtered = raw_distance_m
            if prev.filtered_distance_m is not None:
                filtered = self.alpha * raw_distance_m + (1.0 - self.alpha) * prev.filtered_distance_m
            self._recent_distances.append(filtered)
            vertical_speed = None
            if prev.filtered_distance_m is not None and prev.received_monotonic is not None:
                dt = max(1e-3, now - prev.received_monotonic)
                vertical_speed = (filtered - prev.filtered_distance_m) / dt
            state = ToFState(
                raw_distance_m=raw_distance_m,
                filtered_distance_m=filtered,
                ground_offset_m=self._ground_offset_m,
                vertical_speed_mps=vertical_speed,
                usable=True,
                reason="ok",
                confidence=1.0,
                received_monotonic=now,
            )
            self._latest = self._with_ground_offset_locked(state)

    def _with_ground_offset_locked(self, state: ToFState) -> ToFState:
        if self._ground_offset_m is None or state.filtered_distance_m is None:
            return replace(state, ground_offset_m=self._ground_offset_m, altitude_m=None)
        altitude = max(0.0, state.filtered_distance_m - self._ground_offset_m)
        return replace(state, ground_offset_m=self._ground_offset_m, altitude_m=altitude)

    def _set_error(self, reason: str) -> None:
        with self._lock:
            self._latest = replace(self._latest, usable=False, reason=reason, received_monotonic=time.monotonic())


def _parse_distance_line(line: str) -> float | None:
    if not line:
        return None
    try:
        payload = json.loads(line)
        if isinstance(payload, dict):
            if not finite_bool(payload.get("usable"), True):
                return None
            value = finite_float(payload.get("distance_m"))
            if value is None:
                value = finite_float(payload.get("raw_distance_m"))
            if value is None:
                mm = finite_float(payload.get("distance_mm"))
                value = mm / 1000.0 if mm is not None else None
            return _valid_distance(value)
    except json.JSONDecodeError:
        pass

    token = "".join(ch if (ch.isdigit() or ch in ".-") else " " for ch in line).split()
    if not token:
        return None
    number = finite_float(token[0])
    if number is None:
        return None
    if number > 20.0:
        number = number / 1000.0
    return _valid_distance(number)


def _valid_distance(value: float | None) -> float | None:
    if value is None:
        return None
    if 0.02 <= value <= 12.0:
        return value
    return None
