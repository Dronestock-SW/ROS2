"""Mission gating and finite-state machine."""

