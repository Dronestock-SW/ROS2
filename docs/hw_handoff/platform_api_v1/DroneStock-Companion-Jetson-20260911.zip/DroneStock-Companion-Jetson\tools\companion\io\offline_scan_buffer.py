from __future__ import annotations

import json
import threading
from pathlib import Path
from typing import Any, Callable


class OfflineScanBuffer:
    """JSONL buffer for QR scans captured while Wi-Fi/server upload is down."""

    def __init__(self, path: Path, *, max_attempts: int = 20) -> None:
        self.path = path
        self.dead_path = path.with_suffix(path.suffix + ".dead")
        self.max_attempts = max_attempts
        self._lock = threading.Lock()
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def push(self, payload: dict[str, Any]) -> None:
        record = dict(payload)
        record.setdefault("attempts", 0)
        with self._lock:
            with self.path.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps(record, ensure_ascii=True, separators=(",", ":")) + "\n")

    def count(self) -> int:
        with self._lock:
            return len(self._read_all_locked())

    def flush(self, upload_fn: Callable[[dict[str, Any]], dict[str, Any]]) -> tuple[int, int, int]:
        """Flush pending records.

        Returns `(sent, kept, dead)`.
        """
        with self._lock:
            records = self._read_all_locked()
            if not records:
                return 0, 0, 0

            sent = 0
            kept: list[dict[str, Any]] = []
            dead: list[dict[str, Any]] = []
            for record in records:
                upload_payload = {
                    key: value
                    for key, value in record.items()
                    if key not in {"attempts", "last_error"}
                }
                result = upload_fn(upload_payload)
                if result.get("ok"):
                    sent += 1
                    continue
                attempts = int(record.get("attempts") or 0) + 1
                record["attempts"] = attempts
                record["last_error"] = result.get("error") or result.get("msg") or "upload_failed"
                if attempts >= self.max_attempts:
                    dead.append(record)
                else:
                    kept.append(record)

            self._write_all_locked(kept)
            if dead:
                with self.dead_path.open("a", encoding="utf-8") as fh:
                    for record in dead:
                        fh.write(json.dumps(record, ensure_ascii=True, separators=(",", ":")) + "\n")
            return sent, len(kept), len(dead)

    def _read_all_locked(self) -> list[dict[str, Any]]:
        if not self.path.exists():
            return []
        records: list[dict[str, Any]] = []
        with self.path.open("r", encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                try:
                    payload = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if isinstance(payload, dict):
                    records.append(payload)
        return records

    def _write_all_locked(self, records: list[dict[str, Any]]) -> None:
        if not records:
            self.path.write_text("", encoding="utf-8")
            return
        with self.path.open("w", encoding="utf-8") as fh:
            for record in records:
                fh.write(json.dumps(record, ensure_ascii=True, separators=(",", ":")) + "\n")
