from __future__ import annotations

import csv
import time
from pathlib import Path

from ..types import EstimationState, MissionFSMResult, RCChannels, SafetyState, SensorSnapshot


class FlightLogger:
    FIELDS = [
        "ts",
        "flight_state",
        "takeoff_phase",
        "requested_roll",
        "requested_pitch",
        "requested_throttle",
        "requested_yaw",
        "final_roll",
        "final_pitch",
        "final_throttle",
        "final_yaw",
        "throttle_clamp_reason",
        "rc_writer",
        "uwb_x",
        "uwb_y",
        "uwb_z_control",
        "uwb_xy_control_usable",
        "uwb_z_control_usable",
        "tof_raw",
        "tof_filtered",
        "tof_offset",
        "tof_altitude",
        "tof_usable",
        "imu_roll",
        "imu_pitch",
        "imu_roll_rate",
        "imu_pitch_rate",
        "imu_yaw_rate",
        "imu_accel_norm_g",
        "imu_jerk_mps3",
        "imu_vibration_score",
        "imu_motion_state",
        "imu_usable",
        "fc_armed",
        "fc_mode",
        "fc_relative_alt",
        "fc_yaw",
        "current_z_m",
        "current_z_source",
        "pose_quality",
        "uwb4_residual_m",
        "control_mode",
        "selected_mode",
        "active_waypoint",
        "qr_scan_status",
        "qr_client_scan_id",
        "qr_pending_buffer_count",
        "safety_level",
        "safety_reasons",
    ]

    def __init__(self, log_dir: Path) -> None:
        self.log_dir = log_dir
        self.log_dir.mkdir(parents=True, exist_ok=True)
        stamp = time.strftime("%Y%m%d_%H%M%S")
        self.path = self.log_dir / f"flight_{stamp}.csv"
        with self.path.open("w", newline="", encoding="utf-8") as fh:
            csv.DictWriter(fh, fieldnames=self.FIELDS).writeheader()

    def write(
        self,
        *,
        snapshot: SensorSnapshot,
        estimation: EstimationState,
        fsm_result: MissionFSMResult,
        safety: SafetyState,
        requested_rc: RCChannels,
        final_rc: RCChannels,
        throttle_clamp_reason: str,
        qr_state=None,
        rc_writer: str = "rc_arbiter",
        control_mode: str = "",
        selected_mode: str = "",
    ) -> None:
        waypoint = fsm_result.active_waypoint
        row = {
            "ts": time.time(),
            "flight_state": fsm_result.state.value,
            "takeoff_phase": fsm_result.takeoff_phase.value if fsm_result.takeoff_phase else "",
            "requested_roll": requested_rc.roll,
            "requested_pitch": requested_rc.pitch,
            "requested_throttle": requested_rc.throttle,
            "requested_yaw": requested_rc.yaw,
            "final_roll": final_rc.roll,
            "final_pitch": final_rc.pitch,
            "final_throttle": final_rc.throttle,
            "final_yaw": final_rc.yaw,
            "throttle_clamp_reason": throttle_clamp_reason,
            "rc_writer": rc_writer,
            "uwb_x": snapshot.uwb.x_m,
            "uwb_y": snapshot.uwb.y_m,
            "uwb_z_control": snapshot.uwb.z_control_m,
            "uwb_xy_control_usable": snapshot.uwb.xy_control_usable,
            "uwb_z_control_usable": snapshot.uwb.z_control_usable,
            "tof_raw": snapshot.tof.raw_distance_m,
            "tof_filtered": snapshot.tof.filtered_distance_m,
            "tof_offset": snapshot.tof.ground_offset_m,
            "tof_altitude": snapshot.tof.altitude_m,
            "tof_usable": snapshot.tof.usable,
            "imu_roll": snapshot.imu.roll_deg,
            "imu_pitch": snapshot.imu.pitch_deg,
            "imu_roll_rate": snapshot.imu.roll_rate_dps,
            "imu_pitch_rate": snapshot.imu.pitch_rate_dps,
            "imu_yaw_rate": snapshot.imu.yaw_rate_dps,
            "imu_accel_norm_g": snapshot.imu.accel_norm_g,
            "imu_jerk_mps3": snapshot.imu.jerk_mps3,
            "imu_vibration_score": snapshot.imu.vibration_score,
            "imu_motion_state": snapshot.imu.motion_state,
            "imu_usable": snapshot.imu.usable,
            "fc_armed": snapshot.fc.armed,
            "fc_mode": snapshot.fc.mode,
            "fc_relative_alt": snapshot.fc.relative_alt_m,
            "fc_yaw": snapshot.fc.yaw_deg,
            "current_z_m": estimation.current_z_m,
            "current_z_source": estimation.current_z_source.value,
            "pose_quality": snapshot.uwb.pose_quality,
            "uwb4_residual_m": snapshot.uwb.uwb4_residual_m,
            "control_mode": control_mode or snapshot.mission.raw.get("control_mode", ""),
            "selected_mode": selected_mode or rc_writer,
            "active_waypoint": waypoint.point_id if waypoint else "",
            "qr_scan_status": getattr(getattr(qr_state, "status", None), "value", "") if qr_state else "",
            "qr_client_scan_id": getattr(qr_state, "client_scan_id", "") if qr_state else "",
            "qr_pending_buffer_count": getattr(qr_state, "pending_buffer_count", "") if qr_state else "",
            "safety_level": safety.level.value,
            "safety_reasons": "|".join(safety.reasons),
        }
        with self.path.open("a", newline="", encoding="utf-8") as fh:
            csv.DictWriter(fh, fieldnames=self.FIELDS).writerow(row)
