from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone

from ..config import AppConfig
from ..types import ControlMode, EstimationState, FcGuidedProbeResult, SensorSnapshot


@dataclass(frozen=True)
class LaunchGuardResult:
    system_ready: bool
    mission_ready: bool
    allow_takeoff: bool
    reasons: list[str]


class LaunchGuard:
    def __init__(self, config: AppConfig) -> None:
        self.config = config

    def evaluate(
        self,
        snapshot: SensorSnapshot,
        estimation: EstimationState,
        control_probe: FcGuidedProbeResult | None = None,
    ) -> LaunchGuardResult:
        reasons: list[str] = []

        if self.config.require_uwb and (snapshot.uwb.age_ms is None or snapshot.uwb.age_ms > self.config.uwb_max_age_ms):
            reasons.append("uwb_tag_missing")
        if self.config.require_pixhawk and not snapshot.fc.connected:
            reasons.append("pixhawk_heartbeat_missing")
        if self.config.require_server and not snapshot.mission.server_reachable:
            reasons.append("server_link_missing")
        if self.config.require_tof and (not snapshot.tof.usable or snapshot.tof.age_ms is None or snapshot.tof.age_ms > self.config.tof_max_age_ms):
            reasons.append("tof_missing")
        if self.config.require_imu and (not snapshot.imu.usable or snapshot.imu.age_ms is None or snapshot.imu.age_ms > self.config.imu_max_age_ms):
            reasons.append("imu_missing")

        system_ready = not reasons
        mission_reasons = list(reasons)
        mission = snapshot.mission
        if mission.status != "ACTIVE":
            mission_reasons.append("mission_not_active")
        if not mission.launch_authorized:
            mission_reasons.append("launch_not_authorized")
        if not mission.route_tasks:
            mission_reasons.append("route_empty")
        if mission.launch_blocked_reason:
            mission_reasons.append(f"launch_blocked:{mission.launch_blocked_reason}")
        if not mission.anchor_layout_valid:
            mission_reasons.append("anchor_layout_invalid")
        if mission.anchor_layout_version and mission.anchor_layout_version != 4:
            mission_reasons.append("anchor_layout_version_not_4")
        if self.config.require_uwb and mission.anchor_layout_id:
            if not snapshot.uwb.tag_layout_synced:
                mission_reasons.append("tag_layout_not_synced")
            elif snapshot.uwb.anchor_layout_id and snapshot.uwb.anchor_layout_id != mission.anchor_layout_id:
                mission_reasons.append("tag_layout_id_mismatch")
            if snapshot.uwb.pose_quality != "CONTROL_GRADE":
                mission_reasons.append(f"uwb_pose_quality:{snapshot.uwb.pose_quality}")
        if snapshot.fc.battery_remaining_pct is not None and snapshot.fc.battery_remaining_pct < 15.0:
            mission_reasons.append("battery_low")
        self._append_control_backend_reasons(mission_reasons, snapshot, control_probe)

        mission_ready = system_ready and not mission_reasons
        return LaunchGuardResult(
            system_ready=system_ready,
            mission_ready=mission_ready,
            allow_takeoff=mission_ready and snapshot.fc.armed and estimation.altitude_sensor_ready,
            reasons=mission_reasons or ["ok"],
        )

    def build_launch_snapshot_payload(self, snapshot: SensorSnapshot, estimation: EstimationState) -> dict | None:
        if estimation.current_x_m is None or estimation.current_y_m is None:
            return None
        z_m = estimation.current_z_m if estimation.current_z_trusted else None
        if z_m is None and snapshot.uwb.z_control_usable:
            z_m = snapshot.uwb.z_control_m
        if z_m is None:
            z_m = snapshot.tof.altitude_m
        if z_m is None:
            return None
        if not estimation.xy_control_usable:
            return None
        return {
            "x": estimation.current_x_m,
            "y": estimation.current_y_m,
            "z": z_m,
            "current_z_m": z_m,
            "current_z_trusted": True,
            "fix": bool(snapshot.uwb.fix),
            "captured_at_iso": datetime.now(timezone.utc).isoformat(),
            "source": "companion_local",
        }

    def _append_control_backend_reasons(
        self,
        reasons: list[str],
        snapshot: SensorSnapshot,
        control_probe: FcGuidedProbeResult | None,
    ) -> None:
        if control_probe is None:
            return
        if control_probe.selected_mode != ControlMode.COMPANION_RC.value:
            reasons.append(f"control_backend_not_ready:{control_probe.selected_mode}")
        for reason in control_probe.reasons:
            reasons.append(f"control_backend:{reason.code}")
        desired = str(self.config.companion_rc_flight_mode or "").strip().upper()
        if desired == "ALT_HOLD":
            reasons.append("ALT_HOLD_FORBIDDEN")
        elif desired and _normalize_mode_name(snapshot.fc.mode) != _normalize_mode_name(desired):
            reasons.append(f"fc_mode_not_{desired}:{snapshot.fc.mode or 'unknown'}")


def _normalize_mode_name(value: str) -> str:
    return str(value or "").strip().upper().replace(" ", "_")
