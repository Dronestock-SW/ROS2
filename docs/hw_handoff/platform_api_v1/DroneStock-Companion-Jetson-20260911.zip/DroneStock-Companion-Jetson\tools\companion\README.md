# DroneStock Jetson/Raspberry Pi Companion

This package is the Raspberry Pi autonomous-flight brain.

Core rule:

```text
Sensors provide state.
MissionFSM owns flight state.
Controllers return requested_rc only.
RCArbiter creates final_rc.
PixhawkMavlink sends final_rc and is the only MAVLink RC writer.
```

Default autonomous flight uses `companion_rc` with the Pixhawk in `LOITER`.
The companion injects UWB/ToF external nav and computes small
roll/pitch/throttle/yaw requests from web waypoints, while Pixhawk owns position
hold, altitude behavior, attitude stabilization, and motor mixing. `GUIDED`,
`STABILIZE`, and `ALT_HOLD` are not normal autonomous modes here; legacy
control-mode values are normalized to `companion_rc`.

## Runtime

Run from the repository root:

```bash
python -m tools.companion.app \
  --drone-id 5 \
  --server-url http://<platform-pc-ip>:8001 \
  --uwb-port /dev/ttyUSB0 \
  --pixhawk-device /dev/serial0
```

Dry-run import/control test:

```bash
python -m tools.companion.app --simulation --dry-run-rc --no-tof --no-imu
```

## Deploy To Jetson

Requires Python 3.10 or newer. Raspberry Pi OS Bookworm is recommended.

```bash
cd ~/DroneStock-Companion/DroneStock-Companion-Jetson
sudo bash tools/companion/deploy/install_jetson.sh
sudo nano /etc/dronestock-companion.env
sudo systemctl restart dronestock-companion
journalctl -u dronestock-companion -f
```

### Upload Over SSH

From the development PC, upload the repository to the Pi and run the deploy
script there:

```powershell
$PI="pi@192.168.0.50"
ssh $PI "mkdir -p ~/DroneStock"
scp -r tools apps firmware docs requirements*.txt requirements-companion.txt manage.py ${PI}:~/DroneStock/
ssh $PI "cd ~/DroneStock && sudo bash tools/companion/deploy/install_pi.sh"
ssh $PI "sudo nano /etc/dronestock-companion.env"
ssh $PI "sudo systemctl restart dronestock-companion && journalctl -u dronestock-companion -f"
```

If `rsync` is available, prefer it for repeat uploads:

```bash
rsync -av --exclude .git --exclude .venv --exclude __pycache__ ./ pi@192.168.0.50:~/DroneStock/
```

## Required Environment

See `deploy/companion.env.example`.

Important values:

```text
DRONESTOCK_DRONE_ID=5
DRONESTOCK_SERVER_URL=http://PLATFORM_PC_IP:8001
DRONESTOCK_COMPANION_PLATFORM=jetson-orin-nano
DRONESTOCK_COMPANION_ID=jetson-drone-05
DRONESTOCK_DIAGNOSTIC_INTERVAL_S=5
DRONESTOCK_UWB_PORT=/dev/ttyUSB0
DRONESTOCK_PIXHAWK_DEVICE=/dev/serial0
DRONESTOCK_PIXHAWK_BAUD=57600
DRONESTOCK_TOF_SOURCE=pi
DRONESTOCK_QR_ENABLED=true
DRONESTOCK_QR_CAMERA_BACKEND=picamera2
DRONESTOCK_QR_BUFFER_PATH=/tmp/companion_scan_buffer.jsonl
DRONESTOCK_CONTROL_MODE=companion_rc
DRONESTOCK_COMPANION_RC_FC_MODE=LOITER
DRONESTOCK_ALLOW_PREARM_FALLBACK_TO_RC=true
DRONESTOCK_FORBID_INFLIGHT_BACKEND_SWITCH=true
```

The runtime prints a secret-free `COMPANION_HEALTH` JSON record at the configured
diagnostic interval. It includes UWB serial connection/counter information,
the latest parsed pose status, and WebSocket connection/send counters. The same
record is written to `logs/companion/events_*.jsonl` and is visible through
`journalctl -u dronestock-companion -f` when running as a service. Set
`DRONESTOCK_DIAGNOSTIC_INTERVAL_S=0` only when periodic health logs must be
disabled.

Before starting the full runtime, the UWB serial contract can be checked without
Pixhawk or server access:

```bash
.venv-companion/bin/python tools/companion/deploy/check_uwb_serial.py \
  --port /dev/ttyUSB0 --baud 921600 --seconds 15
```

`DRONESTOCK_DRY_RUN_RC=true` keeps the Pixhawk UART link alive for heartbeat
and mode checks, but skips ARM/DISARM and RC override output. Use it for bench
tests with the real FC connected.

## Pixhawk UART Wiring

Default FC communication uses the Raspberry Pi GPIO UART, not USB:

```text
Pi GPIO14 TXD  -> Pixhawk TELEM RX
Pi GPIO15 RXD  <- Pixhawk TELEM TX
Pi GND         -> Pixhawk GND
```

Use 3.3V UART only. Do not connect Pixhawk 5V to the Pi GPIO rail unless the
power architecture has been reviewed separately. The UWB tag can still use USB
serial at `DRONESTOCK_UWB_PORT=/dev/ttyUSB0`.

On the Pi, enable the hardware serial port and disable the login shell on the
serial port:

```bash
sudo raspi-config
# Interface Options -> Serial Port
# Login shell over serial: No
# Serial port hardware: Yes
sudo reboot
```

After reboot:

```bash
ls -l /dev/serial0
groups
```

The service user should be in `dialout`. The deploy script adds that group, but
a logout/reboot may be needed before it takes effect.

The Pixhawk TELEM port must run MAVLink at the same baud as
`DRONESTOCK_PIXHAWK_BAUD`. Initial default is `57600`; set the matching
ArduPilot `SERIALx_BAUD` and `SERIALx_PROTOCOL=2` for the TELEM port you wired.

UART heartbeat test before starting the companion:

```bash
cd ~/DroneStock
.venv-companion/bin/python tools/companion/deploy/check_pixhawk_uart.py --device /dev/serial0 --baud 57600
```

## ToF Source

The downward ToF can be read in either place:

```text
DRONESTOCK_TOF_SOURCE=pi   # Pi reads ToF10120 through I2C or a dedicated serial port
DRONESTOCK_TOF_SOURCE=uwb  # ESP32 UWB tag reads ToF and includes it in UWB telemetry
```

If the ToF is attached to the ESP32 tag, keep `DRONESTOCK_UWB_PORT` pointed at
the tag serial port and set:

```text
DRONESTOCK_TOF_SOURCE=uwb
DRONESTOCK_TOF_ENABLED=true
DRONESTOCK_REQUIRE_TOF=true
```

The tag telemetry may include either a nested object:

```json
{"type":"uwb_pose","tof":{"distance_mm":315,"usable":true}}
```

or compact top-level fields:

```json
{"type":"uwb_pose","tof_distance_mm":315,"tof_usable":true}
```

Companion captures the ground offset at `TAKEOFF_INIT`; before that, ToF is a
distance sensor sample but not yet an altitude source.

## 4-Anchor Contract

The companion expects `anchor_layout_version=4`:

```text
A1=(0,0,H) BASE_TOP
A2=(X,0,0) X_FLOOR
A3=(0,Y,0) Y_FLOOR
A4=(X,Y,H) DIAG_TOP
```

It sends `ANCHORS4 LAYOUT=<id> ...` to the UWB tag over USB. LoRa layout sync
uses compact `L4,<layout_id>,<x_cm>,<y_cm>,<h_cm>` payloads.

## Safety Contract

- `ARMING`, `TAKEOFF_READY`, and `TAKEOFF_INIT` force throttle `1000`.
- Before `TAKEOFF_BOOST`, throttle above `1000` is blocked.
- UWB XY instability forces roll/pitch/yaw neutral during navigation.
- `DEGRADED_HOVER` holds altitude only.
- `FAILSAFE_LAND` descends slowly with neutral XY.
- `EMERGENCY_CUT` sends throttle `1000` and requests disarm.
- `companion_rc` requires FC `LOITER`; `ALT_HOLD` is blocked for autonomous flight.
- A sent mode command is not enough: ARM is blocked until FC heartbeat confirms `LOITER`.
- If the backend selects `dry_run` or reports a control probe blocker, mission ARM is blocked.
- If UWB/ToF external nav injection fails during takeoff or movement, RC is neutralized.

## QR Scan Pipeline

The CSI camera scanner runs only during the mission `SCAN` state.

```text
CSI camera frame -> QRDecoder -> /api/drones/<id>/scan/
```

If upload fails after retries, the scan is written to the offline JSONL buffer
and retried in the background.

```bash
cat /tmp/companion_scan_buffer.jsonl
```
