from __future__ import annotations

import math
from dataclasses import dataclass

from ..config import AppConfig
from ..types import SensorSnapshot


@dataclass(frozen=True)
class XYPose:
    x_m: float | None
    y_m: float | None
    vx_mps: float | None
    vy_mps: float | None
    usable: bool
    reason: str = ""


class UwbPoseResolver:
    def __init__(self, config: AppConfig) -> None:
        self.config = config
        self._last_x: float | None = None
        self._last_y: float | None = None
        self._last_vx_mps = 0.0
        self._last_vy_mps = 0.0
        self._last_update_monotonic: float | None = None

    def _held_pose(self, reason: str) -> XYPose:
        return XYPose(
            self._last_x,
            self._last_y,
            self._last_vx_mps if self._last_x is not None else None,
            self._last_vy_mps if self._last_y is not None else None,
            False,
            reason,
        )

    def _reset_track(self, *, x_m: float, y_m: float, now: float, vx_mps: float = 0.0, vy_mps: float = 0.0) -> XYPose:
        self._last_x = x_m
        self._last_y = y_m
        self._last_vx_mps = vx_mps
        self._last_vy_mps = vy_mps
        self._last_update_monotonic = now
        return XYPose(x_m, y_m, vx_mps, vy_mps, True, "ok")

    def resolve(self, snapshot: SensorSnapshot) -> XYPose:
        uwb = snapshot.uwb
        if uwb.age_ms is None:
            return self._held_pose("uwb_missing")
        if uwb.age_ms > self.config.uwb_max_age_ms:
            return self._held_pose("uwb_stale")
        if uwb.x_m is None or uwb.y_m is None:
            return self._held_pose("uwb_xy_missing")
        raw = uwb.raw or {}
        if raw.get("xy_control_fresh") is False:
            return self._held_pose("uwb_not_fresh")
        if raw.get("xy_control_held") is True:
            return self._held_pose("uwb_held")
        cycle_ms = _float_or_none(raw.get("range_cycle_ms") or raw.get("cycle_ms"))
        if cycle_ms is not None and cycle_ms > 90.0:
            return self._held_pose(f"uwb_cycle_slow:{cycle_ms:.0f}ms")
        control_age_ms = _float_or_none(raw.get("control_pose_age_ms"))
        if control_age_ms is not None and control_age_ms > 120.0:
            return self._held_pose(f"uwb_control_age:{control_age_ms:.0f}ms")
        reject_mask = _float_or_none(raw.get("range_reject_mask"))
        if reject_mask is not None and int(reject_mask) != 0:
            return self._held_pose(f"uwb_range_reject:{int(reject_mask)}")
        if uwb.pose_quality and uwb.pose_quality != "CONTROL_GRADE":
            return self._held_pose(f"pose_quality:{uwb.pose_quality}")
        if not uwb.xy_control_usable:
            return self._held_pose(uwb.reason or "uwb_xy_unusable")

        now = snapshot.now
        measured_x = uwb.x_m
        measured_y = uwb.y_m
        if (
            self._last_update_monotonic is None or
            self._last_x is None or
            self._last_y is None or
            now <= self._last_update_monotonic or
            (now - self._last_update_monotonic) > 1.0
        ):
            return self._reset_track(x_m=measured_x, y_m=measured_y, now=now)

        dt = min(max(now - self._last_update_monotonic, 1e-3), 0.5)
        predicted_x = self._last_x + (self._last_vx_mps * dt)
        predicted_y = self._last_y + (self._last_vy_mps * dt)
        innovation_x = measured_x - predicted_x
        innovation_y = measured_y - predicted_y
        innovation_norm = math.hypot(innovation_x, innovation_y)

        predicted_speed = math.hypot(self._last_vx_mps, self._last_vy_mps)
        motion_ratio = _clamp01(predicted_speed / 0.8)
        alpha = 0.28 + (0.60 - 0.28) * motion_ratio
        beta = 0.06 + (0.20 - 0.06) * motion_ratio

        if innovation_norm > 1.2:
            measured_vx_mps = _clamp((measured_x - self._last_x) / dt, -2.5, 2.5)
            measured_vy_mps = _clamp((measured_y - self._last_y) / dt, -2.5, 2.5)
            return self._reset_track(
                x_m=measured_x,
                y_m=measured_y,
                now=now,
                vx_mps=measured_vx_mps,
                vy_mps=measured_vy_mps,
            )

        filtered_x = predicted_x + (alpha * innovation_x)
        filtered_y = predicted_y + (alpha * innovation_y)
        filtered_vx_mps = _clamp(self._last_vx_mps + ((beta * innovation_x) / dt), -2.5, 2.5)
        filtered_vy_mps = _clamp(self._last_vy_mps + ((beta * innovation_y) / dt), -2.5, 2.5)

        return self._reset_track(
            x_m=filtered_x,
            y_m=filtered_y,
            now=now,
            vx_mps=filtered_vx_mps,
            vy_mps=filtered_vy_mps,
        )


def _clamp(value: float, lower: float, upper: float) -> float:
    return max(lower, min(upper, value))


def _clamp01(value: float) -> float:
    return _clamp(value, 0.0, 1.0)


def _float_or_none(value: object) -> float | None:
    try:
        parsed = float(value)
    except (TypeError, ValueError):
        return None
    return parsed if math.isfinite(parsed) else None
