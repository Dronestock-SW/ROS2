#!/usr/bin/env python3
"""Field smoke test for the ESP32 UWB tag USB serial contract."""

from __future__ import annotations

import argparse
import glob
import json
import os
import time
from typing import Any

try:
    import serial
except ImportError:  # pragma: no cover - depends on field environment
    serial = None


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Read and summarize DroneStock UWB tag JSON")
    parser.add_argument("--port", default=os.getenv("DRONESTOCK_UWB_PORT", "/dev/ttyUSB0"))
    parser.add_argument("--baud", type=int, default=int(os.getenv("DRONESTOCK_UWB_BAUD", "921600")))
    parser.add_argument("--seconds", type=float, default=15.0, help="0 keeps reading until Ctrl+C")
    parser.add_argument("--summary-every", type=float, default=5.0)
    parser.add_argument("--show-raw", action="store_true")
    parser.add_argument("--require-fix", action="store_true", help="Fail unless at least one usable XY fix is seen")
    return parser


def _candidate_ports() -> list[str]:
    candidates: list[str] = []
    for pattern in ("/dev/ttyUSB*", "/dev/ttyACM*"):
        candidates.extend(glob.glob(pattern))
    return sorted(set(candidates))


def _print_summary(stats: dict[str, Any], *, final: bool = False) -> None:
    payload = {
        "event": "uwb_serial_summary_final" if final else "uwb_serial_summary",
        **stats,
    }
    print(json.dumps(payload, ensure_ascii=False, separators=(",", ":")), flush=True)


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if serial is None:
        print("pyserial is not installed; install requirements-companion.txt", flush=True)
        return 2

    print(json.dumps({
        "event": "uwb_serial_check_start",
        "port": args.port,
        "baud": args.baud,
        "seconds": args.seconds,
        "candidate_ports": _candidate_ports(),
    }, ensure_ascii=False, separators=(",", ":")), flush=True)

    stats: dict[str, Any] = {
        "lines": 0,
        "json_lines": 0,
        "invalid_json_lines": 0,
        "pose_lines": 0,
        "usable_fix_lines": 0,
        "last_type": None,
        "last_seq": None,
        "last_fix": None,
        "last_x": None,
        "last_y": None,
        "last_reason": None,
    }
    started = time.monotonic()
    last_summary = started

    try:
        with serial.Serial(args.port, args.baud, timeout=0.25) as device:
            while args.seconds <= 0 or time.monotonic() - started < args.seconds:
                raw = device.readline()
                if not raw:
                    continue
                line = raw.decode("utf-8", errors="replace").strip()
                if not line:
                    continue
                stats["lines"] += 1
                if args.show_raw:
                    print(line, flush=True)
                try:
                    payload = json.loads(line)
                except json.JSONDecodeError:
                    stats["invalid_json_lines"] += 1
                    continue
                if not isinstance(payload, dict):
                    stats["invalid_json_lines"] += 1
                    continue

                stats["json_lines"] += 1
                payload_type = str(payload.get("type") or "")
                stats["last_type"] = payload_type or None
                if payload_type not in {"uwb_pose", "telemetry"}:
                    continue

                stats["pose_lines"] += 1
                stats["last_seq"] = payload.get("seq")
                stats["last_fix"] = bool(payload.get("fix", False))
                stats["last_x"] = payload.get("x")
                stats["last_y"] = payload.get("y")
                stats["last_reason"] = payload.get("reason")
                usable = bool(payload.get("xy_control_usable", payload.get("fix", False)))
                if usable and payload.get("x") is not None and payload.get("y") is not None:
                    stats["usable_fix_lines"] += 1

                now = time.monotonic()
                if now - last_summary >= max(0.5, args.summary_every):
                    _print_summary(stats)
                    last_summary = now
    except KeyboardInterrupt:
        pass
    except Exception as exc:
        print(json.dumps({
            "event": "uwb_serial_check_error",
            "port": args.port,
            "baud": args.baud,
            "error": f"{type(exc).__name__}:{exc}",
            "candidate_ports": _candidate_ports(),
        }, ensure_ascii=False, separators=(",", ":")), flush=True)
        return 2

    _print_summary(stats, final=True)
    if stats["pose_lines"] == 0:
        return 3
    if args.require_fix and stats["usable_fix_lines"] == 0:
        return 4
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
