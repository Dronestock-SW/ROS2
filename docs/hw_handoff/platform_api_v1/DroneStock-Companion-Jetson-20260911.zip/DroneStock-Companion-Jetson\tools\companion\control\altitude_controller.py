from __future__ import annotations

from ..config import AppConfig
from ..types import EstimationState, clamp


class AltitudeController:
    def __init__(self, config: AppConfig) -> None:
        self.config = config
        self.integrator_pwm = 0.0
        self._last_error: float | None = None
        self._last_t: float | None = None

    def reset(self) -> None:
        self.integrator_pwm = 0.0
        self._last_error = None
        self._last_t = None

    def compute(self, *, target_z_m: float, estimation: EstimationState, now: float) -> int:
        if estimation.current_z_m is None:
            return self.config.hover_throttle_pwm

        error = target_z_m - estimation.current_z_m
        dt = 0.0 if self._last_t is None else max(1e-3, now - self._last_t)
        derivative = 0.0
        if self._last_error is not None and dt > 0.0:
            derivative = (error - self._last_error) / dt

        if not estimation.freeze_altitude_integrator and dt > 0.0:
            self.integrator_pwm += error * self.config.altitude_ki_pwm_per_m_s * dt
            self.integrator_pwm = clamp(
                self.integrator_pwm,
                -self.config.altitude_integrator_limit_pwm,
                self.config.altitude_integrator_limit_pwm,
            )

        self._last_error = error
        self._last_t = now

        pwm = (
            self.config.hover_throttle_pwm
            + self.config.altitude_kp_pwm_per_m * error
            + self.integrator_pwm
            + self.config.altitude_kd_pwm_per_mps * derivative
        )
        if estimation.freeze_altitude_integrator and error > 0:
            pwm = min(pwm, self.config.hover_throttle_pwm)
        return int(clamp(pwm, self.config.altitude_output_min_pwm, self.config.altitude_output_max_pwm))

