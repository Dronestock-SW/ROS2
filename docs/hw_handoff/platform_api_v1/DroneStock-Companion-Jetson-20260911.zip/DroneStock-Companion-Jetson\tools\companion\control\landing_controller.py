from __future__ import annotations

from ..config import AppConfig
from ..types import EstimationState, RCChannels, clamp


class LandingController:
    def __init__(self, config: AppConfig) -> None:
        self.config = config
        self._last_t: float | None = None
        self._last_throttle: float = float(config.hover_throttle_pwm)

    def reset(self) -> None:
        self._last_t = None
        self._last_throttle = float(self.config.hover_throttle_pwm)

    def compute(self, *, estimation: EstimationState, now: float, failsafe: bool = False) -> RCChannels:
        rate = self.config.failsafe_descent_pwm_s if failsafe else self.config.landing_descent_pwm_s
        dt = 0.0 if self._last_t is None else max(0.0, now - self._last_t)
        self._last_t = now
        target = self._last_throttle - rate * dt
        if estimation.current_z_m is not None and estimation.current_z_m > 0.35:
            target = max(target, 1300.0)
        self._last_throttle = clamp(target, self.config.throttle_min_pwm, self.config.hover_throttle_pwm)
        return RCChannels(throttle=int(self._last_throttle), reason="failsafe_land" if failsafe else "land")

