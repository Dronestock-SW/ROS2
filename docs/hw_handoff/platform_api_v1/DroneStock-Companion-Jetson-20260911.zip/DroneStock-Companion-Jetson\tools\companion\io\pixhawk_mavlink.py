from __future__ import annotations

import math
import threading
import time
from dataclasses import replace
from typing import Any

from ..types import FCState, RCChannels

try:  # pragma: no cover - hardware path
    from pymavlink import mavutil
except ImportError:  # pragma: no cover
    mavutil = None


class PixhawkMavlink:
    """Pixhawk MAVLink transport driver.

    This module owns communication only: heartbeat, telemetry, arm/disarm, and
    final RC override transmission. It does not own mission or controller logic.
    """

    def __init__(self, *, device: str, baud: int = 57600, dry_run: bool = False) -> None:
        self.device = device
        self.baud = baud
        self.dry_run = dry_run
        self._lock = threading.Lock()
        self._state = FCState()
        self._master: Any = None
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()
        self.target_system = 1
        self.target_component = 1
        self.last_sent_rc: RCChannels | None = None

    def start(self) -> None:
        if self.dry_run:
            return
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, name="pixhawk-mavlink", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._master is not None:
            try:
                self._master.close()
            except Exception:
                pass

    def latest(self, now: float | None = None) -> FCState:
        now = time.monotonic() if now is None else now
        if self.dry_run:
            return FCState(
                connected=True,
                armed=True,
                mode="DRY_RUN",
                relative_alt_m=0.0,
                yaw_deg=0.0,
                received_monotonic=now,
                heartbeat_monotonic=now,
            ).with_age(now)
        with self._lock:
            return self._state.with_age(now)

    def arm(self) -> bool:
        return self._send_arm_disarm(True)

    def disarm(self) -> bool:
        return self._send_arm_disarm(False)

    def send_rc_override(self, final_rc: RCChannels) -> bool:
        """The single MAVLink RC override writer for the companion package."""
        self.last_sent_rc = final_rc
        if self.dry_run:
            return True
        master = self._master
        if master is None or mavutil is None:
            return False
        try:
            master.mav.rc_channels_override_send(
                self.target_system,
                self.target_component,
                *final_rc.as_mavlink_channels(),
            )
            return True
        except Exception:
            return False

    def set_loiter_mode(self) -> bool:
        return self.set_flight_mode("LOITER")

    def set_flight_mode(self, mode_name: str) -> bool:
        if self.dry_run:
            return True
        master = self._master
        if master is None or mavutil is None:
            return False
        try:
            mode_mapping = master.mode_mapping() or {}
            desired = str(mode_name or "").strip().upper()
            mode_id = mode_mapping.get(desired)
            if mode_id is None:
                return False
            master.mav.set_mode_send(
                self.target_system,
                mavutil.mavlink.MAV_MODE_FLAG_CUSTOM_MODE_ENABLED,
                mode_id,
            )
            return True
        except Exception:
            return False

    def send_vision_position_estimate(self, *, x_m: float, y_m: float, z_m: float, yaw_deg: float = 0.0) -> bool:
        if self.dry_run:
            return True
        master = self._master
        if master is None or mavutil is None:
            return False
        try:
            master.mav.vision_position_estimate_send(
                int(time.time() * 1_000_000),
                x_m,
                y_m,
                z_m,
                0.0,
                0.0,
                math.radians(yaw_deg),
            )
            return True
        except Exception:
            return False

    def send_odometry(
        self,
        *,
        x_m: float,
        y_m: float,
        z_m: float,
        vx_mps: float = 0.0,
        vy_mps: float = 0.0,
        vz_mps: float = 0.0,
        yaw_deg: float = 0.0,
        quality: int = 100,
        pos_error_m: float = 0.12,
        z_error_m: float = 0.15,
        yaw_error_rad: float = 0.25,
    ) -> bool:
        if self.dry_run:
            return True
        master = self._master
        if master is None or mavutil is None:
            return False
        try:
            pos_covariance = [math.nan] * 21
            pos_covariance[0] = max(0.01, float(pos_error_m))
            pos_covariance[6] = max(0.01, float(pos_error_m))
            pos_covariance[11] = max(0.01, float(z_error_m))
            pos_covariance[20] = max(0.01, float(yaw_error_rad))
            velocity_covariance = [math.nan] * 21
            local_frd = getattr(mavutil.mavlink, "MAV_FRAME_LOCAL_FRD", 20)
            estimator_type = getattr(mavutil.mavlink, "MAV_ESTIMATOR_TYPE_VISION", 0)
            master.mav.odometry_send(
                int(time.time() * 1_000_000),
                local_frd,
                local_frd,
                x_m,
                y_m,
                z_m,
                _yaw_quaternion(math.radians(yaw_deg)),
                vx_mps,
                vy_mps,
                vz_mps,
                0.0,
                0.0,
                0.0,
                pos_covariance,
                velocity_covariance,
                0,
                estimator_type,
                max(0, min(100, int(quality))),
            )
            return True
        except Exception:
            return False

    def send_distance_sensor(self, *, distance_m: float, min_m: float = 0.02, max_m: float = 4.0) -> bool:
        if self.dry_run:
            return True
        master = self._master
        if master is None or mavutil is None:
            return False
        try:
            master.mav.distance_sensor_send(
                int(time.time() * 1000) & 0xFFFFFFFF,
                int(min_m * 100),
                int(max_m * 100),
                int(max(0.0, distance_m) * 100),
                mavutil.mavlink.MAV_DISTANCE_SENSOR_LASER,
                0,
                mavutil.mavlink.MAV_SENSOR_ROTATION_PITCH_270,
                0,
            )
            return True
        except Exception:
            return False

    def _send_arm_disarm(self, arm: bool) -> bool:
        if self.dry_run:
            return True
        master = self._master
        if master is None or mavutil is None:
            return False
        try:
            master.mav.command_long_send(
                self.target_system,
                self.target_component,
                mavutil.mavlink.MAV_CMD_COMPONENT_ARM_DISARM,
                0,
                1.0 if arm else 0.0,
                0,
                0,
                0,
                0,
                0,
                0,
            )
            return True
        except Exception:
            return False

    def _run(self) -> None:  # pragma: no cover - hardware loop
        if mavutil is None:
            with self._lock:
                self._state = replace(self._state, mode="pymavlink_missing")
            return

        while not self._stop.is_set():
            try:
                master = mavutil.mavlink_connection(self.device, baud=self.baud, autoreconnect=True)
                self._master = master
                heartbeat = master.wait_heartbeat(timeout=5)
                if heartbeat:
                    self.target_system = master.target_system
                    self.target_component = master.target_component
                _request_streams(master)
                while not self._stop.is_set():
                    msg = master.recv_match(blocking=True, timeout=0.2)
                    if msg is None:
                        continue
                    self._handle_msg(msg)
            except Exception:
                time.sleep(1.0)
            finally:
                self._master = None

    def _handle_msg(self, msg: Any) -> None:  # pragma: no cover
        msg_type = msg.get_type()
        now = time.monotonic()
        with self._lock:
            state = self._state
            if msg_type == "HEARTBEAT":
                armed = bool(msg.base_mode & mavutil.mavlink.MAV_MODE_FLAG_SAFETY_ARMED)
                try:
                    mode = mavutil.mode_string_v10(msg)
                except Exception:
                    mode = str(getattr(msg, "custom_mode", ""))
                self._state = replace(
                    state,
                    connected=True,
                    armed=armed,
                    mode=mode,
                    heartbeat_monotonic=now,
                    received_monotonic=state.received_monotonic or now,
                )
            elif msg_type == "GLOBAL_POSITION_INT":
                self._state = replace(
                    state,
                    relative_alt_m=getattr(msg, "relative_alt", 0) / 1000.0,
                    received_monotonic=now,
                )
            elif msg_type == "ATTITUDE":
                yaw_deg = math.degrees(getattr(msg, "yaw", 0.0))
                self._state = replace(state, yaw_deg=yaw_deg, received_monotonic=now)
            elif msg_type == "SYS_STATUS":
                voltage = getattr(msg, "voltage_battery", -1)
                remaining = getattr(msg, "battery_remaining", -1)
                self._state = replace(
                    state,
                    battery_voltage=(voltage / 1000.0 if voltage and voltage > 0 else None),
                    battery_remaining_pct=(float(remaining) if remaining is not None and remaining >= 0 else None),
                    received_monotonic=now,
                )


def _request_streams(master: Any) -> None:  # pragma: no cover
    if mavutil is None:
        return
    try:
        for stream_id in (
            mavutil.mavlink.MAV_DATA_STREAM_EXTENDED_STATUS,
            mavutil.mavlink.MAV_DATA_STREAM_POSITION,
            mavutil.mavlink.MAV_DATA_STREAM_EXTRA1,
        ):
            master.mav.request_data_stream_send(
                master.target_system,
                master.target_component,
                stream_id,
                10,
                1,
            )
    except Exception:
        pass


def _yaw_quaternion(yaw_rad: float) -> list[float]:
    half_yaw = 0.5 * yaw_rad
    return [math.cos(half_yaw), 0.0, 0.0, math.sin(half_yaw)]
