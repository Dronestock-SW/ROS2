from __future__ import annotations

from ..config import AppConfig
from ..types import EstimationState, FlightState, SensorSnapshot, TakeoffPhase
from .current_z_resolver import CurrentZResolver
from .uwb_pose_resolver import UwbPoseResolver


class Estimator:
    def __init__(self, config: AppConfig) -> None:
        self.config = config
        self.xy_resolver = UwbPoseResolver(config)
        self.z_resolver = CurrentZResolver(config)

    def capture_takeoff_baselines(self, snapshot: SensorSnapshot) -> None:
        self.z_resolver.capture_takeoff_baselines(snapshot)

    def update(
        self,
        snapshot: SensorSnapshot,
        *,
        state: FlightState,
        takeoff_phase: TakeoffPhase | None,
        target_z_m: float | None = None,
    ) -> EstimationState:
        xy = self.xy_resolver.resolve(snapshot)
        z = self.z_resolver.resolve(snapshot, state=state, takeoff_phase=takeoff_phase)
        altitude_error = None
        if target_z_m is not None and z.current_z_m is not None:
            altitude_error = target_z_m - z.current_z_m

        health = {
            "uwb_xy": xy.reason,
            "current_z": z.reason,
            "uwb_age_ms": snapshot.uwb.age_ms,
            "tof_age_ms": snapshot.tof.age_ms,
            "imu_age_ms": snapshot.imu.age_ms,
            "fc_heartbeat_age_ms": snapshot.fc.heartbeat_age_ms,
            "server_age_ms": snapshot.mission.age_ms,
        }
        return EstimationState(
            current_x_m=xy.x_m,
            current_y_m=xy.y_m,
            current_vx_mps=xy.vx_mps,
            current_vy_mps=xy.vy_mps,
            current_z_m=z.current_z_m,
            current_z_source=z.source,
            current_z_trusted=z.trusted,
            current_z_confidence=z.confidence,
            altitude_error_m=altitude_error,
            z_control_usable=z.trusted,
            xy_control_usable=xy.usable,
            altitude_sensor_ready=z.altitude_sensor_ready,
            freeze_altitude_integrator=z.freeze_integrator,
            health=health,
        )
