"""Controller modules.

Controllers return requested RC only. They never talk to Pixhawk directly.
"""

