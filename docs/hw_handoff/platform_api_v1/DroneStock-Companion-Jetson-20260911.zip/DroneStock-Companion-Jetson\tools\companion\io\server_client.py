from __future__ import annotations

import json
import hashlib
import hmac
import queue
import threading
import time
import uuid
from dataclasses import replace
from typing import Any
from urllib.parse import urlparse

from ..types import MissionState, Waypoint, finite_bool, finite_float

COMPANION_API_CONTRACT_VERSION = "1.0"

try:
    import requests
except ImportError:  # pragma: no cover
    requests = None

try:  # pragma: no cover - runtime integration
    from websockets.sync.client import connect as ws_connect
except Exception:  # pragma: no cover
    ws_connect = None


class ServerClient:
    """Poll mission input and push telemetry output to the Django server."""

    def __init__(
        self,
        *,
        server_url: str,
        drone_id: str,
        poll_s: float = 0.5,
        telemetry_queue_size: int = 1,
        device_auth_id: str = "",
        device_auth_secret: str = "",
    ) -> None:
        self.server_url = server_url.rstrip("/")
        self.drone_id = str(drone_id)
        self.poll_s = poll_s
        self.device_auth_id = device_auth_id.strip()
        self.device_auth_secret = device_auth_secret
        self._session = requests.Session() if requests else None
        self._session_lock = threading.Lock()
        self._latest = MissionState()
        self._last_poll = 0.0
        self._telemetry_queue: queue.Queue[dict[str, Any]] = queue.Queue(maxsize=telemetry_queue_size)
        self._stop = threading.Event()
        self._ws_thread: threading.Thread | None = None
        self._posted_phases: set[str] = set()
        self._status_lock = threading.Lock()
        self._ws_connected = False
        self._ws_connect_attempts = 0
        self._ws_connect_successes = 0
        self._ws_messages_sent = 0
        self._ws_messages_dropped = 0
        self._ws_last_connected_monotonic: float | None = None
        self._ws_last_sent_monotonic: float | None = None
        self._ws_last_error = ""

    def start(self) -> None:
        if self._ws_thread and self._ws_thread.is_alive():
            return
        self._stop.clear()
        self._ws_thread = threading.Thread(target=self._ws_loop, name="server-telemetry-ws", daemon=True)
        self._ws_thread.start()

    def stop(self) -> None:
        self._stop.set()

    def diagnostics(self, now: float | None = None) -> dict[str, Any]:
        """Return transport health without exposing credentials or payloads."""
        now = time.monotonic() if now is None else now
        with self._status_lock:
            return {
                "connected": self._ws_connected,
                "transport": "websocket",
                "endpoint": _safe_ws_url(self.server_url, self.drone_id),
                "queue_depth": self._telemetry_queue.qsize(),
                "connect_attempts": self._ws_connect_attempts,
                "connect_successes": self._ws_connect_successes,
                "messages_sent": self._ws_messages_sent,
                "messages_dropped": self._ws_messages_dropped,
                "last_connected_age_ms": _age_ms(self._ws_last_connected_monotonic, now),
                "last_sent_age_ms": _age_ms(self._ws_last_sent_monotonic, now),
                "last_error": self._ws_last_error or None,
            }

    def latest(self, now: float | None = None) -> MissionState:
        now = time.monotonic() if now is None else now
        return self._latest.with_age(now)

    def poll_if_due(self, now: float | None = None) -> MissionState:
        now = time.monotonic() if now is None else now
        if now - self._last_poll < self.poll_s:
            return self.latest(now)
        self._last_poll = now
        return self.poll()

    def poll(self) -> MissionState:
        if self._session is None:
            self._latest = replace(self._latest, server_reachable=False, ok=False)
            return self._latest
        url = f"{self.server_url}/api/drones/{self.drone_id}/companion-mission/"
        try:
            path = f"/api/drones/{self.drone_id}/companion-mission/"
            with self._session_lock:
                resp = self._session.get(url, headers=self._signed_headers("GET", path, b""), timeout=2.0)
            resp.raise_for_status()
            payload = resp.json()
            self._latest = parse_mission_payload(payload, received_monotonic=time.monotonic())
        except Exception as exc:
            self._latest = replace(
                self._latest,
                server_reachable=False,
                ok=False,
                launch_blocked_reason=f"server_error:{exc}",
            )
        return self._latest

    def push_telemetry(self, payload: dict[str, Any]) -> None:
        if self._telemetry_queue.full():
            try:
                self._telemetry_queue.get_nowait()
                with self._status_lock:
                    self._ws_messages_dropped += 1
            except queue.Empty:
                pass
        try:
            self._telemetry_queue.put_nowait(payload)
        except queue.Full:
            pass

    def post_phase_once(
        self,
        phase: str,
        notes: str = "",
        *,
        mission_db_id: int | None = None,
        mission_code: str = "",
    ) -> bool:
        key = f"{mission_db_id or ''}|{mission_code}|{phase}|{notes}"
        if key in self._posted_phases:
            return True
        ok = self.post_phase(phase, notes, mission_db_id=mission_db_id, mission_code=mission_code)
        if ok:
            self._posted_phases.add(key)
        return ok

    def post_phase(
        self,
        phase: str,
        notes: str = "",
        *,
        mission_db_id: int | None = None,
        mission_code: str = "",
    ) -> bool:
        payload: dict[str, Any] = {
            "contract_version": COMPANION_API_CONTRACT_VERSION,
            "phase": phase,
            "notes": notes,
        }
        if mission_db_id is not None:
            payload["mission_db_id"] = mission_db_id
        if mission_code:
            payload["mission_code"] = mission_code
        return self._post(f"/api/drones/{self.drone_id}/companion-phase/", payload)

    def ack_control_action(self, action: str, *, request_id: str = "", requested_at: str = "") -> bool:
        if not action:
            return False
        payload = {
            "contract_version": COMPANION_API_CONTRACT_VERSION,
            "action": action,
            "request_id": request_id,
            "requested_at": requested_at,
        }
        return self._post(f"/api/drones/{self.drone_id}/control-action/ack/", payload)

    def post_launch_snapshot(self, payload: dict[str, Any]) -> bool:
        return self._post(f"/api/drones/{self.drone_id}/launch-snapshot/", payload)

    def upload_scan_payload(self, payload: dict[str, Any]) -> dict[str, Any]:
        if self._session is None:
            return {"ok": False, "error": "requests_missing"}
        try:
            path = f"/api/drones/{self.drone_id}/scan/"
            body = _json_body(payload)
            with self._session_lock:
                resp = self._session.post(
                    f"{self.server_url}{path}",
                    data=body,
                    headers=self._signed_headers("POST", path, body),
                    timeout=5.0,
                )
            data = resp.json() if resp.content else {}
            if 200 <= resp.status_code < 300:
                return data if isinstance(data, dict) else {"ok": True}
            if isinstance(data, dict):
                return {**data, "ok": False, "status_code": resp.status_code}
            return {"ok": False, "status_code": resp.status_code, "error": resp.text}
        except Exception as exc:
            return {"ok": False, "error": str(exc)}

    def upload_scan(
        self,
        qr_text: str,
        *,
        client_scan_id: str,
        drone_name: str = "",
        label_point_id: int | None = None,
        mission_id: int | str | None = None,
        mission_code: str = "",
        scan_source: str = "wifi",
        scanned_at_iso: str = "",
        note: str = "",
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "client_scan_id": client_scan_id,
            "raw_qr_data": qr_text,
            "drone_name": drone_name,
            "scan_source": scan_source,
            "scanned_at_iso": scanned_at_iso,
            "note": note,
        }
        if label_point_id is not None:
            payload["label_point_id"] = label_point_id
        if mission_id:
            payload["mission_id"] = mission_id
        if mission_code:
            payload["mission_code"] = mission_code
        return self.upload_scan_payload(payload)

    def _post(self, path: str, payload: dict[str, Any]) -> bool:
        if self._session is None:
            return False
        try:
            body = _json_body(payload)
            with self._session_lock:
                resp = self._session.post(
                    f"{self.server_url}{path}",
                    data=body,
                    headers=self._signed_headers("POST", path, body),
                    timeout=2.0,
                )
            if not 200 <= resp.status_code < 300:
                return False
            if not resp.content:
                return True
            data = resp.json()
            return not isinstance(data, dict) or finite_bool(data.get("ok"), True)
        except Exception:
            return False

    def _signed_headers(self, method: str, path: str, body: bytes) -> dict[str, str]:
        headers = {"Content-Type": "application/json"}
        if not self.device_auth_id or not self.device_auth_secret:
            return headers
        timestamp = str(int(time.time()))
        nonce = uuid.uuid4().hex
        body_hash = hashlib.sha256(body).hexdigest()
        canonical = "\n".join((method.upper(), path, body_hash, timestamp, nonce))
        signature = hmac.new(
            self.device_auth_secret.encode("utf-8"),
            canonical.encode("utf-8"),
            hashlib.sha256,
        ).hexdigest()
        headers.update({
            "X-DS-Device-ID": self.device_auth_id,
            "X-DS-Timestamp": timestamp,
            "X-DS-Nonce": nonce,
            "X-DS-Signature": signature,
        })
        return headers

    def _ws_loop(self) -> None:  # pragma: no cover - integration path
        if ws_connect is None:
            with self._status_lock:
                self._ws_last_error = "websockets_sync_client_missing"
            return
        ws_url = _ws_url(self.server_url, self.drone_id)
        while not self._stop.is_set():
            try:
                with self._status_lock:
                    self._ws_connect_attempts += 1
                with ws_connect(ws_url, open_timeout=3) as ws:
                    with self._status_lock:
                        self._ws_connected = True
                        self._ws_connect_successes += 1
                        self._ws_last_connected_monotonic = time.monotonic()
                        self._ws_last_error = ""
                    while not self._stop.is_set():
                        try:
                            payload = self._telemetry_queue.get(timeout=0.5)
                        except queue.Empty:
                            continue
                        ws.send(json.dumps(payload, ensure_ascii=True, separators=(",", ":")))
                        with self._status_lock:
                            self._ws_messages_sent += 1
                            self._ws_last_sent_monotonic = time.monotonic()
            except Exception as exc:
                with self._status_lock:
                    self._ws_last_error = _safe_exception_text(exc, self.server_url, ws_url)
            finally:
                with self._status_lock:
                    self._ws_connected = False
            if not self._stop.is_set():
                time.sleep(1.0)


def parse_mission_payload(payload: dict[str, Any], *, received_monotonic: float | None = None) -> MissionState:
    ok = finite_bool(payload.get("ok"), False)
    mission = payload.get("mission") if isinstance(payload.get("mission"), dict) else {}
    mission_db_id_value = finite_float(payload.get("mission_db_id") or mission.get("id"))
    route_tasks = [
        waypoint
        for waypoint in (_parse_waypoint(item, default_z=payload.get("mission_target_alt_m")) for item in payload.get("route_tasks") or payload.get("planned_route_metric") or [])
        if waypoint is not None
    ]
    home_point = _parse_waypoint(payload.get("home_point"), default_z=payload.get("mission_target_alt_m"), default_id="HOME")

    return MissionState(
        contract_version=str(payload.get("contract_version") or ""),
        ok=ok,
        server_reachable=True,
        status=str(payload.get("status") or "HOLD").upper(),
        mission_id=str(payload.get("mission_id") or mission.get("mission_code") or mission.get("id") or ""),
        mission_db_id=int(mission_db_id_value) if mission_db_id_value is not None else None,
        mission_code=str(payload.get("mission_code") or mission.get("mission_code") or ""),
        route_revision=str(payload.get("route_revision") or ""),
        mission_status=str(mission.get("status") or ""),
        launch_authorized=finite_bool(mission.get("launch_authorized"), False),
        launch_blocked_reason=payload.get("launch_blocked_reason"),
        mission_target_alt_m=finite_float(payload.get("mission_target_alt_m") or payload.get("target_alt_m")),
        target_x_m=finite_float(payload.get("target_x")),
        target_y_m=finite_float(payload.get("target_y")),
        target_z_m=finite_float(payload.get("target_z") or payload.get("target_alt_m")),
        home_point=home_point,
        route_tasks=route_tasks,
        control_action=str(payload.get("control_action") or "").strip().lower(),
        control_requested_at=payload.get("control_requested_at"),
        control_request_id=str(payload.get("control_request_id") or ""),
        anchors=list(payload.get("anchors") or []),
        anchor_layout_id=str(payload.get("anchor_layout_id") or payload.get("layout_id") or ""),
        anchor_layout_version=int(finite_float(payload.get("anchor_layout_version") or payload.get("layout_version"), 0) or 0),
        layout_compact=str(payload.get("layout_compact") or ""),
        anchor_layout_valid=finite_bool(payload.get("anchor_layout_valid"), False),
        anchor_layout_warning=payload.get("anchor_layout_warning"),
        received_monotonic=received_monotonic,
        raw=dict(payload),
    )


def _json_body(payload: dict[str, Any]) -> bytes:
    return json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")


def _parse_waypoint(raw: Any, *, default_z: Any = None, default_id: str = "") -> Waypoint | None:
    if not isinstance(raw, dict):
        return None
    x = finite_float(raw.get("x"))
    y = finite_float(raw.get("y"))
    z = finite_float(raw.get("z"))
    if x is None:
        x = finite_float(raw.get("target_x"))
    if y is None:
        y = finite_float(raw.get("target_y"))
    if z is None:
        z = finite_float(raw.get("target_z"))
    if z is None:
        z = finite_float(default_z)
    if x is None or y is None or z is None:
        return None
    arrival_radius_m = finite_float(raw.get("arrival_radius_m"))
    if arrival_radius_m is None:
        arrival_radius_cm = finite_float(raw.get("arrival_radius_cm"))
        arrival_radius_m = arrival_radius_cm / 100.0 if arrival_radius_cm is not None else 0.2
    return Waypoint(
        x_m=x,
        y_m=y,
        z_m=z,
        point_id=str(raw.get("point_id") or raw.get("id") or default_id),
        task_type=str(raw.get("type") or "waypoint").lower(),
        hold_s=finite_float(raw.get("hold_s"), 0.0) or 0.0,
        arrival_radius_m=arrival_radius_m,
        required_scan=finite_bool(raw.get("required_scan"), False),
        raw=dict(raw),
    )


def _ws_url(server_url: str, drone_id: str) -> str:
    parsed = urlparse(server_url)
    scheme = "wss" if parsed.scheme == "https" else "ws"
    netloc = parsed.netloc or parsed.path
    return f"{scheme}://{netloc}/ws/drones/{drone_id}/"


def _safe_ws_url(server_url: str, drone_id: str) -> str:
    parsed = urlparse(server_url)
    scheme = "wss" if parsed.scheme == "https" else "ws"
    hostname = parsed.hostname or "unknown-host"
    netloc = f"{hostname}:{parsed.port}" if parsed.port else hostname
    return f"{scheme}://{netloc}/ws/drones/{drone_id}/"


def _safe_exception_text(exc: Exception, server_url: str, ws_url: str) -> str:
    message = str(exc)
    for sensitive_url in (server_url, ws_url):
        if sensitive_url:
            message = message.replace(sensitive_url, "<server>")
    return f"{type(exc).__name__}:{message}"


def _age_ms(then: float | None, now: float) -> int | None:
    if then is None:
        return None
    return max(0, int((now - then) * 1000))
