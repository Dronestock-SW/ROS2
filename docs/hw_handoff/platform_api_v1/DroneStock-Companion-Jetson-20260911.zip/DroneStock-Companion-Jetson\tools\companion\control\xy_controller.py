from __future__ import annotations

import math

from ..config import AppConfig
from ..types import EstimationState, RCChannels, SensorSnapshot, Waypoint, clamp


class XYController:
    def __init__(self, config: AppConfig) -> None:
        self.config = config

    def compute(self, *, waypoint: Waypoint | None, snapshot: SensorSnapshot, estimation: EstimationState) -> RCChannels:
        if waypoint is None:
            return RCChannels(reason="xy_no_waypoint")
        if not estimation.xy_control_usable:
            return RCChannels(reason="xy_unusable")
        if estimation.current_x_m is None or estimation.current_y_m is None:
            return RCChannels(reason="xy_missing")

        dx = waypoint.x_m - estimation.current_x_m
        dy = waypoint.y_m - estimation.current_y_m
        yaw_rad = math.radians(snapshot.fc.yaw_deg or 0.0)

        ex_body = math.cos(yaw_rad) * dx + math.sin(yaw_rad) * dy
        ey_body = -math.sin(yaw_rad) * dx + math.cos(yaw_rad) * dy

        pitch = 1500 + self.config.xy_kp_pwm_per_m * ex_body
        roll = 1500 + self.config.xy_kp_pwm_per_m * ey_body
        return RCChannels(
            roll=int(clamp(roll, 1500 - self.config.xy_roll_limit_pwm, 1500 + self.config.xy_roll_limit_pwm)),
            pitch=int(clamp(pitch, 1500 - self.config.xy_pitch_limit_pwm, 1500 + self.config.xy_pitch_limit_pwm)),
            throttle=1500,
            yaw=1500,
            reason=f"xy dx={dx:.2f} dy={dy:.2f} exb={ex_body:.2f} eyb={ey_body:.2f}",
        )

