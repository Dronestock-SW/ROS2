"""Hardware and server I/O drivers.

I/O modules do not own mission state and never make flight decisions.
"""

